# GitHub Streak Stats

<table>
  <tr>
    <td>
      Temas
    </td>
    <td>
       <a href="https://github.com/DenverCoder1/github-readme-streak-stats/blob/main/docs/themes.md">
          github-readme-streak-stats/docs/themes.md
       </a>
    </td>
  </tr>
    <tr>
    <td>
      Gerador
    </td>
    <td>
       <a href="https://streak-stats.demolab.com/demo/">
            streak-stats.demolab.com/demo/
       </a>
    </td>
  </tr>
  <tr>
    <td>
      Fonte
    </td>
    <td>
       <a href="https://github.com/denvercoder1/github-readme-streak-stats">
          DenverCoder1/github-readme-streak-stats
       </a>
    </td>
  </tr>
</table>

## Card - Streak

| Preview | Parameters |
|:-------:|:----------:|
| [![GitHub Streak](https://streak-stats.demolab.com/?user=elidianaandrade&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats) | `theme=bear` `background=000` `dates=FFF`|

```
[![GitHub Streak](https://streak-stats.demolab.com/?user=SEUUSERNAME&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)
```