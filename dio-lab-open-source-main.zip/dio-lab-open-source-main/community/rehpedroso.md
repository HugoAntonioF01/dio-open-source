# Rebeca Pedroso

## Minhas redes, conecte-se comigo!
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=006097)](https://www.linkedin.com/in/rebeca-pedroso-590a64170/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/reh_pedroso/)
[![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/rebeca.pedrosoo)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)](https://github.com/rehpedroso)

## Habilidades
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)](https://docs.github.com/)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git)](https://git-scm.com/doc)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Jupyter](https://img.shields.io/badge/Jupyter-000?style=for-the-badge&logo=jupyter)
![MicrosoftSQLServer](https://img.shields.io/badge/Microsoft%20SQL%20Server-000?style=for-the-badge&logo=microsoft%20sql%20server&logoColor=white)
![Kotlin](https://img.shields.io/badge/Kotlin-000?style=for-the-badge&logo=kotlin)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=openjdk)
![PowerBi](https://img.shields.io/badge/PowerBi-000?style=for-the-badge&logo=powerbi)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=rehpedroso&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&text_color=FFF&hide_title=true&hide=stars)

## Linguagens Utilizadas
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=rehpedroso&layout=compact&bg_color=000&border_color=30A3DC&text_color=FFF&hide_title=true&hide=vue,typescript,objective-c,starlark,html,javascript,scss,ruby)

## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=rehpedroso&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&text_color=FFF)](https://github.com/rehpedroso/dio-lab-open-source)