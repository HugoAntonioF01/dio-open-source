# George Franco

***Professor de Física e amante de tecnologia***

## Conecte-se comigo
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:prof.george.franco@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/prof-george-franco/)


## Interesses
![Static Badge](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python&logoColor=FE6100)
![Static Badge](https://img.shields.io/badge/Data%20Science-000?style=for-the-badge&logo=r&logoColor=288CFE)
![Static Badge](https://img.shields.io/badge/C%2B%2B%20C%23-710E08?style=for-the-badge&logo=c)


## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ProfGeorgeFranco&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
