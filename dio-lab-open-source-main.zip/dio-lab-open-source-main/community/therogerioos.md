# Rogerio Oliveira dos Santos
* 🦗 Profile GitHub: [therogerioos](https://github.com/therogerioos)
* 📚 Acesse: [Meu Curriculo Online](https://therogerioos.github.io/resume/)
                                                            
#### 📱 Minhas Redes Sociais:

<center>

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/rogeriooliveiradossantos/)
[![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/rogeriooliveirasantos)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/therogerioos/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)](https://github.com/therogerioos)

</center>

#### 💪 Minhas Habilidades:

<center>

![SQL](https://img.shields.io/badge/SQL-000?style=for-the-badge&logo=sql)
![Power BI](https://img.shields.io/badge/PowerBI-000?style=for-the-badge&logo=PowerBI)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=Python)
![GIT](https://img.shields.io/badge/git-000?style=for-the-badge&logo=git)
![GITHUB](https://img.shields.io/badge/github-000?style=for-the-badge&logo=github)
![VBA](https://img.shields.io/badge/VBA-000?style=for-the-badge&logo=vba)


</center>


#### 🤓 Em processo de aprendizado:

<center>

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![HTML](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=HTML)
![CSS](https://img.shields.io/badge/CSS-000?style=for-the-badge&logo=CSS)

</center>

#### ✅ Meu perfil no GitHub

<center>

[![GitHub Streak](https://streak-stats.demolab.com/?user=therogerioos&theme=dark&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)


![GitHub Stats](https://github-readme-stats.vercel.app/api?username=therogerioos&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=FFA500&text_color=FFF)


![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=therogerioos&bg_color=000&border_color=30A3DC&title_color=FFA500&text_color=FFF)

</center>

### 📖 Meus repositórios de destaque

1) Criação do meu curriculo online

<center>

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=therogerioos&repo=resume&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=FFA500&text_color=FFF)](https://github.com/therogerioos/resume)

</center>

2) Meus estudos sobre Python

<center>

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=therogerioos&repo=EstudosPython&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=FFA500&text_color=FFF)](https://github.com/therogerioos/EstudosPython)


</center>


### 📁 Meu Projetos Futuros

* Criação de Blog
* Criação de Gerenciador de Finanças
* Criação de Gerenciador de Tarefas



