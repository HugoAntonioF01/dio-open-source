 Hudson Farias 


## 🔌  Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin)](https://github.com/hudsonfarias)
[![GitHub](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/hudson-farias-29508521b/)

## 🤹‍♀️ Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![SQL](https://img.shields.io/badge/SQL-000?style=for-the-badge&logo=python)

## 🔍 GitHub Status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=hudsonfarias&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## 📚 Minhas Certificações
[![Match Computing Basics](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin)](https://certificados.descomplica.com.br/graduacao/9efaa41b66243bc8343b1d90e21312e4eafe617e390f4306a0827863d6e43521)