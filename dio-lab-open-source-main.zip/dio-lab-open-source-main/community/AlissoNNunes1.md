## 👋 Welcome to my profile!

<p align="justify"> ✋Olá! Meu nome é Alisson e sou estudante de Análise e Desenvolvimento de Sistemas na UNIT. Sou apaixonado por tecnologia e gosto de explorar vários aspectos do desenvolvimento de software.<strong> Estudando Ciência de Dados e Desenvolvimento Web </p>

### Conecte-se comigo:
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/alissonandradennnunes)[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:alissonandradennnunes@gmail.com)[![LinkedIn](https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alisson-nunes1/)

### Skills:
![Python](https://img.shields.io/badge/Python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)![Git](https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white)![Github](https://img.shields.io/badge/Github-181717?style=for-the-badge&logo=Github&logoColor=white)![Google Cloud](https://img.shields.io/badge/Google%20Cloud-4285F4?style=for-the-badge&logo=google-cloud&logoColor=white)




### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlissoNNunes1&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AlissoNNunes1&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)