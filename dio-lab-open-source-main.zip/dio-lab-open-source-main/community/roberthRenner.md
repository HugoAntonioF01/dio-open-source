# Roberth Renner
Iai, como estâo? Prazer, eu sou Renner estudante de Eng. da Computação, comecei na area de computação tem poucos meses, mas venho também da area de tecnologia sou formado em Mecatrônica, e estou em busca de um novo caminho.

# Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/roberth-renner-37911a199/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/renner.rr/)

# Habilidades

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)


# Projetos

Não possuo projetos realizados, como estou no começo ainda só pratico os conhecimentos com testes, mas podemos deixar status como em andamento.

