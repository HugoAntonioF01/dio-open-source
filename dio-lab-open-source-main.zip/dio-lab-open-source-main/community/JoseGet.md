# Desafio DIO - Contribuindo em um Projeto Open Source no GitHub

Olá, me chamo José Getúlio, tenho 19 anos, sou de Manaus/Amazonas, e sou estudadnte de graduação de Engenharia de Software pela UFAM.

Ingressei neste bootcamp na intenção de aprender a linguagem de programação Python e sobre Ciência de Dados, afim de aprender mais e evoluir meu currículo e portifólio.

Já domino linguagens de programação C e Java.

Essa contribuição faz parte do Profile READ-ME.

## Me siga 

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/getulio_13/)

## Jornada no GitHub

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=JoseGet&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)