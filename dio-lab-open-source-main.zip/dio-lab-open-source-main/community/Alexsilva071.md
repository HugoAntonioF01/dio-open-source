# Alexandre Silva


## Quem sou eu
Sou um novato,migrando da área fitness para a área tech, com interesse em BackEnd. 


## Meus contatos
- GitHub: [Alex71](https://github.com/Alexsilva071)
- Instagram: [Alex.naturalmove](https://www.instagram.com/alex.naturalmove/) 



## Habilidades Técnicas
![Python](https://img.shields.io/badge/Python-blue?style=for-the-badge&logo=python&logoColor=white) ![JavaScript](https://img.shields.io/badge/JavaScript-blue?style=for-the-badge&logo=javascript&logoColor=white)
![Git](https://img.shields.io/badge/Git-blue?style=for-the-badge&logo=git&logoColor=white)

