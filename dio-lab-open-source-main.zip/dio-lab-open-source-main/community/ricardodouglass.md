
# Douglas Mariz

Olá, pessoal! Me chamo Douglas, estou em Passo Fundo-RS, sou um apaixonado por tecnologia que resolveu se jogar nesse mundo da programação. Atualmente sou estudante de Engenharia de Software na Uninter!

### Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/douglas-mariz-66710519a/)

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ricardodouglass&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

### O que estou estudando
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4) 
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript) 
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) 
