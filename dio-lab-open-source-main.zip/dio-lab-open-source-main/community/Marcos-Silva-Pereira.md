# Marcos Pereira

## Um pouco sobre mim
Tenho 28 anos, sou formado em Gestão de TI e sou iniciante na área de tecnologia.

## Conecte-se
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/marcos-da-silva-pereira-940b301a3/)

## Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
