# Meu Perfil

Olá, sou Richard M. Alba. Aqui estão algumas informações sobre mim:

- 🔭 Atualmente estou trabalhando com Sistemas Fotovoltaicos.
- 🌱 Atualmente estou aprendendo Python.
- 📫 Como me encontrar: 
- [![Email](https://img.shields.io/badge/email-006?style=for-the-badge&logo=Email&logoColor=white)](rma.eletrica1@gmail.com) 
- [![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/engrichardalba/)
- [![cults3d](https://img.shields.io/badge/cults3d-0A10?style=for-the-badge&logo=cults3d&logoColor=white)](https://cults3d.com/en/search?q=amartmanufatura) 
- [![Myminifactory](https://img.shields.io/badge/myminictory-0A6?style=for-the-badge&logo=&logoColor=white)](https://www.linkedin.com/in/engrichardalba/) 
- ⚡ Curiosidade: Desenvolvo produtos com foco em manufatura aditiva (Impressão 3D).

## Habilidades

- ![Python](https://img.shields.io/badge/Python-001?style=for-the-badge&logo=Email&logoColor=white)
- ![C++](https://img.shields.io/badge/c++-003?style=for-the-badge&logo=Email&logoColor=white)
- ![GitHub](https://img.shields.io/badge/github-006?style=for-the-badge&logo=Email&logoColor=white)
- ![Git](https://img.shields.io/badge/git-009?style=for-the-badge&logo=Email&logoColor=white)

## Estatísticas do GitHub

![Estatísticas do GitHub](https://github-readme-stats.vercel.app/api?username=rmaxyz&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=rueE94D5&hide_title=true&text_color=FFF) 

## Projetos

- [Projeto 1](https://github.com/rmaxyz/AutoHidroTech)
- [Projeto 2](https://github.com/rmaxyz/nascerrenascer.github.io)

