<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=4e237e&height=120&section=header"/>

 [![Typing SVG](https://readme-typing-svg.herokuapp.com?duration=5011&color=CFCECB&center=falso&vCenter=falso&lines=👋+Hello+World,+Carlos+Junior+here;👋+Welcome+to+my+profile+Carlos-Juni0r)](https://git.io/typing-svg)

## 👨‍💻 About me
 Hi, My name is Carlos Junior, i'm 22 years old. I'm a software engineer with experience in web development and data analysis and I'm trying to be a sucessfull developer😎👍. 

## 💡 Skills & Technologies

<div align="center">

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JAVASCRIPT](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![TYPESCRIPT](https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white)
![SQLite](https://img.shields.io/badge/SQLite-white?style=for-the-badge&logo=sqlite&logoColor=blue)
![GIT](https://img.shields.io/badge/Git-E34F26?style=for-the-badge&logo=git&logoColor=white)
![NODE.JS](https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white)
![REACT](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)

</div>

## 📊 Github Status

[![GitHub Streak](https://streak-stats.demolab.com?user=Carlos-Juni0r&theme=ambient-gradient)](https://git.io/streak-stats)



##


<div align="center"><img src="https://www.alura.com.br/artigos/assets/como-criar-um-readme-para-seu-perfil-github/imagem15.gif"/></div>

<br>

<p align="center"> by Carlos-Juni0r </p>

<div align="center">

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://linkedin.com/in/ucarlos-junior/)
[![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Carlos-Juni0r/dio-lab-open-source/tree/main/community/Carlos-Juni0r.md)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram&logoColor=default)](https://www.instagram.com/c4rlos_junior_)
</div>
<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=4e237e&height=120&section=footer"/>