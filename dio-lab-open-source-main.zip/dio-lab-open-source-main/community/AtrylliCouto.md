<header>
<h1> <strong>Oláa, meu nome é Atrylli Couto!</strong>
<img align = "left" alt= "Title-icon" height = "40" width = "40" src="https://img.icons8.com/fluency/48/null/minecraft-golden-apple.png"/> </h1>

<img align="right" alt="Atry-gif" height="120" width="120" src="https://cdn.discordapp.com/attachments/656990779201421313/1083451830245281912/gif_atry.gif">

<p> 
<img align = "left" alt= "Title-icon" height = "30" width = "30" src="https://cdn.discordapp.com/attachments/798631748421943347/1082789366029619290/1676667607663.png"/> <i>Tecnóloga em Análise e Desenvolvimento de Sistemas, em busca de oportunidades na área de Dados.</i> 
  
<img align = "left" alt= "Title-icon" height = "30" width = "30" src="https://cdn.discordapp.com/attachments/798631748421943347/1082789366335811594/1676667468701.png"/> <i>Estudando Python, AI, Data Science e Data Analysis.</i>  
 
<img align = "left" alt= "Title-icon" height = "25" width = "25" src="https://cdn.discordapp.com/attachments/798631748421943347/1082789365710860459/1676667930134.png"/> <i>E-mail para contato: atryllicouto@gmail.com</i>
</p>
</header>

<div>
  <a href="https://github.com/atrylli">
  <img height="160em" src="https://github-readme-stats.vercel.app/api?username=atrylli&show_icons=true&theme=radical&include_all_commits=true&count_private=true"/>
</div>

  
<div style="display: inline_block"><br>
  <h2 align = "left"> Linguagens e Ferramentas </h2>
  
  <img align="center" alt="Atry-Python" height="45" width="45" src="https://img.itch.zone/aW1hZ2UvMTIzMzU0OC83MTkzMjIzLnBuZw==/347x500/bOhDrd.png">
  <img align="center" alt="Atry-MySQL" height="60" width="60" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original-wordmark.svg">
  <img align="center" alt="Atry-Jupyter_note" height="45" width="45" src="https://img.icons8.com/fluency/48/null/jupyter.png"/>
 <img align="center" alt="Atry-Figma" height="45" width="45" src="https://cdn.discordapp.com/attachments/798631748421943347/1082789365228503110/1676670770335.png"/>
  
</div>
  
<div>
  <h2 align = "left"> Conecte-se Comigo!  </h2>
  
  <a href="https://instagram.com/_trylli" target="_blank"><img src="https://cdn.discordapp.com/attachments/798631748421943347/1082789366612627476/1676668902216.png" target="_blank" height="30" width="30"></a>
  <a href="https://www.linkedin.com/in/atryllicouto/" target="_blank"><img src="https://cdn.discordapp.com/attachments/798631748421943347/1082789366855905290/1676668808990.png" target="_blank" height="30" width="30"></a> 
   
</div>
