<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=1F618D&height=120&section=header"/>

[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=2471A3&size=35&center=true&vCenter=true&width=1000&lines=OLÁ,+MEU+NOME+É+MATEUS+FRANCO+GONÇALVES;TENHO+22+ANOS;E+SOU+ENTUSIASTA+DA++ÁREA+DE+DADOS+:%29)](https://git.io/typing-svg)

<div align="center">  
  <img width="49%" height="195px" src="https://github-readme-stats.vercel.app/api?username=MateusFranc0&show_icons=true&count_private=true&hide_border=true&title_color=2471A3&icon_color=00bfbf&text_color=A3A214&bg_color=0d1117" alt="Mateus Franco Gonçalves github stats" /> 
  <img width="41%" height="195px" src="https://github-readme-stats.vercel.app/api/top-langs/?username=MateusFranc0&layout=compact&hide_border=true&title_color=A3A214&text_color=A3A214&bg_color=0d1117" />
</div>

<div align="center"> 
<a href = "mailto:franco.contato@outlook.com"> <img src="https://img.shields.io/badge/-Email-%23333?style=for-the-badge&logo=gmail&logoColor=A3A214" target="_blank"></a>
<a href="https://www.linkedin.com/in/mateusfranc0/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" style="border-radius: 30px" target="_blank"></a> 
 </div>


### Estudando no momento:
![Python](https://img.shields.io/badge/-Python-0D1117?style=for-the-badge&logo=python&labelColor=0D1117)&nbsp;
![SQL](https://img.shields.io/badge/-SQL-0D1117?style=for-the-badge&logo=mysql&labelColor=0D1117&textColor=0D1117)&nbsp;
![PowerBi](https://img.shields.io/badge/-PowerBi-0D1117?style=for-the-badge&logo=powerbi&labelColor=0D1117&textColor=0D1117)&nbsp;
![Excel](https://img.shields.io/badge/-Excel-0D1117?style=for-the-badge&logo=microsoftexcel&labelColor=0D1117&textColor=0D1117)&nbsp;

<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=1F618D&height=120&section=footer"/>
