
# Zocateli28
Prazer! 
Meu nome é Lucas Zocateli e estou concluido o Desafio: Contruibuindo em um projeto opensource.

## 🐱‍💻 Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/lucas-zocateli-0b11a9199/)

## 🐱‍🐉 Habilidades

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)



# 🐱‍🏍 Referências
- [Digital Innovation One](https://www.dio.me/)