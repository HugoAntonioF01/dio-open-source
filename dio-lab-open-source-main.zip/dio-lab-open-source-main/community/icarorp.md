# IcaroRP
Olá, eu sou o Ícaro. Sou estudante de Analise e desenvolvimento de sistemas pela  Faculdade Martha Falcão Wyden e produtor de conteudo na internet nas horas vagas. É um prazer conhecer você!

Eu guithub anda pegando poeira por causa da faculdade, contudo não vejo a hora de por a mão na massa e participar de projetos com a comunidade

## As redes sociais que participo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/icarorp/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/rp_icaro/)

## Minhas habilidades
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

## Linguagens mais usadas
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=icarorp&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)