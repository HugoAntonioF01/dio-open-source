
# Bruna Ribeiro

📚 Estudando de Ciência de Dados com Python na DIO!

## Conecte-se comigo
[![Email](https://img.shields.io/badge/Email-000?style=for-the-badge&logo=email)](mailto:bruribeiro108@gmail.com)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/bruribeiro108/)

## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

## Github Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=bruribeiro108&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF&hide_title=true&hide=stars)

## Meus desafios cumpridos da DIO ✨
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=bruribeiro108&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/bruribeiro108/dio-lab-open-source)
