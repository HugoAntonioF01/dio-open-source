# Luis Kesley
Olá a todos que chegaram até aqui, me chamo Luis Kesley, tenho 24 anos, estou cursando a faculdade de Gestão em TI mas pretendo seguir na carreira de desenvolvedor, ainda estou me encontrando para saber qual área irei atuar, a cada semestre da faculdade vou descobrindo e adquirindo novas habilidades. Desde pequeno sou curioso na área tecnológica, gosto de jogar nas minhas horas vagas (finais de semana), desenhar e atualmente estou embarcando no mundo da trilha e camping para me conectar mais a natureza.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/luis-kesley-sousa-rodrigues-1ab311142/)

[![GitHub](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=github&logoColor=0E76A8)](https://github.com/kesley22)

## Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![C#](https://img.shields.io/badge/C%23-239120?style=for-the-badge&logo=c-sharp&logoColor=white)

![C++](https://img.shields.io/badge/C%2B%2B-00599C?style=for-the-badge&logo=c%2B%2B&logoColor=white)


## Minhas Contribuições
Não tenho contribuições ainda me desculpe, mas estou aos poucos estudando e aprendendo mais para que novas idéias possam surgir e eu possa contribuir para a comunidade.
