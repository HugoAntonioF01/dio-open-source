# Ulysses
E aí! Eu sou Ulysses, um desenvolvedor iniciante que descobriu a programação no último ano e agora estou totalmente mergulhado nesse mundo computacional. Meu foco está na área de ciência de dados com python e suas tecnologias.

## Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/ulysses_oliveira2015/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/ulysses-lorde)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/ulysses_7ly/)

## Habilidades
[![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)](https://www.python.org/)

<div>
    <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=ulysses-lorde&layout=compact&langs_count=7&theme=dark"/>
</div>