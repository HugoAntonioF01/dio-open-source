# Fernando-Borcsik

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/fernando-sartoreli-borcsik-32447814b/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/fernando.borcsik/)

## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)

## Github Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=fernando-borcsik&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=fernando-borcsik&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=fernando-borcsik&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/fernando-borcsik/dio-lab-open-source)
