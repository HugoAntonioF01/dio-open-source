# Jonathan Wallace
Olá, me chamo Jonathan.  
Sou um dev em em desenvolvimento.

## Conecte-se comigo
[![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github)](https://github.com/JonathanWallace)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/jonathan-wallace-lima-lino-65265622b/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/jonyjw/)

## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) 
![Pandas](https://img.shields.io/badge/Pandas-000?style=for-the-badge&logo=pandas)
![Numpy](https://img.shields.io/badge/Numpy-000?style=for-the-badge&logo=numpy)
![Django](https://img.shields.io/badge/Django-000?style=for-the-badge&logo=django)  
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)  
![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git)
![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=Github)
## Github Stats
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=JonathanWallace&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=JonathanWallace&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

