

#  *Olá me chamo Thaís Alessandra*
  
  Sou apaixonada por tecnologia, estou no meu 3° ano de Licenciatura em Computação!
  
  ## *Interesses*
  
  Estou em busca de uma oportunidade na área de desenvolvimento.
  
  Atualmente estou estagiando no Núcleo da Tecnologia da Informação, atuando como Suporte Técnico na Universidade Estadual do Norte do Paraná.
  
  Tenho 26 anos, sou natural de Bandeirantes/PR, adoro aprender coisas novas!
  
  
  

<div >
  <a href="https://github.com/Thaisalessandra/Thaisalessandra/">
  <img height="180em" width="360em" src="https://github-readme-stats.vercel.app/api?username=Thaisalessandra&show_icons=true&theme=codeSTACKr&border_radius=1.7em" />
    
  <img height="190em" width="360em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Thaisalessandra&layout=compact&theme=codeSTACKr&border_radius=1em" />
</div> 


##  *Conhecimentos*
  
* HTML
* CSS
* Bootstrap
* Java
* JavaScript - aprendendo
* Bootstrap
* SQL
* PYTHON
* Wordpress 

<div  width="100%">

  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg"  width="50"/>       
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-plain.svg" width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-plain.svg" width="50"/>   
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg"  width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg" width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" width="50" /> 
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/wordpress/wordpress-original.svg" width="50"/>
          
              
</div>