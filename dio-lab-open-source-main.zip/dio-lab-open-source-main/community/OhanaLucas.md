
# :love_you_gesture: Hannah Lucas

Full-stack Developer from Vitória-ES, Brazil, graduating at Computer Engineering. I've been in love with computers and magic-like software's since i was 3yo but only had my first "Hello World" at age 14.\
Passionate about life and all the amazing things in the world, most of my hobbies includes gaming, reading, watching animes, tv series/movies, asian "doramas" and playing every kind of sport i can.

### Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/hannah_slucas) 
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:ohannah.lucas@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/hannah-santos-lucas-0680631ab/)

### Habilidades

![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=fd7e14)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=339af0)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python&logoColor=fcc419)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=f8f9fa)](https://docs.github.com/)

### GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=OhanaLucas&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=ff6b6b&title_color=5c7cfa&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=OhanaLucas&layout=compact&bg_color=000&border_color=30A3DC&title_color=5c7cfa&text_color=FFF)
 
---
> “You only live once, but if you do it right, once is enough.”
― Mae West
