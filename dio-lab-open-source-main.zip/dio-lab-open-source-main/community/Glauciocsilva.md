#Glauciocsilva

Meu nome é Gláucio César, sou estudante de Data Science, venho me capacitando nessa área fascinante.

Formado em Administração com especialização em Gestão de Projetos.

📈 Cientista de dados em construção
🔧 Aprendizado em : Python, SQL, PowerBi, Excel, linguagem R, Analise de dados
📫 contate me no email: glauciocsilva@gmail.com

#conecte-se Comigo
🌐 Me conheça mais em: https://www.linkedin.com/in/glauciocsilva/