# Apresentação

Olá, sou Lucas!
Estou em busca de transição de carreira para área de programação com foco em Python

# Encontre-me em:
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](www.linkedin.com/in/lucas-simoes-2582461b6)


