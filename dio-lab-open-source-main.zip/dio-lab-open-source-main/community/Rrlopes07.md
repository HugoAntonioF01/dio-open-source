<div align="center">
  <h3> Olá mundo! Sou Agrônomo - Estudante de TI.</h2>
</div>

  ##

<div align="center">
<a href="https://github.com/Rrlopes07/Rrlopes07">
  <img height="165em" align="center" src="https://github-readme-stats.vercel.app/api?username=rrlopes07&PAT1=rrlopes07&show_icons=true&theme=swift&include_all_commits=true&count_private=true" />
</a>
<a height="180em" href="https://github.com/Rrlopes07/Rrlopes07">
  <img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=rrlopes07&PAT1=rrlopes07&theme=swift" />
</a>
</div>
  
  ##
  
<div align="center" style="display: inline_block"><br>
  <img align="center" alt="Rapha-Java" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg">
  <img align="center" alt="Rapha-Python" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg">    
  <img align="center" alt="Rapha-SQL" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-original.svg">
</div>
  
  ##
  
<div align="center"> 
  <a href="https://www.instagram.com/raphaelrlopes/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/raphaelrlopes/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
  <a href="https://cursos.alura.com.br/user/rrlopes" target="_blank"><img src="https://cursos.alura.com.br/assets/images/logos/logo-alura.svg" target="_blank"></a> 
</div>