 # Lucas Machado aqui 👋
## Bem vindo ao meu Perfil.
Lucas Machado, um advogado/concurseiro no mundo tech. Estou em transição de carreira, saindo dos códigos legais para os códigos computacionais.Sempre fui impressionado com o mundo da tecnologia, vendo o impossível se tornando realidade graças a tecnologia e como ela é capaz de facilitar as nossas vidas.<br>
Desbravar o mundo da tecnologia em busca da linha de código perfeita é a minha missão.
    

## Conecte-se comigo
   [![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/lucas-mbv/)           [![Outlook](https://img.shields.io/badge/Outlook-000?style=for-the-badge&logo=microsoft-outlook&logoColor=0078D4)](mailto:lucasmachado.mbv@hotmail.com) [![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Lucasmbv) [![Perfil DIO](https://img.shields.io/badge/DIO-000?style=for-the-badge)](https://web.dio.me/users/lucasmachado_mbv)

## Tecnologias
![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E) ![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54) ![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white) ![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white)

## Status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Lucasmbv&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Lucasmbv&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)