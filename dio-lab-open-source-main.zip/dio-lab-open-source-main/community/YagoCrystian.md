## Meu Repositório!

| Preview | Parameters |
|:-------:|:----------:|
| [![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=digitalinnovationone&repo=roadmaps&bg_color=4B0082&border_color=32CD32&show_icons=true&icon_color=FFFF00&title_color=E94D5F&text_color=FFF)](https://github.com/digitalinnovationone/roadmaps)| `bg_color=4B0082` `border_color=32CD32` `icon_color=FFFF00` `title_color=E94D5F` `text_color=FFF`|



