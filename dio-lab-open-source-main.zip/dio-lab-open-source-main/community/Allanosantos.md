## Allano Alberto Santos de Jesus 

### 🤙Olá, me chamo Allano, tenho 22 e atualmente estou estudando python.


## Conecte-se comigo.


[![Static Badge](https://img.shields.io/badge/Digital_Innovation_One-badge?color=black)](https://web.dio.me/users/Allano_alberto?)

[![GitHub](https://img.shields.io/badge/GitHub-bagde?color=black)](https://github.com/AllanoSantos)

[![Linkedin](https://img.shields.io/badge/Linkedin-badge?color=black)](https://www.linkedin.com/in/allano-alberto-1891a6171/)

## Habildades

![Git](https://img.shields.io/badge/Git-badge?color=orange)

![Static Badge](https://img.shields.io/badge/GitHub-badge?color=white)
