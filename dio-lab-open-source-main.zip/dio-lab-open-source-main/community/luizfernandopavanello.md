# Luiz Pavanello 

Meu nome é Luiz Fernando, estou estudando Análise e Desenvolvimento de Sistemas e Ciência de Dados para me adaptar à profissão do futuro, e assim poder fazer parte desta grande revolução tecnológica  que trás muitas oportunidades de desenvolvimento profissional e pessoal devido ao seu grande dinamismo e possibilidade de conhecer pessoas que de fato querem mudar o mundo com suas criações,assim como eu.

### Social Meida

[![LinkedIn](https://img.shields.io/badge/LinkedIn-fff?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/luizfernandopavanello/)
[![GitHub](https://img.shields.io/badge/GitHub-black)](https://github.com/luizfernandopavanello)


### Github Stats

![GitHub stats](https://github-readme-stats.vercel.app/api?username=luizfernandopavanello&theme=prussian_icons=true)