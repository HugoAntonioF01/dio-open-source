# Rafael Lemke

## Sobre
------

Olá, me chamo Rafael e estou no inicio de uma nova trajetória. Atualmente em processo de transição de carreira, da aviação para a tecnologia, minhas duas paixões.

Sempre fui muito curioso em querer aprender como as coisas funcionam, e isso me fez chegar até aqui. Estou curtindo cada momento de aprendizagem nessa nova etapa, e me encantando cada vez mais com o mundo da tecnologia.

------



## Conecte-se comigo
[![Instagram](https://img.shields.io/badge/Instagram-708090?style=for-the-badge&logo=instagram)](https://www.instagram.com/rafalemke/) 
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/rafael-lemke-645114137/)

-------

## Habilidades
![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=30A3DC)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=E94D5F)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)
![MySQL](https://img.shields.io/badge/mysql-%2300f.svg?style=for-the-badge&logo=mysql&logoColor=white)
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![Matplotlib](https://img.shields.io/badge/Matplotlib-%23ffffff.svg?style=for-the-badge&logo=Matplotlib&logoColor=black)
![Pandas](https://img.shields.io/badge/pandas-%23150458.svg?style=for-the-badge&logo=pandas&logoColor=white)

--------

## GitHub Status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=rafalemke&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF&hide_title=true&hide=stars)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=rafalemke&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas contribuições 
[![GitHub Streak](https://streak-stats.demolab.com?user=rafalemke&theme=nord)](https://git.io/streak-stats)




