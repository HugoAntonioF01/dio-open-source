# Carlos Alberto Silva Júnior

Sou graduando em Ciência de Dados na Univesp, com previsão de conclusão em 2023. Finalizei a formação Data Science e Machine Learning na Tera em julho de 2022, onde tive o intuito de reforçar os conhecimentos adquiridos na graduação, adquirir experiência prática e desenvolver minhas soft skills. Formado em Desenvolvimento Front-End, Lógica de Programação e Empreendedorismo pelo programa Oracle Next Education. Atualmente atuo como desenvolvedor web na Empreender.

## Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://web.dio.me/users/carlosalbertospace/) 
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=fff)](https://www.linkedin.com/in/carlosalbertosilvajunior/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/casjunior93)

## Habilidades

[![Python](https://img.shields.io/badge/Python-white?logo=Python)](#) [![Jupyter](https://img.shields.io/badge/Jupyter-white?logo=Jupyter)](#) [![sklearn](https://img.shields.io/badge/sklearn-white?logo=scikit-learn)](#)