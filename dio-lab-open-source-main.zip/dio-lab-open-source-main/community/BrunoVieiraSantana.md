
# Bruno Vieira
Estudante de Programação, com foco em Python, em busca de experiência nas áreas de Programação de sistemas e análise de dados.

### Habilidades

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python&logoColor=30A3DC)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

### Contato

[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:bruno_vieira_santana@outlook.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/bruno-vieira-08b95a208/)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=BrunoVieiraSantana&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=BrunoVieiraSantana&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

