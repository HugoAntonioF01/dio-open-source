
# Francisco Cipriano Modesto(devcylon)
Mora em Jaboatão dos Guararapes, sou formado em engenharia elétrica e gosto muito de desafios.
Meus robbies são: andar de moto, estuda programação e curtir com a família.

## Estatística do GitHub

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=devcylon&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Top linguagens
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=devcylon&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

[![GitHub Streak](https://streak-stats.demolab.com/?user=devcylon&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/cyloncipriano/)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/fcmodesto/)

