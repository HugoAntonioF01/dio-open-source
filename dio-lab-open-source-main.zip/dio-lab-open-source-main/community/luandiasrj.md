# Luan Bernardo Dias

Buscando a transição de carreira para a área de tecnologia.

Apaixonado por tecnologia, inovação e desenvolvimento de software.

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/luandias/)
[![E-mail](https://img.shields.io/badge/-Email-f7f7f7?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:luandias@id.uff.br)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-f7f7f7?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/luan-bernardo-dias/)[![Instagram](https://img.shields.io/badge/Instagram-f7f7f7?style=for-the-badge&logo=instagram)](https://www.instagram.com/luantrilhasrj/)


### Habilidades
![Python](https://img.shields.io/badge/Python-f7f7f7?style=for-the-badge&logo=python)
![PHP](https://img.shields.io/badge/php-f7f7f7?style=for-the-badge&logo=php&logoColor=777BB4)
![SQL](https://img.shields.io/badge/SQL-f7f7f7?style=for-the-badge&logo=mysql&logoColor=%2300f)
![C#](https://img.shields.io/badge/C%23-f7f7f7?style=for-the-badge&logo=c-sharp&logoColor=823085)
![JAVA](https://img.shields.io/badge/JAVA-f7f7f7?style=for-the-badge&logo=openjdk&logoColor=%23ED8B00)

![HTML5](https://img.shields.io/badge/HTML-f7f7f7?style=for-the-badge&logo=html5&logoColor=30A3DC)
![CSS3](https://img.shields.io/badge/CSS3-f7f7f7?style=for-the-badge&logo=css3&logoColor=E94D5F)
![JavaScript](https://img.shields.io/badge/JavaScript-f7f7f7?style=for-the-badge&logo=javascript&logoColor=30A3DC)
[![Git](https://img.shields.io/badge/Git-f7f7f7?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-f7f7f7?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=luandiasrj&theme=swift&show_icons=true&icon_color=30A3DC)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=luandiasrj&theme=swift)

### Streak Stats
 [![GitHub Streak](https://streak-stats.demolab.com?user=luandiasrj&locale=pt_BR&background=90%2CFFFFFF%2CEBEBEB)](https://git.io/streak-stats) 


### Meus Principais Desafios de Projeto DIO
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&show_icons=true&icon_color=30A3DC&theme=swift)](https://github.com/elidianaandrade/dio-lab-open-source)
[![Resgate-jQuery](https://github-readme-stats.vercel.app/api/pin/?username=luandiasrj&repo=Resgate-jQuery&show_icons=true&icon_color=30A3DC&theme=swift)](https://github.com/luandiasrj/Resgate-jQuery)

### Meus Principais Artigos na DIO
<table>
  <thead>
    <tr align="left">
      <th>Data</th>
      <th>Título</th>
      <th>Link</th>
    </tr>
  </thead>
  <tbody align="left">
    <tr>
      <td>21/06/2023</td>
      <td>Explicando as siglas da computação em nuvem para leigos</td>
      <td align="center">
        <a href="https://web.dio.me/articles/explicando-as-siglas-da-computacao-em-nuvem-para-leigos">
           <img align="center" alt="Ler Artigo" src="https://img.shields.io/badge/Ler%20Artigo-30A3DC?style=for-the-badge">
        </a>
      </td>
    </tr>
  </tbody>
  <tfoot></tfoot>
</table>