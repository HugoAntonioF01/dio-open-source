# <<< Olá Comunidade!!! >>>

## Victor
    Obrigado pela parceria em podermos sempre melhorar nossos códigos, queira seja fazendo ou queira ajudando! Bora codar.


### Languages and Technologies
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" width="40" height="40"/><img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" width="40" height="40"/><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/New_Power_BI_Logo.svg/630px-New_Power_BI_Logo.svg.png" width="40" height="40"/>

![TOP Linguagens](https://github-readme-stats.vercel.app/api/top-langs/?username=area-41&layout=compact&theme=merko)
![area-41 Status](https://github-readme-stats.vercel.app/api?username=area-41&show_icons=true&theme=merko)
-----
