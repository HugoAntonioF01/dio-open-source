
# Apresentação

Olá, sou Jéssyca! Na adolescência, decidi cursar Desenvolvimento de Sistemas integrado ao ensino médio e desde então tenho certeza que a área da tecnologia é o que eu amo. Atualmente, curso Ciência da Computação e estou sempre em busca de novos desafios e aprendizados. Meus hobbies além da programação envolvem desenho, literatura e crochê. Sinta-se livre para entrar em contato.

# Encontre-me em:
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/jessyca-ferreira/)

## Github stats
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=jessyca-ferreira&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)



