
 ***Hi, I'm Andrielly***, Sou analista de Dados com bacharelado em estatística e formação em Data Science. 
               Sou apaixonada por tudo relacionado a análise de dados. 




## Hard skills

Ao longo do tempo pode conhecer e trabalhar com diversas ferramentas, mas confesso que Python é o meu queridinho.



<div style="display: inline_block"><br>
  <img align="center" alt="Dri-ApacheSpark." height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/apache/apache-original.svg">
  <img align="center" alt="Dri-MongoDB" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mongodb/mongodb-original.svg">
  <img align="center" alt="Dri-MySQL" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original.svg">
  <img align="center" alt="Dri-Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
   <img align="center" alt="Dri-RStudio" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/rstudio/rstudio-original.svg">
  <img align="center" alt="Dri-Azure" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/azure/azure-original.svg">
 <img align="center" alt="Dri-Julia" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/julia/julia-original.svg">
 <img align="center" alt="Dri-go" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/go/go-original.svg">
 <img align="center" alt="Dri-javascript" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg">
 
  ##

  **Sinta-se livre para conecta-se comigo em minhas redes sociais**
  
  <div> 

  <a href = "andrielly.moraespereira@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/andrielly-de-moraes-pereira-4408391b9/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
    <a href="https://www.kaggle.com/andrielly/" target="_blank"><img src="https://img.shields.io/badge/Kaggle-20BEFF?style=for-the-badge&logo=Kaggle&logoColor=white" target="_blank"></a> 
 <a href="https://developer.twitter.com/en/portal/projects/1521565631451222021/apps/" target="_blank"><img src="https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white" target="_blank"></a> 
    
    
</div>
  
  ![Snake animation](https://github.com/andriellymoraespereira/andriellymoraespereira/blob/output/github-contribution-grid-snake.svg)

