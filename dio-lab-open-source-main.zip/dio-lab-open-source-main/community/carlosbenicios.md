# Carlos Benício

Sou estudante de Ciência de Dados. Procurando me aprimorar mais a cada dia!

###Habilidades que estou desenvolvendo
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" width="40" height="40" /> JavaScript

<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-original.svg" width="40" height="40" /> PostGres

<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" width="40" height="40" /> Python

## Entre em contato comigo

[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook)](mailto:cbeniciosouza@gmail.com)
