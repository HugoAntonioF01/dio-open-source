# Enrique Gama
Sobre Mim

Olá! Meu nome é Enrique Gama e tenho 29 anos. Sou formado em Análise e Desenvolvimento de Sistemas.

## Habilidades
Python: Tenho habilidades intermediaria em Python

[![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)](https://docs.python.org/)

## Conecte-se comigo
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram&logoColor=0E76A8)](https://www.instagram.com/gama_enrique/)