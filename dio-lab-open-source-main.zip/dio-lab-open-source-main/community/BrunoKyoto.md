# Bruno Kyoto

Olá! Eu sou Bruno, estudo programação há algum tempo (como autodidata) e estou participando de vários bootcamps oferecidos pela DIO (Digital Innovation One), que são disponibilizados em parceria com empresas dos mais variados setores. Graças à DIO tenho aprendido muito e tenho certeza de que avançarei ainda mais nesse vasto campo do conhecimento. Tenho uma grande paixão por Python (pela sua versatilidade e curva de aprendizado, que é muito favorável aos iniciantes), mas também me aventuro no estudo de outras linguagens, como por exemplo, o Java.

## Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://web.dio.me/users/BrunoKyoto/) 
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=fff)](https://www.linkedin.com/in/bruno-kyoto/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/BrunoKyoto)

## Habilidades

[![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python&logoColor=fff)](https://docs.python.org/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://docs.github.com/pt)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=fff)](https://git-scm.com/doc)