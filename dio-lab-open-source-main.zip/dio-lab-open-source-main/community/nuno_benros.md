# Nuno Benrós

**PT-BR:** Caboverdiano nascido na diáspora. Aventurei-me no Brasil para continuar minha jornada de aprendizado. Desta forma, procuro me desenvolver de forma holística - tanto profissional quanto pessoal.
Sou atraído pelo saber multidisciplinar, sendo que hoje os meus interesses englobam tópicos como Análise/Visualização de Dados e Inteligência Artificial.

**EN-US:** Cape Verdean born in the diaspora. I started my adventured is Brazil to continue my learning journey. I seek to develop myself holistically - both professionally and personally.
I'm attracted by multidisciplinary knowledge, and today my interests are within topics such as Data Analysis/Visualization and Artificial Intelligence

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/nunobenros/)