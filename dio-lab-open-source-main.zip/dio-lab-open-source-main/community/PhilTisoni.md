## Hello, I'm Phelipe

- 🌱 I’m currently learning Python and C#
- 🤞 I’m looking for help with Data Science and Machine Learn
- 💕 I love Music and Arduino too


![GitHub Stats](https://github-readme-stats.vercel.app/api?username=philtisoni&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=philtisoni&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Hard Skills

<div style="display: inline_block"><br>
  <img align="center" alt="Phil-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Phil-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Phil-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Phil-Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="Phil-Csharp" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/csharp/csharp-original.svg">
  <img align="center" alt="Phil-Arduino" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/arduino/arduino-original.svg"">
</div>


## Highlights

[![Adopet](https://github-readme-stats.vercel.app/api/pin/?username=philtisoni&repo=Alura.Adopet&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/PhilTisoni/Alura.Adopet)  [![My-Book-Library](https://github-readme-stats.vercel.app/api/pin/?username=philtisoni&repo=CodeRDIversity-My_Book_Library&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/PhilTisoni/CodeRDIversity-My_Book_Library)
[![Harry-Potter](https://github-readme-stats.vercel.app/api/pin/?username=philtisoni&repo=Arduino-Harry_Potter_Theme&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/PhilTisoni/Arduino-Harry_Potter_Theme)  [![Lista-Tarefas](https://github-readme-stats.vercel.app/api/pin/?username=philtisoni&repo=CodeRDIversity-API_Lista_Tarefas&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/PhilTisoni/CodeRDIversity-API_Lista_Tarefas) 

## Articles

<img align="center" alt="Phil-Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">[DIO - 8 Gráficos Fundamentais para Data Science Utilizando Python](https://web.dio.me/articles/8-graficos-fundamentais-para-data-science-utilizando-python?back=%2Farticles&page=1&order=oldest)

## Contact Me
 
<div> 
  <a href = mailto:phelipe.tisoni@gmail.com><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/phelipetisoni/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
  
</div>
