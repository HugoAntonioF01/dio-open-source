# Marcus Lima

Sou Estudante de análise e desenvolvimento de sistemas e estou em transição de carreira 
## Conecte-se comigo 
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/marcuscorrealima/)


## Git Stats 
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=sucramlima2021&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Habilidades 
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Django](https://img.shields.io/badge/django-%23092E20.svg?style=for-the-badge&logo=django&logoColor=white)
![MySQL](https://img.shields.io/badge/mysql-%2300f.svg?style=for-the-badge&logo=mysql&logoColor=white)
![SQLite](https://img.shields.io/badge/sqlite-%280002e.svg?style=for-the-badge&logo=sqlite&logoColor=white)
![AWS](https://img.shields.io/badge/aws-%2307405e.svg?style=for-the-badge&logo=amazonaws&logoColor=white)

