<h1 align='center'>
 Olá 👋 ! Sou Flavio Alessandro Pereira </h1>

## 🗨 Sobre mim

Tenho me dedicado à área de Desenvolvimento Front-End, aplicando minhas habilidades em HTML e CSS, enquanto no Back-End utilizo a linguagem Python em meus projetos.

[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/flavioalessandropereira/)
[![Gmail](https://img.shields.io/badge/Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white)](mailto:flavioalessandropereira@gmail.com)

## 👨‍💻 Habilidades

![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git)
![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=flavioalessandropereira&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
