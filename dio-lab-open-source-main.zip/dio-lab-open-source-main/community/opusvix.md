Olá! Sou o Maurício Barros.

Bem-vindo ao meu perfil.

Atuando em análise de dados/BI com os processos de extração (seja por importação por consultas SQL, Pentaho, Power Query), transformação, carga dos dados e a devida apresentação de insights (MS Power BI e Looker Studio) para que os clientes possam tomar as decisões mais acertadas em seus negócios.

Atuando no levantamento de processos para determinar quais soluções sejam aplicadas, realizando parametrizações e configurações, utilizando sempre os métodos ágeis. Culminando com o treinamento dos usuários na aplicação, dando ao cliente as melhores condições de utilização da solução.

Esse é meu primeiro contato com o Git e estou gostando bastante, principalmente da forma como as pessoas se ajudam compartilhando seus conhecimentos.
