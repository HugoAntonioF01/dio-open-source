<div>
    <h1>Olá!!! Eu sou o Fernando. 👋 </h1>
    <h2>Bem vindo ao meu Perfil.</h2>
    <p> Me chamo Fernando Anísio Goulart. sou um fascinado por tecnologia e 3D design. Moro em Minas Gerais, tenho 31 anos, 
    apesar da paixão pela area ao longo da minha jornada profissional desenvolvi outras habilidades administrativas,
    gerenciais, liderança de equipes, marketing e desenvolvimento pessoal.
    <p>
    Sou formado em Gestão Comercial na Faculdade Pitágoras e atualmente estou cursando Analise e Desenvolvimento de Sistemas na PUC Minas.
    </p>
    <p>
    Meu objetivo atualmente é desenvolver habilidades e me tornar Cientista de Dados.
    </p>
</div>
<div>
    <h2>Conecte-se comigo</h2>
   <a href="https://www.linkedin.com/in/fernando-anisio-goulart/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
</div>
<br>
<div align="center">
  <a href="https://github.com/fernandodelin">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=fernandodelin&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=fernandodelin&layout=compact&langs_count=7&theme=tokyonight"/>
</div>
<div style="display: inline_block"><br>
    <h2>Tecnologias</h2>
  <img align="center" alt="Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="PowerBI" height="30" width="30" src="https://e7.pngegg.com/pngimages/252/727/png-clipart-power-bi-business-intelligence-microsoft-analytics-microsoft-text-rectangle.png">
  <img align="center" alt="MySQL" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original-wordmark.svg">
  <img align="center" alt="MongoDB" height="30" width="40" src="https://www.pngall.com/wp-content/uploads/13/Mongodb-PNG-Image-HD.png">
  <img align="center" alt="HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
</div>
<br>
<br>
