<h1>
    <a href="https://www.dio.me/">
     <img align="center" width="40px" src="https://hermes.digitalinnovation.one/assets/diome/logo-minimized.png"></a>
    <span>Caio Fábio Juvino de Queiroz</span>
</h1>

Bacharel em Ciência da Computação pela Universidade Federal de Campina Grande. Desenvolvedor Backend, utilizo principalmente Java, Spring Boot e React. Trabalho bem em equipe, gosto de aprender novas tecnologias e ter novos desafios.

## Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=flat)](https://web.dio.me/users/cfjdeq)
[![E-mail](https://img.shields.io/badge/Gmail-000?style=flat&logo=gmail&logoColor=red)](mailto:cfjdeq@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=flat&logo=linkedin&logoColor=blue)](https://www.linkedin.com/in/cfjdeq/)
[![Github](https://img.shields.io/badge/-Github-000?style=flat&logo=github&logoColor=white)](https://github.com/caiojuvino)

## Habilidades
![HTML5](https://img.shields.io/badge/HTML-000?style=flat&logo=html5&logoColor=orange)
![CSS3](https://img.shields.io/badge/CSS3-000?style=flat&logo=css3&logoColor=blue)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=flat&logo=javascript&logoColor=yellow)
[![Git](https://img.shields.io/badge/Git-000?style=flat&logo=git&logoColor=red)](https://git-scm.com/doc)
![Python](https://img.shields.io/badge/Python-000?style=flat&logo=python&logoColor=blue)
![Java](https://img.shields.io/badge/Java-000?style=flat&logo=openjdk&logoColor=red)
![Kotlin](https://img.shields.io/badge/Kotlin-000?style=flat&logo=kotlin&logoColor=purple)
![NodeJS](https://img.shields.io/badge/Node.js-000?style=flat&logo=node.js&logoColor=green)
![Spring](https://img.shields.io/badge/Spring-000?style=flat&logo=spring&logoColor=green)
![MongoDB](https://img.shields.io/badge/MongoDB-000?style=flat&logo=mongodb&logoColor=green)
![MySQL](https://img.shields.io/badge/MySQL-000?style=flat&logo=mysql&logoColor=blue)
![Linux](https://img.shields.io/badge/Linux-000?style=flat&logo=linux&logoColor=yellow)
![Docker](https://img.shields.io/badge/Docker-000?style=flat&logo=docker&logoColor=blue)