# Heberson Vinhote

Olá, meu nome é Heberson Vinhote (31 anos), sou de Manaus-AM.

sou Aluno universitario do Curso de Ciências de Dados pela Faculdade Martha Falcão Wyden, estou atualmente (06/2023) finalizando o 2º semestre.

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/heberson-vinhote-a7b1bb153/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/vinhote.h/)