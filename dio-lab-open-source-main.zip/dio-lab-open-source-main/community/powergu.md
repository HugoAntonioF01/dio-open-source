
# powergu | Gustavo Ferreira Guimarães  

Iniciante no mundo da programação, tenho 27 anos e estou cursando Redes de Computadores pela Fatec Indaiatuba e Análise e desenvolvimento de Sistemas pela UNIASSELVI.

_______________________________________________________

Redes Sociais: 

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/gustavo-ferreira-guimar%C3%A3es-aa5210232/) 

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/gustavoshinoda/)

Linguagens de Programação:

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)
