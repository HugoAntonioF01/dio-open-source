# Estevan-Tomazini
Sou Estevan, com formação pregressa na área de biológicas, onde fiz até o doutorado, estou há algum tempo no processo de transição de carreira para TI, onde iniciei no curso de estatisitica da UFPR e posteriormente no curso de ciencia de dados da PUCPR. Estou no caminho da Ciências de dados, bigdata e desenvolvimento FrontEnd.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/estevantomazini/)

## Habilidades

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)


## GitHub Status

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Estevan-Tomazini&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


## Minhas colaborações

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Estevan-Tomazini&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Estevan-Tomazini&repo=SEUREPOSITORIO&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Estevan-Tomazini/HTML_portifolio)