# Deivison Cassimiro

## Sobre
Meu nome é Deivison Cassimiro Dos Santos, tenho 18 anos e atualmente estou na faculdade de **Análise e Desenvolvimento de Sistemas**, no IFBA. Sou novo no mundo da programação mas a liberdade criativa e desafiadora da área me estimula a querer aprender mais. 

## Interesse / Aprendendo

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)


## Redes Sociais

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/deivison_314/)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/deivison-cassimiro-3ab207238/)
