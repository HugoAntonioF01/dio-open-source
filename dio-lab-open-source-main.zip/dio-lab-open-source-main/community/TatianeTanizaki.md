<h1 align="center">
    <a href="https://www.dio.me/">
        <img align="center" width="40px" src="https://hermes.digitalinnovation.one/assets/diome/logo-minimized.png">
    </a>
    Tatiane Tanizaki
</h1>

<h2>Introdução:</h2>

Meu nome é Tatiane Tanizaki e estou finalizando o primeiro track da carreira de Certified Tech Developer na Digital House. Minha busca constante pelo conhecimento e melhoria contínua se refletiu na minha trajetória como escoteira, onde aprendi a importância de buscar a excelência e superar desafios. Sou uma pessoa proativa, criativa e apaixonada pelo meu trabalho. Além disso, possuo um nível avançado de inglês e fluência em português, o que me permite me comunicar efetivamente em ambientes internacionais. Estou comprometida em continuar crescendo profissionalmente e contribuir de forma significativa em projetos desafiadores.

### Conecte-se comigo:
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:ts.tanizaki@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/tatianetanizaki/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://github.com/KaoruH)

### Habilidades:
![React](https://img.shields.io/badge/React-%23282C34.svg?style=for-the-badge&logo=react)
![HTML](https://img.shields.io/badge/HTML-%23282C34.svg?style=for-the-badge&logo=html5)
![CSS](https://img.shields.io/badge/CSS-%23282C34.svg?style=for-the-badge&logo=css3)
![JavaScript](https://img.shields.io/badge/JavaScript-%23282C34.svg?style=for-the-badge&logo=javascript)
![MySQL](https://img.shields.io/badge/MySQL-%23282C34.svg?style=for-the-badge&logo=mysql)
![Java](https://img.shields.io/badge/Java-%23282C34.svg?style=for-the-badge&logo=java)
![SpringBoot](https://img.shields.io/badge/SpringBoot-%23282C34.svg?style=for-the-badge&logo=spring)
![JWT Token](https://img.shields.io/badge/JWT%20Token-%23282C34.svg?style=for-the-badge&logo=json-web-tokens)
![Spring Security](https://img.shields.io/badge/Spring%20Security-%23282C34.svg?style=for-the-badge&logo=spring)
![API REST](https://img.shields.io/badge/API%20REST-%23282C34.svg?style=for-the-badge&logo=api)
![Maven](https://img.shields.io/badge/Maven-%23282C34.svg?style=for-the-badge&logo=apache-maven)
![Git](https://img.shields.io/badge/Git-%23282C34.svg?style=for-the-badge&logo=git)
![Testing](https://img.shields.io/badge/Testing-%23282C34.svg?style=for-the-badge&logo=testing-library)
![SCRUM](https://img.shields.io/badge/SCRUM-%23282C34.svg?style=for-the-badge&logo=agile)

### Idiomas:
- Inglês
- Português
- Espanhol

### Status

<div>
<a href="https://github.com/KaoruH">
<img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=KaoruH&layout=compact&langs_count=7&theme=nord"/>
