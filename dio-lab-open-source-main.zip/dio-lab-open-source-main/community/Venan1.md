#  Venan Pontes

## Formação
Formação
Licenciatura em Informática
Bacharel Em Administração de Empresas

## Redes Sociais 
![Linkedin](https://img.shields.io/badge/linkedin-000)
@venanpontes

![Linkedin](https://img.shields.io/badge/instagram-000)
@venanpontes

## Habilidades
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=venan1&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Objetivo
Iniciar na área de desenvolvimento web, aprendendo novas tecnologias e aprimorando as habilidades existentes
Contribuir para projetos desafiadores e inovadores que possam gerar impacto positivo na sociedade
Crescer profissionalmente e pessoalmente.
