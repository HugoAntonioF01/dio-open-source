# Pedro Morais 

## Olá! me chamo Pedro e sou um iniciante no mundo da programação.

## Conecte-se comigo
[![Twitter](https://img.shields.io/badge/Twitter-000?style=for-the-badge&logo=twitter)](https://twitter.com/moraisdacosta13)

## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)  

## Github Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Pedro-1301&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF&hide_tittle=true&hide=stars)