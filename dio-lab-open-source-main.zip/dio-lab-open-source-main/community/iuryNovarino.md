<div>
    <h1>Olá mundo!!! Eu sou o Iury 💻</h1>
    <h2>Seja muito bem vindo!!</h2>
    <p> Me chamo Iury Novarino, trabalhei durante 12 anos na área de infraestrutura de TI e agora estou me reinventando e estudando programação, além disso estudo inglês e espanhol também. A tecnologia é algo que me fascina desde novo, mesmo estando um tempo sem trabalhar na área nunca deixei de acompanhar. Agradeço muito a Digital Innovation pela a oportunidade dada no seu projeto vocês tem mudado vidas, o priemeiro sálario que eu pegar como programador irei enviar um presente para a DIO e ao professor Gustavo Guanabara. Vejo na Ciência de Dados um grande potencial de crescimento nos próximos anos devido a sua capacidade de tornar empresas e negócios mais rentáveis e ecologicamente sustentáveis. Seria muito louco se em breve eu me tornar um cientista de dados, pois quando criança sonhei muito com isso!
    </p>
    <p>Continuem lutando para a realização dos seus sonhos pessoal, esse seguimento de programação é muito glamuroso, porém exige muita dedicação e horas de estudos. E não se esqueçam de me indicar caso se tornem cientistas de dados primeiro do que a minha pessoal!!! 
    </p>
</div>
<div>
    <h2>Conecte-se comigo</h2>
   <a href="www.linkedin.com/in/iurynovarino" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
   <a href="https://github.com/iurynovarino" target="83Rfl#3843"><img src="https://img.shields.io/badge/Github-7289DA?style=for-the-badge&logo=github&logoColor=white" target="_blank"></a> 
    <a href = "mailto:novarinos@hotmail.com"><img src="https://img.shields.io/badge/-Hotmail-%23333?style=for-the-badge&logo=microsoftoutlook&logoColor=white" target="_blank"></a>
</div>
<br>
<div align="center">
  <a href="https://github.com/83Rafa">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=iurynovarino&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=iurynovarino&layout=compact&langs_count=7&theme=tokyonight"/>
</div>
<div style="display: inline_block"><br>
    <h2>Tecnologias</h2>
  <img align="center" alt="Iury-Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">    
  <img align="center" alt="Iury-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Iury-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg"> <img align="center" alt="Iury-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg">

</div>
<br>
<br>

## Principais Projetos
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/elidianaandrade/dio-lab-open-source)
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=iurynovarino&repo=TelaDeLogin001&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/digitalinnovationone/roadmaps)
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=iurynovarino&repo=HTML-CSS&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/elidianaandrade/dio-lab-open-source)

    

## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=iurynovarino&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](thhps://github.com/83Rafa/dio-lab-open-source)