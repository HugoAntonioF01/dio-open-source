# João Gonçalves!
Olá, estou estudando de Engenharia de Software, ainda não estou trabalhando na área. Gosto muito de tecnologia e estou aprendendo muito nos cursos da [DIO](https://www.dio.me/).
<div>
  <a href="https://github.com/Joao-G-oncalves">
 
  ![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Joao-G-oncalves&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
  ![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Joao-G-oncalves&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
</div>

## Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-black?style=for-the-badge)](https://web.dio.me/users/zaquir01/)
[![E-mail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:zaquir01@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-blue?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/joao-g-oncalves/)
[![Instagram](https://img.shields.io/badge/-Instagram-white?style=for-the-badge&logo=instagram)](https://www.instagram.com/goncalves_jooo/)