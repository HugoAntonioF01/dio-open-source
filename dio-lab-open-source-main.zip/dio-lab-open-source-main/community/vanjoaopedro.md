
# **Olá a todos 👋, me chamo João Pedro**😉 

## Quem sou eu ?🤔

* 👨‍💻Aspirante a cientista de dados.
* 🖥 Técnico em informática.
* 👨‍🎓Bacharelando em Sistemas de Informações.
* 📚Estudante e curioso para aprender novas técnicas.

## Skills 🧙‍♂️

* 🐍 Python.
* 📊 R.
* 🎲 SQL.
* 💻 Power BI.
* 🧠 Machine Learning.
* 🧪 Survival Analisis.
* 📉 Data Visualization.

## Conecte-se comigo 🌎


[![LinkedIn](https://img.shields.io/badge/LinkedIn-00a8ff?style=for-the-badge&logo=linkedin&logoColor=fff)](https://www.linkedin.com/in/jo%C3%A3o-pedro-silva-prado/)
[![Instagram](https://img.shields.io/badge/Instagram-E1306C?style=for-the-badge&logo=instagram&logoColor=fff)](https://www.instagram.com/joaohelsing/)
