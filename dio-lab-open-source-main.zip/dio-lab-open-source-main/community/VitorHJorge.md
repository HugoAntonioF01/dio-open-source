<h1 align="Center">VITOR HENRIQUE JORGE<H1>

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com)
[![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com)
[![Facebook](https://img.shields.io/badge/github-000?style=for-the-badge&logo=github)](https://www.gituhb.com)

<H2>Linguagens de Programação e Marcação</h2>

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)



<h2>Linguagens de Programação e Marcação mais Usadas</H2>

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=VitorHJorge&bg_color=000&border_color=FFF&title_color=FFF&text_color=FFF)

