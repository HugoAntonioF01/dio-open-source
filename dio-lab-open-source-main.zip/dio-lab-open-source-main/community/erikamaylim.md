# ![Logo Coruja](https://icons.iconarchive.com/icons/iconarchive/wild-camping/48/Bird-Owl-icon.png) ERIKAMAYLIM

Olá! Me chamo Erika, sou estudante de Sistemas de Informação, moro no Rio de Janeiro e criei este arquivo para o desafio "Contribuindo em um Projeto Open Source no GitHub" do Bootcamp Potência Tech powered by iFood | Ciências de Dados com Python.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/linkedin-%230077B5.svg?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/erikamaylim/)

## Algumas habilidades
![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white) ![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54) ![C#](https://img.shields.io/badge/c%23-%23239120.svg?style=for-the-badge&logo=c-sharp&logoColor=white) ![Go](https://img.shields.io/badge/go-%2300ADD8.svg?style=for-the-badge&logo=go&logoColor=white) ![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white) ![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white)
