# Flipedds
🌱 Olá, me chamo Filipe André <br>

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/filipe-andr%C3%A9-16b1bb239/) <br>
# Top Languages
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Flipedds&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF) <br>
# Repositório que estou desenvolvendo.
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Flipedds&repo=Portfolio_angular&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Flipedds/Portfolio_angular)
