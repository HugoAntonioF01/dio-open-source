
# Apresentação

Olá, sou João Emanuel! Apaixonado por tecnologia e em uma constante busca de aprimorar meus conhecimentos e explorar novos horizontes.Atualmente, curso Análise e Desenvolvimento de Sistemas e estou sempre em busca de novos desafios e aprendizados. Meus hobbies além da programação envolvem música, leitura e games.

# Encontre-me em:
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/jo%C3%A3o-emanuel-618373218)




