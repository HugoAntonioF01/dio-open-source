# João Gabriel Moraes Carvalho
Estudante de Engenharia da Computação. Entusiasta em programação e eletrônica!

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/joaogabriel_mc/)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/joão-gabriel-carvalho-213738189/)


### Habilidades
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=JoaoGaBRiel-X&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=JoaoGaBRiel-X&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

### Meus Principais Desafios de Projeto DIO
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=JoaoGaBRiel-X&repo=desafio_criando_sistema_bancario_DIO&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/JoaoGaBRiel-X/desafio_criando_sistema_bancario_DIO)
[![Repo DIO Roadmaps](https://github-readme-stats.vercel.app/api/pin/?username=JoaoGaBRiel-X&repo=app_transf_bancaria&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/JoaoGaBRiel-X/app_transf_bancaria)

