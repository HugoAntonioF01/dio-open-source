<h1>
    <a href="https://www.dio.me/">
     <img align="center" width="40px" src="https://hermes.digitalinnovation.one/assets/diome/logo-minimized.png"></a>
    <span> .-~! -  gcn_feloz</span>
</h1>

     Um breve resumo do meu perfil dev 😅


---

## Maker
O que ta criado melhoramos, o que não está, inventamos.

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/gcn_feloz/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:gcn_feloz@hotmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/albertomacielkraemer/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://github.com/gcn-feloz)


### Habilidades
![HTML5](https://img.shields.io/badge/HTML5%20[5/10]-000?style=for-the-badge&logo=html5&logoColor=30A3DC)
![CSS3](https://img.shields.io/badge/CSS3%20[5/10]-000?style=for-the-badge&logo=css3&logoColor=E94D5F)
![JavaScript](https://img.shields.io/badge/JavaScript%20[3/10]-000?style=for-the-badge&logo=javascript&logoColor=30A3DC) 
![Git](https://img.shields.io/badge/Git%20[4/10]-000?style=for-the-badge&logo=git&logoColor=E94D5F) 
![GitHub](https://img.shields.io/badge/GitHub%20[5/10]-000?style=for-the-badge&logo=github&logoColor=30A3DC) 
![Python](https://img.shields.io/badge/Python%20[5/10]-000?style=for-the-badge&logo=Python&logoColor=30A3DC) 
![Arduino](https://img.shields.io/badge/Arduino%20[8/10]-000?style=for-the-badge&logo=arduino&logoColor=30A3DC)


### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=gcn-feloz&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=gcn-feloz&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

### Meus Principais Desafios de Projeto DIO
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/elidianaandrade/dio-lab-open-source)
[![Repo DIO Roadmaps](https://github-readme-stats.vercel.app/api/pin/?username=digitalinnovationone&repo=roadmaps&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/digitalinnovationone/roadmaps)





---
