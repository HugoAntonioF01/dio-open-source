# Rafael N Gimenez


## Um rápido Resumo sobre mim:

#### Sou o Rafael, pai de família, futuro Ciêntista de Dados, entusiastade tecnologia, migrando decarreira. Busco por oportunidades e conexões pra combinar minha minhas skills e trocas experiências.



### Fique a vontade para conectar-se comigo:
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/rapha_gimenez?tab=ski)

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://github.com/Gimenez10)
     
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/rafaelgimenez1/)

[![WHATSAPP](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/+5519983602056)

[![E-mail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:rapha.gimenez@gmail.com)


### Habilidades:
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)

![R](https://img.shields.io/badge/R-276DC3?style=for-the-badge&logo=r&logoColor=white)

![AWS](https://img.shields.io/badge/Amazon_AWS-232F3E?style=for-the-badge&logo=amazon-aws&logoColor=white)
 
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)

![SQL](https://img.shields.io/badge/SQL-07405E?style=for-the-badge&logo=sql&logoColor=white)

![BOOTSTRAP](https://img.shields.io/badge/Bootstrap-563D7C?style=for-the-badge&logo=bootstrap&logoColor=white)

![GIT](https://img.shields.io/badge/Git-E34F26?style=for-the-badge&logo=git&logoColor=white)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Gimenez10&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E34F26F&text_color=FFF)

### Meus Principais Desafios de Projeto DIO
[![Repo DIO Versionamento de Código com Git e GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E34F26F&text_color=FFF)](https://github.com/CientistaPY/dio-curso-git-github.git)
[![Repo DIO Roadmaps](https://github-readme-stats.vercel.app/api/pin/?username=digitalinnovationone&repo=roadmaps&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E34F26F&text_color=FFF)](https://github.com/digitalinnovationone/roadmaps)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Gimenez10&layout=compact&bg_color=000&border_color=30A3DC&title_color=E34F26F&text_color=FFF)


### Meus Repositórios GitHub

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Gimenez10&repo=project-flexbox-dio-master&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E34F26F&text_color=FFF)](https://github.com/Gimenez10/project-flexbox-dio-master)


### Meus Principais Artigos na DIO
- [Como Iniciar Uma Carreira sem Experiencia aos 40 anos?](https://web.dio.me/articles/como-iniciar-na-carreira-sem-experiencia-aos-40-anos?back=%2Farticles&page=1&order=oldest)
- [Inteligência Artificial e Python: Potencializando a Era Tecnológica](https://web.dio.me/articles/inteligencia-artificial-e-python-potencializando-a-era-tecnologica?back=%2Farticles&page=1&order=oldest)

Feito com 💙 por [Rafael](https://web.dio.me/users/rapha_gimenez).