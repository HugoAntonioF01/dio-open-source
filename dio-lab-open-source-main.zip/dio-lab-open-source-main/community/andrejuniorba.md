# Olá! Eu sou André Luz 👍😀 
Apaixonado por educação matemática, ciência e análise de dados.

## Vamos nos conectar?

[![Linkedin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/andrejuniorba/)
[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/andrejuniorba/)


![André GitHub stats](https://github-readme-stats.vercel.app/api?username=andrejuniorba&show_icons=true&theme=dracula)

## Tecnologia que estou estudando e usando atualmente:

<div style="display: inline_block"><br/>
    <img align="center" alt="Python" src ="https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white">
    <img align="center" alt="SQlite" src ="https://img.shields.io/badge/SQLite-07405E?style=for-the-badge&logo=sqlite&logoColor=white">
    <img align="center" alt="Excel" src ="https://img.shields.io/badge/Microsoft_Excel-217346?style=for-the-badge&logo=microsoft-excel&logoColor=white">
    <img align="center" alt="Arduino" src ="https://img.shields.io/badge/Arduino-00979D?style=for-the-badge&logo=Arduino&logoColor=white">

</div><br/>

