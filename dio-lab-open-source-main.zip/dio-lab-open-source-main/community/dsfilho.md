# Olá Visitante!
<p>Me chamo Daniel Filho atuo no mercado de tecnologia a mais de 10 anos, tendo trabalhado na área da industria e comércio, em pequenas e grandes empresas, trabalhando diretamente com infraestrutura de TI, Segurança de redes e suporte a usuários, tenho como pedra angular a busca pelo alinhamento da tecnologia ao negócio do cliente.

Nos últimos anos, tenho atuado como desenvolvedor independente com foco em sistemas web, com conhecimento em Php, Java, JavaScript (Node/ React), banco de dados SQL , NoSQL e infraestrutura de serviços web.

Sou Bacharel em Ciência da Computação, Pós Graduado – (Lato Sensu) em Desenvolvimento Web Full Stack e Desenvolvedor Back End NodeJs, programa em parceria do Ifood com a Digital House através do programa Potência Tech.</p>

<div>

  ![gifFinal](https://user-images.githubusercontent.com/99821361/204103411-605426af-e7c0-405f-88ed-6d8e3ff6edc5.gif)


</div>

<div align="center">
<img height="180em" src="https://github-readme-stats.vercel.app/api?username=dsfilho&amp;show_icons=true&amp;theme=codeSTACKr&amp;include_all_commits=true&amp;count_private=true" style="max-width: 100%;">

<img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=dsfilho&amp;layout=compact&amp;langs_count=7&amp;theme=codeSTACKr" style="max-width: 100%;">
</div>

<br>
 
<div align="center">
<img width="40" height="30" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg" alt="PHP"/>

<img width="40" height="30" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/laravel/laravel-plain.svg" alt="Laravel" />
          
<img width="40" height="30" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" alt="Java" />
          
<img width="40" height="30" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" alt="JavaScript" />
            
<img width="40" height="30" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg" alt="Node.jS" />
          
<img width="40" height="30" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" alt="Mysql" />
                    
<img width="40" height="30" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" alt="React" />

<img width="40" height="30" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" alt="CSS" />

<img width="40" height="30" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" alt="HTML" />
</div>
         
 ---
## Conecte-se comigo!



<div align="Center">

<a href="https://web.dio.me/users/danielfilho">
<img width="100" height="35" src="https://img.shields.io/badge/DIO-Digital_Innovation_One-blue" />
</a>

<a href="https://www.linkedin.com/in/ddsfilho">
<img width="100" height="35" src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white" />
</a>
  
 <a href="https://api.whatsapp.com/send?phone=5571987875747"> 
 <img width="100" height="35" src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>
  
 <a href="mailto:danielfilho@mesalvati.com.br">
   <img width="100" height="35" src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" />
  </a>
    
</div>          

