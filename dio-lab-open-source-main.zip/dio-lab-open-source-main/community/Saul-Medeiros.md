# 👋 E aí, eu sou o Saul Medeiros 😎

- 👀 Eu me interesso bastante por linguagem de programação e linguagem de desenvolvimento web
- 🌱 Atualmente estudo Java, Programação Orientada a Objetos, Phyton, HTML/CSS/JS e um pouco de PHP.
- ⭐ Planejo para o meu futuro entrar em uma faculdade de TI para aprimorar e aperfeiçoar meu conhecimento

```py
aboutMe = {
    'interesses': 'Programação Back-End e Desenvolvimento Web',
    'back-end': 'Java, Python e PHP',
    'front-end': 'HTML, CSS e Javascript'
}
```

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Saul-Medeiros&layout=compact&langs_count=6&theme=transparent&title_color=ffffff&text_color=ffffff&bg_color=000&border_color=000000)

## Tecnologias

<div style="display: inline_block"><br>
  <img align="center" alt="Java" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg">
  <img align="center" alt="Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="PHP" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/php/php-original.svg">
  <img align="center" alt="HTML5" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg">
</div>

## Minhas Redes
  
[![Instagram](https://img.shields.io/badge/Instagram-%23e4405f?style=for-the-badge&logo=instagram&logoColor=white)](https://instagram.com/saul.mdrs_) [![Gmail](https://img.shields.io/badge/Gmail-ff0000?style=for-the-badge&logo=gmail&logoColor=white)](mailto:saulmedeiros2017@gmail.com) [![LinkedIn](https://img.shields.io/badge/LinkedIn-0E76A8?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/saulmedeiros/)

## Projetos Acadêmicos

[![DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&border_color=000000&show_icons=true&icon_color=ff0050&title_color=ff0050&text_color=FFF)](https://github.com/elidianaandrade/dio-lab-open-source)
[![Repo Java Database](https://github-readme-stats.vercel.app/api/pin/?username=Saul-Medeiros&repo=Java_DB_ClinicaMedica&bg_color=000&border_color=000000&show_icons=true&icon_color=FF8C00&title_color=FF8C00&text_color=FFF)](https://github.com/Saul-Medeiros/Java_DB_ClinicaMedica)
[![Repo PHP Database](https://github-readme-stats.vercel.app/api/pin/?username=Saul-Medeiros&repo=ProjetoWeb3A&bg_color=000&border_color=000000&show_icons=true&icon_color=6A5ACD&title_color=6A5ACD&text_color=FFF)](https://github.com/elidianaandrade/dio-lab-open-source)

