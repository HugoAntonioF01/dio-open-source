### Olá, sou o Rafael.

Nesse momento estou realizando o bootcamp da Digital Innovation One - [Ciências de Dados com Python](https://www.dio.me/bootcamp/potencia-tech-powered-ifood-ciencias-de-dados-com-python) e resolvi passar deixar meu Alô!

- 🔭 Focado em desenvolvimente Full Stack;
- 🐍 Trabalhando em pequenos projetos próprios com Python;
- 📫 Buscando conhecimento...


<div>
  <a href="https://github.com/foxtryan">
  <img height="168em" src="https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=foxtryan&custom_title=Linguagens+mais+usadas:&layout=compact&langs_count=8&theme=dark&hide_border=true"/>
</div>
