<h1>Ismael Roberto L Gonçalves</h1>
Sou um amador em tecnologia, tentando saber de alguma coisa, e fazendo o meu melhor para que isso aconteça.

# Conecte-se Comigo
[![LinkedIn](https://img.shields.io/badge/GitHub-fff?style=for-the-badge&logo=github&logoColor=0E76A8)](https://github.com/Ismagold67)

[![Instagram](https://img.shields.io/badge/Instagram-fff?style=for-the-badge&logo=instagram)](https://instagram.com/ismagold67?igshid=OGQ5ZDc2ODk2ZA==)

[![Twitter](https://img.shields.io/badge/Twitter-FFF?style=for-the-badge&logo=twitter)](https://twitter.com/ismelbateraa2)

# Habilidades
![HTML5](https://img.shields.io/badge/HTML5-fff?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-fff?style=for-the-badge&logo=css3&logoColor=264CE4)
![Angular](https://img.shields.io/badge/Angular-fff?style=for-the-badge&logo=angular&logoColor=C3002F)
![JavaScript](https://img.shields.io/badge/JavaScript-fff?style=for-the-badge&logo=javascript)
![Java](https://img.shields.io/badge/Java-fff?style=for-the-badge&logo=java)

# Linguagens
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Ismagold67&bg_color=fff&border_color=30A3DC&title_color=E94D5F&text_color=000&)

# GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Ismagold67&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

# Minhas Contribuições

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Ismagold67&repo=SEUREPOSITORIO&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Ismagold67/SEUREPOSITORIO)