
# **Desafio Profile da Dio**


## **Wesley Kadekaro**

### **Sobre Mim:** 
Me chamo Wesley, sou natural de SP, porém, eu moro em MG desde pequeno. Amo tecnologia e ciências, o meu contato com a programação foi algo que me transformou e que considero muito importante em minha vida. Sou aluno de Física da UFSJ, e lá tive contato com outras linguagens de programação (além do python que é a minha primeira linguagem). É um prazer me apresentar a todos vocês espero que possamos aprender muito nessa jornada!

**Para acessar o meu perfil na Dio click na imagem:**      

\
[![Dio](https://hermes.digitalinnovation.one/assets/diome/logo-full.svg)](https://web.dio.me/home/Kadekaro) 

\      
|Habilidades|FrameWorks|Linguagens|Rede Sociais|
|-----------|----------|----------|------------| 
|  ![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)|[![Django](https://img.shields.io/badge/Django-092E20?style=for-the-badge&logo=django&logoColor=white)](https://www.djangoproject.com/)|![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)|[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/wesley-kadekaro-687aa221a//)|
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)|[![Spring Boot](https://img.shields.io/badge/Spring_Boot-6DB33F?style=for-the-badge&logo=spring-boot&logoColor=white)](https://spring.io/projects/spring-boot)|||[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/Kadekaro/)
|![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)|
|![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
|![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Kadekaro&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Kadekaro&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)