# Karen Lima

Olá, meu nome Karen Lima. Eu sou formada em Engenharia de Materiais e Nanotecnologia, mas atualemnte estou tentando migrar para a área de TI. Eu tenho grande interesse em Back-end e pretendo me desenvolver nessa área. 

### Conecte-se comigo
[![Meu Perfil na Dio](https://img.shields.io/badge/Meu_Perfil_na_DIO-000?style=for-the-badge&logologoColor=0E76A8)](https://web.dio.me/users/lima_kcls/?tab=skills)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/karen-lima-602a77277)

[![Email](https://img.shields.io/badge/Gmail-000?style=for-the-badge&logo=gmail&logoColor=orange)](lima.kcls@gmail.com)

[![GitHUb](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/karenCLima)

### Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![GitHUb](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)
![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E34F26)
![Microsoft Excel](https://img.shields.io/badge/Microsoft_Excel-000?style=for-the-badge&logo=microsoft-excel&logoColor=217346)
![Power BI](https://img.shields.io/badge/Power_BI-000?style=for-the-badge&logo=Power%20BI&logoColor=F2C811)

### Em aprendizado
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Springboot](https://img.shields.io/badge/Spring_Boot-000?style=for-the-badge&logo=spring-boot)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=karenCLima&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=karenCLima&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)