Sobre mim
# Vinicius Laranjeira

## Sobre mim

Olá! Sou Vinicius Laranjeira, um entusiasta da programação apaixonado por Python e C++. Sou um desenvolvedor autodidata com uma grande paixão por resolver problemas complexos por meio de código limpo e eficiente. Tenho experiência no desenvolvimento de aplicativos e soluções web.

## Habilidades

- **Linguagens de Programação:** Python, C++
- **Desenvolvimento Web:** HTML, CSS, JavaScript
- **Frameworks e Bibliotecas:** Django, Flask, Qt
- **Banco de Dados:** MySQL, PostgreSQL
- **Controle de Versão:** Git, GitHub
- **Metodologias de Desenvolvimento:** Agile, Scrum
