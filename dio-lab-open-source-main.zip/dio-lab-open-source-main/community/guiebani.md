# Guilherme Ebani

Oi! Eu sou o Guilherme. Sou formado em Engenharia Civil e atualmente moro em Belo Horizonte/MG.

Meu primeiro contato com programação ocorreu pela necessidade de automatizar inúmeras tarefas extremamente repetitivas no local onde trabalho. Até então achava que esse mundo era para pessoas super inteligentes e que eu nunca conseguiria escrever duas linhas de código.

Comecei a ter muito interesse em aprender sobre diversas linguagens e percebi que tenho uma boa afinidade pela área de ciência de dados e hoje estou dando os primeiros passos de um processo de transição de carreira.

Quando não estou trabalhando ou estudando, gosto muito de assistir filmes e séries (❗️aceito indicações❗️), jogar, ficar com meus gatos, me aventurar na cozinha e aprender novas líguas.

## 🖥️ **Conecte-se comigo**

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/guilherme-ebani-0574b971/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/guiebani/)

## 📚 **Interesses**

[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Pandas](https://img.shields.io/badge/pandas-000.svg?style=for-the-badge&logo=pandas&logoColor=white)
![GoogleColab](https://img.shields.io/badge/Google%20Colab-000.svg?style=for-the-badge&logo=Google-Colab&logoColor=white)
![SQL](https://img.shields.io/badge/Microsoft%20SQL%20Server-000.svg?style=for-the-badge&logo=Microsoft-SQL-Server&logoColor=white)
![PowerBI](https://img.shields.io/badge/Power%20BI-F2C811.svg?style=for-the-badge&logo=Power-BI&logoColor=black)
