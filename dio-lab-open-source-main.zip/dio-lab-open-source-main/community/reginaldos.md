# Reginaldo Santos

## Conecte-se comigo
[![GitHub](https://img.shields.io/badge/GitHub-30A3DC?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/reginaldos)

## Habilidades
[![GitHub](https://img.shields.io/badge/GitHub-30A3DC?style-for-the-badge&logo-github&logoColor=fff)](https://docs.github.com/)
[![Git](https://img.shields.io/badge/Git-30A3DC?style-for-the-badge&logo-git&logoColor=fff)](https://git-scm.com/doc)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=reginaldos&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF&hide_title=true&hide=stars)

## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=reginaldos&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/reginaldo/dio-lab-open-source)




