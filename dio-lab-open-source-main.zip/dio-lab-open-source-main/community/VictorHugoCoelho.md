# 👋Olá, meu nome é Victor Hugo

### 💻Estou iniciando uma graduação Interdisciplinar em ciência e tecnologia e pretendo seguir para a área de desenvolvimento de software, sou iniciante e não domino nenhuma tecnologia mas tenho muita sede de conhecimento e paixão por tecnologia.

## 📍Contatos

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/victor-hugo-ribeiro-de-almeida-coelho-104700197)
