# Hello there 👋

### Nice to meet you! I'm Danilo, Android Developer

Motivated by my passion for tech and problem resolutions with logic, I'm undergoing a carrer change from International Business Developer to Mobile Developer.

For the past year I'v been studying Android and developing apps using Kotlin and Java.

I like to work with international clients and multi-cultural teams. I have experience in different countries and can adapt my communication in several languages.

## Skills
  
<div style="display: inline_block">
  <img align="center" alt="Danilo-Java" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" />
  <img align="center" alt="Danilo-Kotlin" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/kotlin/kotlin-original.svg" />
  <img align="center" alt="Danilo-Kotlin" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/android/android-original.svg" />
  <br>
  <br>
</div>


## Let's connect!

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/gomes-danilo/)


<div align="center"><br>
  <a href="https://github.com/dgomesdev">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=dgomesdev&show_icons=true&theme=dark&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=dgomesdev&layout=compact&langs_count=7&theme=dark"/>
</div>
