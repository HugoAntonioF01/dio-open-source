# miti
[![GitHub Streak](https://streak-stats.demolab.com/?user=wladimith&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

## Ei, vamos nos conectar?
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=GitHub&logoColor=0E76A8)](
https://github.com/wladimith)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/wladimith)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/wladimith)
[![Strava](https://img.shields.io/badge/Strava-000?style=for-the-badge&logo=Strava)](
https://www.strava.com/athletes/wladimith)

## Habilidades em desenvolvimento
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=wladimith&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)


## GitHub Status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=wladimith&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=FFA500&title_color=E94D5F&text_color=FFF&hide_title=true)

## Contribuições em desenvolvimento
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=wladimith&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/wladimith/dio-lab-open-source)