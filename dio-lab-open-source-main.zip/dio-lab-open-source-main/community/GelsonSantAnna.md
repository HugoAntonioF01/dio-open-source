# Gelson
## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/gelsonsantannadev/)
## Habilidades
## Linguagens de Marcação e Estilo
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4) ![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5) 

## Linguagens de Programação
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)


## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=GelsonSantAnna&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title&text_color=FFF&hide_title=true&hide=stars)      