# Fernanda Ribeiro

<p> Olá! Sou Fernanda, Graduada em Sistemas de Informação e Mestra em Ciência da Computação. </p>
<p>Tenho experiência através de projetos e estágios desenvolvidos na faculdade, realizando todos os processos como a extração de requisitos dos usuários, desenvolvendo, testes finais e treinamento. Experiência em processamento de imagens e áudios, trabalhando com a extração e classificação de sinais de áudio de voz através do mestrado. E experiência na área de secretariado e docência do ensino superior e técnico.</p>

<a href="www.linkedin.com/in/fernanda-ribeiro-49a08a204" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 


