# Paulo Henrique Rodrigues de Araujo
Olá, meu nome é Paulo Henrique Rodrigues de Araujo, estou fazendo um bootcamp na plataforma DIO

## Objetivos
Pretendo trabalhar na área de dados e atualmente estou no 3º período de Ciência da Computação e em busca de minha primeira oportunidade de estágio.

## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
Postgresql
Power Bi

## Perfil DIO
[Paulo Araujo](https://web.dio.me/users/phrod_devp?tab=skills)

## Contato:
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/paulo--araujo/)