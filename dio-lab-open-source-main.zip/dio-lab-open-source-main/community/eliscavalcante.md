
# Elis Cavalcante 

Meu nome é Elisabeth e estou estudando Ciência de dados para me adaptar à profissão do futuro ,e assim poder fazer parte desta grande revolução tecnológica  que trás muitas oportunidades de desenvolvimento profissional e pessoal devido ao seu grande dinamismo e possibilidade de conhecer pessoas que de fato querem mudar o mundo com suas criações,assim como eu.

# Sigam-me os bons!
[![LinkedIn](https://img.shields.io/badge/LinkedIn-fff?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/elisabeth-cavalcante-500a8969//)

# Github Stats

![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=anuraghazra&theme=prussian_icons=true)


