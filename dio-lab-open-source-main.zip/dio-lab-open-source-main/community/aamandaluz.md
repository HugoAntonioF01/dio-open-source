
# Hello World

Meu nome é Amanda sou de Belo Horizonte - MG, sou engenheira de alimentos e estou ingressando na área de tecnologia.

Atualmente sou estudante de Ciência da Computação e estou desenvolvendo minhas habilidades em Python e Power BI com foco na análise de dados.


## 🔗 Conecte-se Comigo

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/amanda-regina-ferreira-da-luz-ba9370210/)
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://web.dio.me/users/amandareginaluz?tab=skills)

