# Hello, a todos apaixonados pelo Fantástico Mundo da Tecnologia ...

## Me chamo Rafael da Silva, tenho 38 anos, sou casado e resido em Erechim RS.
### Trabalho como PCM de Manutenção a 15 anos sou formado em eletroeletrônica Industrial e em Tecnologia em Gestão de Produção Industrial. Em 2021 iniciei o meu processo de transição de carreira para a área de Ti, com enfâse em Backend.
#### Estou cursando o último semestre Análise e desenvolvimento de sistemas ADS.
#### E no ùltimo semestre finalizei meu MBA em Engenharia de Software.

## Desde então venho conhecendo, estudando e práticando linguagens de programação voltado ao Backend como:
### Python ![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) 
### Java: ![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
#### No ano 2023 iniciei cursos voltados a área de Dados, Machine Learn.

### Um grande abraço, a quem ler essa menssagem e lembre-se  .

# Todos os dias em que nos dedicamos ao que gostamos, ganhamos 1% a mais de conhecimento, não desistam nunca, pois estamos a posso de encontrar o que sonhamos.

### Conecte-se comigo:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/linkedin.com/in/rafael-d-62a7a81a6/)
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discord.com/in/rafaelsilva1984/)
[![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github&logoColor=)](https://github.com/RafaelDaSilva1984)
