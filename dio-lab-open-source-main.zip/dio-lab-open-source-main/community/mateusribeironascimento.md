# DIO | Mateus Ribeiro

Tenho 25 anos, moro em João Pessoa-PB.

## Objetivo
- Arrumar um emprego na área de TI como desenvolvedor back-end

## Tecnologias dominadas
- No momento estudo Python

## Futuras Ações
- Me especializar na linguagem Python
- Aprender novas tecnologias

## Links
[Github](https://github.com/mateusribeironascimento)
[LinkedIn](https://www.linkedin.com/in/mateusribeironascimento/)