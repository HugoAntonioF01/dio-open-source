<div id="header" align="center">
  <img src="https://i.ibb.co/MgZs7mw/gitbanner.jpg"/>
</div>

<br>

## Hi there 👋 I'm Daniele

<br>

<img src="https://camo.githubusercontent.com/63371d36886ee658f5a97401f393e1ab1684b2fd3de674b8f5efc7d410b2a3d0/68747470733a2f2f6d656469612e67697068792e636f6d2f6d656469612f57556c706c634d704f43456d5447427442572f67697068792e676966" width="30"/> I'm currently a BTech Computer Systems Analysis student from Brazil.<br>
<img src="https://media.giphy.com/media/QB58ZP0duR41RYH4Lk/giphy.gif" width="30"/> I have a background in Veterinary Medicine and Graphic Design.<br>
<img src="https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExOGVldXBkbjdiaWJ1emg4eDg4NG0yN3U4dGJtdTQwNmk3aDh2aTRkNyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/1xOPeoGeRWn5JIpuIm/giphy.gif" width="30"> I am interested especially in Data Engineering/Science, Back-end Development, System Analysis, Risk Analysis, Epidemiology, Animal Welfare & Behaviour, and Food Safety.<br>
<img src="https://media.giphy.com/media/M0XX5oAZq4L4tmLpTt/giphy.gif" width="30"/> And I love all things cats.<br>

<br>

##

<br>

<div id="badges" align="center">
  <img src="https://img.shields.io/badge/Python-FFD43B?style=for-the-badge&logo=python&logoColor=blue"/>
  <img src="https://img.shields.io/badge/OpenJDK-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white"/>
  <img src="https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E"/>
  <br>
  <img src="https://img.shields.io/badge/VSCode-0078D4?style=for-the-badge&logo=visual%20studio%20code&logoColor=white"/>
  <img src="https://img.shields.io/badge/IntelliJ_IDEA-000000.svg?style=for-the-badge&logo=intellij-idea&logoColor=white"/>
  <br>
  <img src="https://img.shields.io/badge/Canva-%2300C4CC.svg?&style=for-the-badge&logo=Canva&logoColor=white"/>
  <img src="https://img.shields.io/badge/Notion-000000?style=for-the-badge&logo=notion&logoColor=white"/>
  <img src="https://img.shields.io/badge/Trello-0052CC?style=for-the-badge&logo=trello&logoColor=white"/>
  <img src="https://img.shields.io/badge/Microsoft_Office-D83B01?style=for-the-badge&logo=microsoft-office&logoColor=white"/>
</div>

##

<div id="views counter" align="center">
  <img src="https://komarev.com/ghpvc/?username=unbestimmt&style=flat-square&color=blue" alt=""/>
 </div>

 <br><br>

 <div id="footer" align="center">
  <img src="https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNzAwNzQzMDE0NDE4OGY1MzhhYWJlNzNlOTk1MWIwM2MzYWUxZDRhYiZlcD12MV9pbnRlcm5hbF9naWZzX2dpZklkJmN0PWc/XTSAu52BAHuAYB7BB6/giphy.gif"/>
</div>
