# Enzzo Natan Ferraz

## Sobre Mim
Olá! Me chamo Enzzo e sou um fascinado por tecnologia e design. Moro na cidade de Florianópolis, tenho 20 anos e desde cedo, descobri minha paixão por essas áreas e tenho me dedicado a aprimorar minhas habilidades. Estou constantemente buscando oportunidades para aprender e crescer profissionalmente nesses campos fascinantes. 

[![LinkedIn](https://img.shields.io/badge/linkedin-0E6305?style=for-the-badge&logo=Linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/enzzo-ferraz)

[![LinkedIn](https://img.shields.io/badge/GitHub-0E6305?style=for-the-badge&logo=GitHub&logoColor=0E76A8)](https://github.com/EnzzoNatan)

## Habilidades
![Java](https://img.shields.io/badge/Java-0E6305?style=for-the-badge&logo=java)

![HTML5](https://img.shields.io/badge/HTML5-0E6305?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-0E6305?style=for-the-badge&logo=css3&logoColor=264CE4)



## GitHub Status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=EnzzoNatan&theme=transparent&bg_color=0E6305&border_color=09E500&show_icons=true&icon_color=ffff&title_color=ffff&text_color=6DE03F&hide_title=true&hide=stars)



