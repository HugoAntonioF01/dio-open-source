# Oderlan Freire
Olá, sou Oderlan, atualmente sou graduando de Sistemas de Informação e estou seguindo na trilha de engenharia de dados para formação profissional.

## 🔗 Conecte-se comigo
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor)](https://www.linkedin.com/in/oderlanfs/)

## 🛠 Habilidades
> - Python
> - Java
> - C
> - C++
> - Javascript
> - HTML
> - CSS
> - Django
> - SQL
> - GCP

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=oderlanfreire&show_icons=true&hide_title=true&hide=stars&cache_seconds=86400&theme=midnight-purple)

<div>
    <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=oderlanfreire&theme=midnight-purple"/>
<div>
