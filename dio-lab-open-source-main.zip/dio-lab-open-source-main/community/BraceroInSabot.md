<h1 align="center">Sobre mim</h1>

<h2>
-> Guilherme Bracero <br>
-> Desenvolvedor de Software
</h2>
<br>
<p>Sou interessado por TI há algum tempo, tô sempre aprendendo coisas novas na internet. Python é a linguagem que eu mais domino porém, com força de vontade suficiente eu posso aprender novas (tô aprendendo R rsrs). No meu tempo livre, quando não estou estudando eu: adoro Deus ou socializo com pessoas ou toco guitarra ou fico vendo memes. Essa é praticamente a minha rotina. </p>

<br>


<br>

```python

class Programador(Pessoa):
    
    def setUp(self):
        self.name = "Guilherme Bracero"
        self.title = "Software Engineer"
        self.languages = {
            "Python": "Intermediary",
            "R": "Basic",
            "SQL": "Basic",
            } 
        self.frameworks = {
            "Django": "Intermediary",
        }
        self.tools = [
            "Git",
            "Docker",
            "PostgreSQL"
        ]
        self.available = True

    def aboutme(self)
        title = str(self.title.title())
        ...

```


<h1 align="center"> Tech Stacks </h1>


<div align="center">
    <img src="https://img.shields.io/badge/-Python-05122A?style=flat&logo=Python"></img>
    <img src="https://img.shields.io/badge/-Django-05122A?style=flat&logo=django"></img>
    <img src="https://img.shields.io/badge/-Postgres-05122A?style=flat&logo=postgresql"></img>
    <img src="https://img.shields.io/badge/-Docker-05122A?style=flat&logo=docker"></img>
    <img src="https://img.shields.io/badge/-Git-05122A?style=flat&logo=git"></img>
    <img src="https://img.shields.io/badge/-Html-05122A?style=flat&logo=html5"></img><br><br>
    <img width="30%" height="30%" src="https://github-readme-stats.vercel.app/api/top-langs/?username=BraceroInSabot&layout=compact&theme=synthwave&title_color=D9299B&border_color=F27F3D" alt="my most used languages"/><br><br>
</div>

<h1 id="social-medias" align="center" >Redes</h1>

<br>

<p align="center">
  <a href="https://www.linkedin.com/in/guilherme-bracero/" target="_blank">
    <img align="center" src="https://img.shields.io/badge/-Guilherme Bracero-05122A?style=flat&logo=linkedin" alt="linkedin"/>
  </a>
  <a href="https://www.instagram.com/guilhermebracero/" target="_blank">
   <img align="center" src="https://img.shields.io/badge/-guilhermebracero-05122A?style=flat&logo=instagram" alt="instagram"/>
  </a>
  <a href="https://www.facebook.com/guilherme.bracerogonzales/" target="_blank">
   <img align="center" src="https://img.shields.io/badge/-Guilherme Bracero Gonzales-05122A?style=flat&logo=facebook" alt="facebook"/>
  </a>
</p>

<!--
**BraceroInSabot/BraceroInSabot** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->
