# Marcos Sousa

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=m-sousa&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085) 

![.NET](https://img.shields.io/badge/.net-black?style=for-the-badge&logo=dotnet)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript) 

![Oracle](https://img.shields.io/badge/oracle-black?style=for-the-badge&logo=oracle)

![Microsoft SQL Server](https://img.shields.io/badge/microsoft_sql_server-black?style=for-the-badge&logo=microsoftsqlserver)

![MongoDB](https://img.shields.io/badge/mongodb-black?style=for-the-badge&logo=mongodb)

## Entre em contato
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/sousamarcos/)