# Olá, eu sou o Ramon Campos! 👋
<!---
## 🧑🏻‍💻 Sobre mim
--->
## 🔗 Links

![Perfil DIO](https://img.shields.io/badge/MEU_PERFIL_NA_DIO-30A3DC?style=for-the-badge&link=https%3A%2F%2Fweb.dio.me%2Fusers%2Framon_campos)
![LinkedIn](https://img.shields.io/badge/LinkedIn-292524?style=for-the-badge&logo=linkedin&logoColor=0A66C2&link=https%3A%2F%2Fweb.dio.me%2Fusers%2Framon_campos)
![Email](https://img.shields.io/badge/E--mail-292524?style=for-the-badge&logo=maildotru&link=https%3A%2F%2Fweb.dio.me%2Fusers%2Framon_campos)

## 🛠️  Habilidades

![Python](https://img.shields.io/badge/Python-292524?style=for-the-badge&logo=python&link=https%3A%2F%2Fweb.dio.me%2Fusers%2Framon_campos)
![SQL](https://img.shields.io/badge/SQL-292524?style=for-the-badge&logo=microsoftsqlserver&logoColor=CC2927&link=https%3A%2F%2Fweb.dio.me%2Fusers%2Framon_campos)
![Power BI](https://img.shields.io/badge/Power_BI-292524?style=for-the-badge&logo=powerbi&link=https%3A%2F%2Fweb.dio.me%2Fusers%2Framon_campos)
![MS Excel](https://img.shields.io/badge/Excel-292524?style=for-the-badge&logo=microsoftexcel&logoColor=217346&link=https%3A%2F%2Fweb.dio.me%2Fusers%2Framon_campos)
![WordPress](https://img.shields.io/badge/WordPress-292524?style=for-the-badge&logo=wordpress&logoColor=21759B&link=https%3A%2F%2Fweb.dio.me%2Fusers%2Framon_campos)
![HTML](https://img.shields.io/badge/HTML-292524?style=for-the-badge&logo=html5&link=https%3A%2F%2Fweb.dio.me%2Fusers%2Framon_campos)
![CSS](https://img.shields.io/badge/CSS-292524?style=for-the-badge&logo=css3&link=https%3A%2F%2Fweb.dio.me%2Fusers%2Framon_campos)
![Git](https://img.shields.io/badge/git-292524?style=for-the-badge&logo=git&link=https%3A%2F%2Fweb.dio.me%2Fusers%2Framon_campos)
![GitHub](https://img.shields.io/badge/GitHub-292524?style=for-the-badge&logo=GitHub&link=https%3A%2F%2Fweb.dio.me%2Fusers%2Framon_campos)

<!---
##  GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ramon-campos&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=ramon-campos&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
--->

## Meus Principais Desafios de Projeto

[![Chinook Database](https://github-readme-stats.vercel.app/api/pin/?username=ramon-campos&repo=chinook-database&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/ramon-campos/chinook-database)
