
# About Me.

🐱‍👤

Hi, my name is Bruno Marx, please do not confuse with Bruno Mars. 

# Studies

📚  I am currently studying History at UFU. But I've always had a foot in technology, you know I'm one of the children of the 2000s who grew up in front of a computer.

My first jobs were as a computer teacher in small schools in my city, where I had contact with HTML, CSS, JAVASCRIPT and a little bit of C and C#, all very basic.

# Goals

I believe that the present moment is opportune for me to progress and explore development further. Primarily, I am intrigued by the realm of data analysis and artificial intelligence.
