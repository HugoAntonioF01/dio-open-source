# Juliana Fernandes Belletati

👋 Olá, 

Sou estudante do quarto semestre de Ciência da Computação e Fisioterapeuta em transição de carreira.

📈 Me interesso muito por cálculos, resolução de problemas e análises.

Tenho uma filha de 7 anos e meu grande desafio é conciliar todas as minhas tarefas em equilibrio. Me esforço com muito amor ❤️

### Contribuições no GitHub

[![GitHub Streak](https://streak-stats.demolab.com/?user=Belletati&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)


Conecte-se comigo!

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/juliana-belletati-8876056)

