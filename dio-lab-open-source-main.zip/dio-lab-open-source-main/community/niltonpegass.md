<h1 align="center">
    <a href="https://www.dio.me/">
        <img align="center" width="40px" src="https://hermes.digitalinnovation.one/assets/diome/logo-minimized.png">
    </a>
    Nilton Pegas
</h1>

<div align="right">

[![Facebook](https://img.shields.io/badge/Facebook-%231877F2.svg?logo=Facebook&logoColor=white)](https://facebook.com/https://www.facebook.com/niltonpegass/)
[![Instagram](https://img.shields.io/badge/Instagram-%23E4405F.svg?logo=Instagram&logoColor=white)](https://instagram.com/niltonpegass)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-%230077B5.svg?logo=linkedin&logoColor=white)](https://linkedin.com/in/https://www.linkedin.com/in/niltonpegass)
[![Email](https://img.shields.io/badge/gmail-%23E4405F.svg?logo=Gmail&logoColor=white)](mailto:niltonpegas@id.uff.br)
</div>


## SOBRE MIM:
<div align="justify">
Sou formado em Engenharia Mecânica pela Universidade Federal Fluminense. Sempre amei tecnologia e me encontrei na área de Dados. Estou finalizando uma pós-graduação em Análise de Dados e Inteligência de Negócios e já pensando nos próximos passos com Ciência de Dados.
</div>

## IDIOMAS:
- Português
- Inglês (Intermediário)
- Alemão (Iniciante)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=niltonpegass&layout=compact&bg_color=000&border_color=30A3DC&title_color=30A3DC&text_color=FFF)
