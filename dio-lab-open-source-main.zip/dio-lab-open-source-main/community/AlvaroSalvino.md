# AlvarSalvino 

Olá! Sou Alvaro Salvino, um estudante entusiasmado do curso de Jogos Digitais e apaixonado por desenvolvimento e programação. Atualmente, tenho a oportunidade de trabalhar como auxiliar administrativo em uma clínica oftalmológica em Teresina - PI, onde também atuo como Técnico de Informática. Além disso, tenho uma pequena empresa que oferece serviços de web design, com foco em criação de sites utilizando a plataforma WordPress.

Com minha formação em Jogos Digitais, adquiri conhecimentos sólidos em áreas como design de jogos, programação, modelagem 3D e animação. Tenho habilidades técnicas e criativas que me permitem desenvolver projetos inovadores e envolventes.

No meu trabalho como auxiliar administrativo, utilizo minha expertise em tecnologia para otimizar processos, gerenciar sistemas e garantir a eficiência operacional. Também sou responsável por oferecer suporte técnico aos colaboradores, solucionando problemas relacionados a computadores, redes e softwares.

Obrigado por conhecer um pouco mais sobre mim. Estou ansioso para explorar novas possibilidades e projetos emocionantes juntos!





