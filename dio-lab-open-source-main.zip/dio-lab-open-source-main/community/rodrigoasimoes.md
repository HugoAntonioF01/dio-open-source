# RODRIGO ALVES SIMÕES

## UM POUCO SOBRE MIM :blush:
- Graduado em Letras e cursando pós-graduação em Engenharia de Dados :sweat_smile:
- Apaixonado por tecnologias Open Source 💻;
- Apaixonado por Artes Marciais :martial_arts_uniform:; 
- Apaixonado por música, literatura, natureza e cultura popular brasileira. :heart_eyes:

## APRENDENDO :books:
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5) ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4) ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)


## CONTATO
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/rodrigoalvessimoes/)
