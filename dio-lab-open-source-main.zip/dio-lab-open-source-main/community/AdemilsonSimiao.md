##### Name:

# Ademilson Simião
I'm Full Stack Developer, by Simiao Express since 2019.
I worked as an IT Technician for 10 years.

### Hard Skills
![HTML](https://img.shields.io/badge/HTML-red)
![CSS](https://img.shields.io/badge/CSS-blue)
![JS](https://img.shields.io/badge/JavaScript-yellow)
![PHP](https://img.shields.io/badge/PHP-darkblue)
![SQL](https://img.shields.io/badge/SQL-orange)

### Soft Skills
![Communicative](https://img.shields.io/badge/Communicative-red)
![Proactive](https://img.shields.io/badge/Proactive-blue)
![Organized](https://img.shields.io/badge/Organized-red)
![Empathetic](https://img.shields.io/badge/Empathetic-blue)

### Social Media
[![Perfil DIO](https://img.shields.io/badge/DIO/PERFIL-darkblue)](https://web.dio.me/users/biassistencia)
[![LINKDIN](https://img.shields.io/badge/Linkdin-blue)](https://www.linkedin.com/in/ademilson-simiao-950656171/)
[![GitHub](https://img.shields.io/badge/GitHub-black)](https://github.com/AdemilsonSimiao)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AdemilsonSimiao&theme=transparent&bg_color=013&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AdemilsonSimiao&layout=compact&bg_color=013&border_color=30A3DC&title_color=E94D5F&text_color=FFF)