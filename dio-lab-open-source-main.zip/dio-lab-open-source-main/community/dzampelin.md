<header>
<h1> <strong>Oi, meu nome é Daniel Zampelin!</strong>
<img align = "left" alt= "Title-icon" height = "40" width = "40" src="https://cdn.discordapp.com/attachments/798631748421943347/1125951976807600200/icons8-stormtrooper-512.png"/> </h1>

<img align="right" alt="Atry-gif" height="120" width="120" src="https://cdn.discordapp.com/attachments/798631748421943347/1125935695228326028/dzampelinGIF.gif">

<p> 
<img align = "left" alt= "Title-icon" height = "30" width = "30" src="https://cdn.discordapp.com/attachments/798631748421943347/1125950245692514304/001-light-saber.png"/> <i>Especialista em Análise de Dados.</i> 
  
<img align = "left" alt= "Title-icon" height = "30" width = "30" src="https://cdn.discordapp.com/attachments/798631748421943347/1125950246011273277/002-death-star.png"/> <i>Estudando Python, Data Science e Data Analysis.</i>

<img align = "left" alt= "Title-icon" height = "25" width = "25" src="https://cdn.discordapp.com/attachments/798631748421943347/1125952448150917120/icons8-star-wars-512.png"/> <i>E-mail para contato: danielzampelin@gmail.com</i>
</p>
</header>

<div>
  <a href="https://github.com/dzampelin">
  <img height="160em" src="https://github-readme-stats.vercel.app/api?username=dzampelin&show_icons=true&theme=radical&include_all_commits=true&count_private=true"/>
</div>

  
<div style="display: inline_block"><br>
  <h2 align = "left"> Linguagens e Ferramentas </h2>
  <img align="center" alt="Dz-Python" height="45" width="45" src="https://cdn.discordapp.com/attachments/798631748421943347/1125953059005157376/icons8-python-512.png">
  <img align="center" alt="Dz-MySQL" height="60" width="60" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original-wordmark.svg">
</div>
  
<div>
  <h2 align = "left"> Conecte-se Comigo!  </h2>
  
  <a href="https://www.linkedin.com/in/danielzampelin/" target="_blank"><img src="https://cdn.discordapp.com/attachments/798631748421943347/1125953058766065694/icons8-linkedin-circled-512.png" target="_blank" height="30" width="30"></a> 
   
</div>