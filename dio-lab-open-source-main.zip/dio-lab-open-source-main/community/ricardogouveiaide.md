# Ricardo Gouveia Ide
Olá Sou o Ricardo e estou fazendo o tutorial de colaboração do github. Realizando o primeiro commit
## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/rgouveiaide/)
## Habilidades
[![GitHub](https://img.shields.io/badge/GitHub-ec63a?style=for-the-badge&logo=github&logoColor=fff)](https://docs.github.com/)
[![Git](https://img.shields.io/badge/Git-ec63a?style=for-the-badge&logo=git&logoColor=fff)](https://git-scm.com/doc) 

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ricardogouveiaide&theme=transparent&bg_color=ec63a1&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=fff&hide_title=true&hide=stars)
## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=ricardogouveiaide&repo=dio-lab-open-source&bg_color=ec63a1&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=fff)](https://github.com/octoeli/dio-lab-open-source)