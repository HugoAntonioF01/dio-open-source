### Olá 👋

![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=endobrasil&show_icons=true&theme=cobalt)
[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=endobrasil&hide_progress=false)]

<!--https://github.com/anuraghazra/github-readme-stats-->

**endobrasil/endobrasil** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on SEDUC, voluntário no Greenpeace e Casa do saber
- 🌱 I’m currently learning BI, Data Scientist, postura sustentável, vida saudável
- 👯 I’m looking to collaborate on um mundo melhor
- 🤔 I’m looking for help with Desenvolvimento da humanidade
- 💬 Ask me about qualquer coisa
- 📫 How to reach me: endobrasil@gmail.com; [![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/endobrasil/)
- ⚡ Fun fact: A existência só existe na minha cabeça...

