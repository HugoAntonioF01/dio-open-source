
# Edson Mokiu Yabiku
- Formado em Matemática e cursando Ciência de dados atualmente.
- Trabalho como dev em C#/SQL. Tentando fazer a transição para área de Ciência de dados/Análise de dados.

#


### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/edsonmy/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:edsonmy@hotmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/edsonmy/)

#


### Habilidades
<div style="display: inline_block">
  <img align="center" heigth="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg" />
  <img align="center" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" /> 
  <img align="center" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-plain.svg">
  <img align="center" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg">
  <img align="center" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg">
</div>

#



### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=edsonmy&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=edsonmy&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

#


### Meus Principais Desafios de Projeto DIO
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=edsonmy&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/edsonmy/dio-lab-open-source)


