# Wesley Marcos 

Oi eu sou Wesley Mais conhecido como Rasta

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/wrasta/)
[![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/wesley.wrasta/)
[![Twitter](https://img.shields.io/badge/Twitter-000?style=for-the-badge&logo=twitter)](https://twitter.com/RealwRasta)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/rasta.wesley/)


## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=RastaWesley&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## TOP Linguagens

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=RastaWesley&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

