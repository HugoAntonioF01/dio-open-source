## Thais Garcia 
Sou formada pela Etec Jacinto Ferreira de Sá em Técnico em Desenvolvimento de Sistemas, onde também concluí o Ensino Médio com Qualificação Profissional de Administrador de Banco de Dados. 
Como uma jovem profissional em constante evolução, estou sempre em busca de novos conhecimentos e tecnologias para aprimorar minhas habilidades e me destacar no mercado de trabalho.

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000000?style=for-the-badge&logoColor=30A3DC)](https://web.dio.me/users/thaisgarcia_t11/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=gmail&logoColor=E94D5F)](mailto:thaisgarcia.t11@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/thais-garcia11/)
[![Instagram](https://img.shields.io/badge/-Instagram-000?style=for-the-badge&logo=instagram&logoColor=E94D5F)](https://www.instagram.com/tha_grc)

### Habilidades
![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![C#](https://img.shields.io/badge/CSharp-000?style=for-the-badge&logo=csharp&logoColor=A020F0)
![PHP](https://img.shields.io/badge/PHP-000?style=for-the-badge&logo=php)
![C++](https://img.shields.io/badge/C++-000?style=for-the-badge&logo=cplusplus&logoColor=4169E1)
![MySql](https://img.shields.io/badge/MySql-000?style=for-the-badge&logo=mysql)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Power BI](https://img.shields.io/badge/Power_BI-000?style=for-the-badge&logo=powerbi)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)](https://docs.github.com/)

### GitHub Stats
<img height="180em" src="https://github-readme-stats.vercel.app/api?username=thaisgarcia&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF"/> <img height="180em" src="https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=thaisgarcia&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF"/>

### Meus Principais Projetos
[![Biblioteca Escolar](https://github-readme-stats.vercel.app/api/pin/?username=thaisgarcia&repo=biblioteca-escolar&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/thaisgarcia/biblioteca-escolar)
[![Portfólio](https://github-readme-stats.vercel.app/api/pin/?username=thaisgarcia&repo=portfolio&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/thaisgarcia/portfolio)
