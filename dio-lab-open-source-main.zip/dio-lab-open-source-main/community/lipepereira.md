### Olá! Eu sou o Felipe Pereira, seja muito bem-vindo(a)!

- 🌱 Estudando Python, Git e Banco de dados
- 😄 Futuro Programador
- ⚡ 19 years

<div style="display: inline_block">
  <a href="https://github.com/lipepereira">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=lipepereira&show_icons=true&theme=github_dark&include_all_commits=true&count_private=true"/>
</div>
<br>
  
##
  
<div>
  <a href="https://www.linkedin.com/in/felipe-pereira-99a083208/" target="_blank"><img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
  <a href="mailto:lipepereira1903@gmail.com" target="_blank"><img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://t.me/Phelip_saantos" target="_blank"><img src="https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white" target="_blank"></a>
  <a href="https://www.instagram.com/lipepereira1903/" target="_blank"><img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  
 
</div>