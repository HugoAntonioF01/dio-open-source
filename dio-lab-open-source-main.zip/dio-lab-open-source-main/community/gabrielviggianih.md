### Olá, meu nome é Gabriel Viggiani. 😃

- Estou começando agora no curso de engenharia de software.
- Não possuo muitas coisas para compartilhar por agora, então é isso!! 🙃
- Segue algumas redes minhas. ;D

[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/gabriel_viggiani)
[![Linkedin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/gabrielviggiani/)

 <div>
   <a href="https://github.com/gabrielviggianih">
   <img height="180em" src="https://github-readme-stats.vercel.app/api?username=gabrielviggianih&show_icons=true&theme=vision-friendly-dark&include_all_commits=true&count_private=true"/>
   <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=gabrielviggianih&layout=compact&langs_count=6&theme=vision-friendly-dark"/>

</div>
<div style="display: inline_block"><br>
  <img align="center" alt="Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
</div>
 
 <br>


</div>