# Davi Stalleiken

Graduado em Análise e Desenvolvimento de Sistemas, atualmente estudando e buscando trabalho em desenvolvimento web Full Stack. Meu foco é Next.Js, React, React Native, Typescript e Cypress.

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/davi-stalleiken/)

## Habilidades

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript)

![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)

![React Native](https://img.shields.io/badge/React-Native-000?style=for-the-badge&logo=React-Native)

## Github Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=DaviStalleiken&theme=dracula&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

[![Davi Stalleiken's GitHub stats](https://github-readme-stats.vercel.app/api/top-langs?username=DaviStalleiken&hide=html,scss,stylus,blade,jupyter%20notebook,python,css,shell,batchfile,dockerfile,javascript&theme=dracula&show_icons=true)](https://github.com/DaviStalleiken)



