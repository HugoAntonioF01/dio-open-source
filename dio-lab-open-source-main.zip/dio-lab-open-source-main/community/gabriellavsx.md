
# About me

Hello, my name is Maria Gabriella Victor and I am currently a Software Engineering student at the Federal Technological University of Paraná in Brazil.



### Technologies I have experience
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)


![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=gabriellavsx&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)


![GitHub Stats](https://github-readme-stats.vercel.app/api?username=gabriellavsx&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


### Contact Me
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/maria-gabriella-victor/)