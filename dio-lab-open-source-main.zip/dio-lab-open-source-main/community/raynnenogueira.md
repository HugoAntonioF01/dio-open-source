# Raynne Nogueira
Sou estudante de Sistemas de Informação, tenho 23 anos e estou em busca do seu primeiro emprego na área.
Sou uma pessoa dedicada e trabalho muito bem em equipe, valorizando a colaboração e a troca de ideias. Além
disso, possuo habilidades em HTML, CSS e alguns ambiente como o Figma, o que me torna apto a desenvolver
design de interfaces. Minha determinação em aprender e crescer na carreira são características que certamente
contribuirão para o meu sucesso profissional

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/raynne-nogueira/)
[![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github&logoColor=0E76A8)](https://www.linkedin.com/in/raynnenogueira/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/raynnenogueira/)


## Habilidades
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://docs.github.com/)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=fff)](https://git-scm.com/doc) 
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![Sass](https://img.shields.io/badge/Sass-000?style=for-the-badge&logo=sass)



## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=raynnenogueira&repo=descubraAFruta&bg_color=7A46B3&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=fff)](https://github.com/raynnenogueira/descubraAFruta)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=raynnenogueira&repo=projeto&bg_color=7A46B3&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=fff)](https://github.com/raynnenogueira/projeto)