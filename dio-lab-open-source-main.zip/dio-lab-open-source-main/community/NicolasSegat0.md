### Bem vindo, sou Nicolas Navas! 👋

- 🔭 Estou cursando Análise e Desenvolvimento de Sistemas na Faculdade de Engenharia de Sorocaba (FACENS). 
- 🌱 Iniciando no mundo da tecnologia e programação. 
- 💬 Contato: ninavassegato@gmail.com 
- 👔 Linkedin: https://www.linkedin.com/in/nicolas-navas-segato-2ba431232/

<div align="center">
  <a href="https://github.com/NicolasSegat0">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=NicolasSegat0&show_icons=true&theme=dark&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=NicolasSegat0&layout=compact&langs_count=7&theme=dark"/>
</div>
 
 <img align="center" alt="Nicolas-Python" height="60" width="80" 
   src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="Nicolas-Java" height="60" width="80" 
   src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-plain.svg">
   
  
  
