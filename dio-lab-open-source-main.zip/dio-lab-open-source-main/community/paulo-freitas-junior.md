
<center><h1><font color=\".FFFAFA\"> Olá, seja bem-vindo(a) </font> </h1></center>

  

> "And be a simple kind of man..Oh, be something you love and understand” - Simple Man - **Lynyrd Skynyrd**

>

  
<br>
<h2><font color=\".#BC8F8F\">Sobre o Paulo...</font></h2>

  

---

  

Me chamo **Paulo Roberto L. de F. Junior**, nascido em Dezembro de 1976, brasileiro das Minas Gerais mas que vive em São Paulo. Sou um apaixonado pela Pesca Esportiva (Se liga no octo alí no avatar…), músico frustrado mas mesmo assim apaixonado pelo bom e velho Rock and Roll e pelo Blues, que tem gostos simples, que adora a natureza e gosta de se aventurar nela quando é possível. Que adora animais tanto que tenho 3 pets sendo uma cadela SRD chamada Sharon “Osbourne”, e dois gatos um chamado Freddie “Mercury” e a outra destruidora de móveis se chama Luna.

  

Esse é basicamente o Paulo em seus momentos de lazer.

  

Aproveita e já se conecta ai…
<br>



  [![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/juniorpaulo/) [![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/paulofreitasjunior) [![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/paulo.robertojunior.90/) [![Twitter](https://img.shields.io/badge/Twitter-000?style=for-the-badge&logo=twitter)](https://twitter.com/PauloRLFJR) [![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/paulo.robertojunior.90) [![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/paulo-freitas-junior)
  
<br>

<h2><font color=\".#BC8F8F\">Profissionalmente</font></h2>

  

---

  

Profissionalmente atuo com tecnologia desde meus 16 anos de idade, começando por um colegial técnico em Processamento de Dados onde tive contato com as linguagens Cobol, Clipper, e Visual Basic !!! ( É.. já deu para sacar que faz tempo isso…) mas que logo em seguida seguiu para um Bacharelado em Administração com Hab. em Análise de Sistemas, turma de formandos de 2003, que foi onde tive contato com a linguagem Java (novidade na época) e onde descobri minha paixão por Base de Dados tendo contato com produtos da Oracle e onde comecei a me tornar um analista de dados (mas não tinha esse nome na época não.. tá…) usando tecnologias como SQL, Excel.

  

Até que em 2003 resolvi me tornar um empreendedor na área de tecnologia e entretenimento até os dias hoje. Porém o desejo de voltar a trabalhar com Dados voltou a crescer desde o início da Pandemia do Covid-19 e foi justamente nesse período de mudanças que resolvi seguir à diante e pesquisar cursos de Graduação e Tecnológicos na área.

  

E aqui estou.



  


<br>

<h2><font color=\".#BC8F8F\"> Tecnologias </font></h2>

---

<br>


![PostgreeSQL](https://img.shields.io/badge/PostgreSQL-000?style=for-the-badge&logo=PostgreSQL&logoColor=30A3DC) ![Oracle](https://img.shields.io/badge/Oracle-000?style=for-the-badge&logo=Oracle&logoColor=E94D5F)

 ![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python&logoColor=30A3DC) ![R](https://img.shields.io/badge/R-000?style=for-the-badge&logo=r&logoColor=30A3DC) ![SQL](https://img.shields.io/badge/Sql-000?style=for-the-badge&logo=Sql&logoColor=30A3DC)

 ![PowerBi](https://img.shields.io/badge/PowerBi-000?style=for-the-badge&logo=PowerBi&logoColor=FF8C00) ![Excel](https://img.shields.io/badge/Excel-000?style=for-the-badge&logo=MicrosoftExcel&logoColor=008000)

  [![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=DC143C)](https://git-scm.com/doc) [![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)  



<br>

<h2><font color=\".#BC8F8F\"> GitHub Status </font></h2>

---

<br>

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=paulo-freitas-junior&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=#0000FF&text_color=FFF) [![GitHub Streak](https://streak-stats.demolab.com?user=paulo-freitas-junior&theme=nord)](https://git.io/streak-stats)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=paulo-freitas-junior&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
