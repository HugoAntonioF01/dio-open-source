# Clébio

Meu nome é Clébio,estou cursando Engenharia de software,estou me especializando em python para realocação profissional.

## Habilidades
## Linguagens de Marcação e Estilo
<table>
  <thead>
    <tr align="left">
      <th>Badge</th>
      <th>Markdown</th>
    </tr>
  </thead>
  <tbody align="left">
    <tr>
      <td>
        <img align="center" alt="Markdown" src="https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown">
      </td>
      <td>
        <code>tenho conhecimento médio</code>
      </td>
    </tr>
    <tr>
      <td>
        <img align="center" alt="HTML5" src="https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5">
      </td>
      <td>
        <code>tenho conhecimento médio</code>
      </td>
    </tr>
    <tr>
      <td>
        <img align="center" alt="CSS3" src="https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4">
      </td>
      <td>
        <code>tenho conhecimento médio</code>
      </td>
    </tr>
    
  </tbody>
  <tfoot></tfoot>
</table>

## Linguagens de Programação
<table>
  <thead>
    <tr align="left">
      <th>Badge</th>
      <th>Markdown</th>
    </tr>
  </thead>
  <tbody align="left">
    <tr>
      <td>
        <img align="center" alt="JavaScript" src="https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript">
      </td>
      <td>
        <code>tenho conhecimento médio</code>
      </td>
    </tr>
       <tr>
      <td>
        <img align="center" alt="Java" src="https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java">
      </td>
      <td>
        <code>tenho conhecimento básico</code>
      </td>
    </tr>
    <tr>
      <td>
        <img align="center" alt="Python" src="https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python">
      </td>
      <td>
        <code>tenho conhecimento maior </code>
      </td>
    </tr>
    <tr>
      <td>
        <img align="center" alt="C" src="https://img.shields.io/badge/C-000?style=for-the-badge&logo=c">
      </td>
      <td>
        <code>tenho conhecimento básico</code>
      </td>
    </tr>
    <tr>
      <td>
        <img align="center" alt="C++" src="https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C">
      </td>
      <td>
        <code>tenho conhecimento básico</code>
      </td>
    </tr>
    <tr>
      <td>
        <img align="center" alt="C#" src="https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085">
      </td>
      <td>
        <code>tenho conhecimento básico</code>
      </td>
    </tr>
  </tbody>
  <tfoot></tfoot>
</table>

## Bibliotecas e Frameworks
<table>
  <thead>
    <tr align="left">
      <th>Badge</th>
      <th>Markdown</th>
    </tr>
  </thead>
  <tbody align="left">
    <tr>
      <td>
        <img align="center" alt="React" src="https://img.shields.io/badge/React-000?style=for-the-badge&logo=react">
      </td>
      <td>
        <code>tenho conhecimento médio</code>
      </td>
    </tr>
    <tr>
    <tr>
      <td>
        <img alt="14713matplotlib-logo-7107377" class="alignnone entered lazyloaded" src="https://datapeaker.com/wp-content/uploads/2021/08/14713matplotlib-logo-7107377.png" width="70" height="45" data-lazy-src="https://datapeaker.com/wp-content/uploads/2021/08/14713matplotlib-logo-7107377.png" data-ll-status="loaded">
      </td>
      <td>
        <code>tenho conhecimento médio</code>
      </td>
    </tr>
    <tr><tr>
      <td>
        <img alt="49277numpy-3369553" class="alignnone entered lazyloaded" src="https://datapeaker.com/wp-content/uploads/2021/08/49277numpy-3369553.png" width="75" height="50" data-lazy-src="https://datapeaker.com/wp-content/uploads/2021/08/49277numpy-3369553.png" data-ll-status="loaded">
      </td>
      <td>
        <code>tenho conhecimento médio</code>
      </td>
    </tr>
    <tr>
  </tbody>
  <tfoot></tfoot>
</table>

## Conecte-se comigo
[![GitHub](https://img.shields.io/badge/GitHub-ec63a1?style=for-the-badge&logo=github&logoColor=000)](https://github.com/Clebiotalves)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/clebioteodoroalves)
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/ct_alves/)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Clebiotalves&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Clebiotalves&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

### Minha Contribuição no projeto
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=edsonmy&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/edsonmy/dio-lab-open-source)