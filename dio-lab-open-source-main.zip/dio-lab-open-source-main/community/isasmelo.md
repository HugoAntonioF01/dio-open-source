# Sobre mim
 Olá! Meu nome é Isabela, tenho 24 anos e sou de Teresina-PI. Sou uma estudante curiosa. Estou sempre buscando novos desafios e formas de aplicar minhas habilidades. Possuo graduação em andamento em Engenharia Elétrica, mas também tenho e nutro interesse em desenvolvimento de software. Por isso, faço cursos e bootcamps de programação para me atualizar e aperfeiçoar as minhas competências.

## 📚 **Aprendendo**

[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4) ![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![JavaScript](https://img.shields.io/badge/JavaScript%20-000?style=for-the-badge&logo=javascript&logoColor=ffff00) 

# 📊 GitHub Stats:
![](https://github-readme-stats.vercel.app/api/top-langs/?username=isasmelo&theme=react&hide_border=false&include_all_commits=false&count_private=false&layout=compact)

## 🔗 Conecte-se Comigo

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](www.linkedin.com/in/isabelamelosiq)
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://web.dio.me/users/isabelamelos15?tab=skills)
