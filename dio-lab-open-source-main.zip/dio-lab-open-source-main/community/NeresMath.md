# Matheus Neres

Eu sou Matheus Neres e moro em Taboão da Serra/SP. Sou Economista de formação e estou cursando MBA em Data Science & Analytics.
Atualmente trabalho em uma Seguradora na área de Estratégia.

## 🛠️ Habilidades


<p>
    <a href="#"><img alt="Power Apps" src="https://img.shields.io/badge/Power%20Apps-742774?logo=powerapps&logoColor=white"></a>
    <a href="#"><img alt="Power BI" src="https://img.shields.io/badge/Power%20BI-F2C811.svg?logo=powerbi&logoColor=black"></a>
    <a href="#"><img alt="R Studio" src="https://img.shields.io/badge/R%20Studio-276DC3.svg?logo=rstudio&logoColor=white"></a>
    <a href="#"><img alt="Microsoft Excel" src="https://img.shields.io/badge/Microsoft%20Excel-217346?logo=microsoftexcel&logoColor=white"></a>
    <a href="#"><img alt="Git" src="https://img.shields.io/badge/Git-F05033.svg?logo=git&logoColor=white"></a>
    <a href="https://github.com/search?q=user%3Avitorkol+language%3Apython"><img alt="Python" src="https://img.shields.io/badge/Python-14354C.svg?logo=python&logoColor=white"></a>
    <a href="https://github.com/search?q=user%3Avitorkol+language%3Ar"><img alt="R" src="https://img.shields.io/badge/R-276DC3.svg?logo=r&logoColor=white"></a>
    <a href="https://github.com/search?q=user%3Avitorkol+language%3Asql"><img alt="SQL" src="https://custom-icon-badges.herokuapp.com/badge/SQL-025E8C.svg?logo=database&logoColor=white"></a>
</p>



## Contatos

[![DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://web.dio.me/users/matheusdn_santos?tab=skills) 
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=fff)](https://www.linkedin.com/in/matheus-neres-/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/NeresMath)

