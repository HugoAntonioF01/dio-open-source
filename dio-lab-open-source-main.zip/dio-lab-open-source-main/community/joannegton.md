
![Wellington](https://avatars.githubusercontent.com/u/72559274?s=96&v=4)
# Wellington Tavares

### Professor de matemática com um grande foco em educação, todavia com um **hobby** de estudar Hardware e Software para fins pessoais e para que eu possa colaborar com o aprendizado de crianças e adolescentes que não conhecem sobre.

# Entre em contato:
[![LinkedIn](https://img.shields.io/badge/LinkedIn-6e0a78?style=for-the-badge&logo=linkedin&logoColor=000)](https://www.linkedin.com/in/wellington-tavares-galbarini-21b915a9/)

[![Instagram](https://img.shields.io/badge/Instagram-6e0a78?style=for-the-badge&logo=instagram&logoColor=000)](https://www.instagram.com/joanne_gton/)

[![Facebook](https://img.shields.io/badge/Facebook-6e0a78?style=for-the-badge&logo=facebook&logoColor=000)](https://www.facebook.com/profile.php?id=100004390482855/)

# O que estou aprendendo:
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)

![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)


## O que geralmente uso:
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=joannegton&layout=compact&bg_color=000&border_color=6e0a78&title_color=6e0a78&text_color=FFF)
[![GitHub Streak](https://streak-stats.demolab.com/?user=joannegton&theme=bear&background=000&border=6e0a78&dates=6e0a78)](https://git.io/streak-stats)



