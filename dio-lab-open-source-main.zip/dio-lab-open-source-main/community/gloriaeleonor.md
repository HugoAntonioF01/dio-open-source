# **README | Glória**
## **Sobre mim**
Me cadastrei na comunidade online DIO esse ano (2023) para participar de um evento com palestras sobre data science. Tenho interesse nessa área e em desenvolvimento web.

Atualmente, estou aprimorando meu conhecimento em Javascript e revisitando conceitos de Python.

Meus aspectos preferidos da tecnologia são a ampla variedade de funções e a possiblidade de interseção com múltiplas áreas (saúde, comércio etc.).

## **Habilidades**
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)


## **Github Stats**
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=gloria&theme=tokyonight&bg_color=1A1B27&border_color=30A3DC&show_icons=true&icon_color=BB94F2&title_color=6295D9&text_color=38BDAE&hide=stars)