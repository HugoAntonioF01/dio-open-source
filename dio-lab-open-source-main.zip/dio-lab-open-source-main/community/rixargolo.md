<h1 align="center">Olá👋, Seja bem-vindo ao meu perfil :)</h1>

<h4 align="center">Estou há muito tempo na área de Tecnologia da Informação, mas só recentemente resolvi me dedicar àquilo que me despertou para esse mundo que é a programação.</h3>

<h3 align="left">Conecte-se comigo:</h3>
<p align="left">
<a href="https://linkedin.com/in/ricardoargolo" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="ricardoargolo" height="30" width="40" /></a>
</p>

<h3 align="left">Linguagens e ferramentas:</h3>
<p align="left">
<a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> 
<a href="https://www.mysql.com/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original-wordmark.svg" alt="mysql" width="40" height="40"/> </a> 
<a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> </a> 
<a href="https://git-scm.com/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="40" height="40"/> </a>
<a href="https://www.arduino.cc/" target="_blank" rel="noreferrer"> <img src="https://cdn.worldvectorlogo.com/logos/arduino-1.svg" alt="arduino" width="40" height="40"/> </a> 
</p>

<p><img align="center" src="https://github-readme-stats.vercel.app/api/top-langs?username=rixargolo&show_icons=true&locale=en&layout=compact" alt="rixargolo" /></p>

<p><img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=rixargolo&" alt="rixargolo" /></p>

