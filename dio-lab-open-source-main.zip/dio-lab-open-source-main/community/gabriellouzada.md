# Gabriel Louzada Araújo

Investigador das relações humanas através da linguagem. Apaixonado por tecnologia, programação, ciência e análise de dados. *PT-BR | ENG*

## Conecte-se comigo

[![Todos as Redes](https://img.shields.io/badge/Todas_as_redes-red)](https://taggo.one/gabriellouzada)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&color=blue)](https://www.linkedin.com/in/gabriellouzadasga/)

## Habilidades
![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&color=white)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&color=white)](https://git-scm.com/doc)
[![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python&color=white)](https://git-scm.com/doc) 

## Meu artigo na DIO

[Nuvem de Palavras com Python para Amantes de Literatura](https://web.dio.me/articles/nuvem-de-palavras-com-python-para-amantes-de-literatura?back=%2Farticles&page=1&order=oldest)