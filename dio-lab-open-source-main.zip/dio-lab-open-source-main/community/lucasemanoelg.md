# **Lucas Gonçalves**

Olá, sou estudando de Engenharia de Computação, trabalho como técnico de telecomunicações. Sou apaixonado por tecnologia, e a minha grande área na programação é o backend.

### Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/goncalves_lucasemanoel/)
[![E-mail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:goncalves.lucasemanoel@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-blue?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/lucas-emanoel-goncalves)

### Habilidades

![JAVA](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java&logoColor=white)
![Spring](https://img.shields.io/badge/Spring-000?style=for-the-badge&logo=spring&logoColor=white)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=spring&logoColor=white)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
![Github](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)
![MySQL](https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white)

### GitHub Stats
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=lucasemanoelg&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=lucasemanoelg&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

### Meus Principais Projetos
[![Programa em python para a remoção de aplicativos pré instalados na MIUI.](https://github-readme-stats.vercel.app/api/pin/?username=lucasemanoelg&repo=Xiaomi-Debloater&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/lucasemanoelg/Xiaomi-Debloater)
[![Repositório para exercícios de estrutura de dados em Java](https://github-readme-stats.vercel.app/api/pin/?username=lucasemanoelg&repo=estrutura-de-dados-java&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/lucasemanoelg/estrutura-de-dados-java)