# Edimaron Almeida

Estudante de Engenharia da Computação na Universidade Virtual do Estado de São Paulo, Bahiano com passagens pelo Rio de Janeiro e Rio Grande do Sul, agora residindo atualmente em Votorantim/SP, fome por adquirir conhecimentos na área de programação e de dados, apaixonado por jogos de estratégia.  

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/edimaron-almeida/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/edimaronalmeida/)

## Habilidades 

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)

## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=edimaron&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=BLUE&text_color=FFF)

## GitHub Most Used Languages

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=edimaron&bg_color=000&border_color=30A3DC&title_color=BLUE&text_color=FFF)


## Minha Contribuições

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=edimaron&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=BLUE&text_color=FFF)](https://github.com/edimaron/dio-lab-open-source)

[![GitHub Streak](https://streak-stats.demolab.com/?user=edimaron&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/edimaron)