
# carolina_dias



Sou Carolina, e resolvi aos 30 anos mudar totalmente de carreira e me aventurar na TI.





## Redes Sociais

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/carolinasdias/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/cadias2/)

## Linguagens de Programação

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)




## GitHub Stats


[![GitHub Streak](https://streak-stats.demolab.com/?user=SEUUSERNAME&theme=bear&background=000&border=30A3DC&dates=FFF)](https://github.com/carolinasdias)



