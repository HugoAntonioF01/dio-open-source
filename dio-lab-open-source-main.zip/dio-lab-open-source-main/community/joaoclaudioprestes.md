<p align="center">
  <img src="https://i.pinimg.com/564x/3b/d0/05/3bd0059a46f4044bd0efd98b9e6cd994.jpg" width="100%">
</p>

<h2 align="center">Olá, este sou eu João Claudio e este é o meu perfil! <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="28"></h2>

## 📞 Contato
<<<<<<< HEAD
=======

>>>>>>> 24ff4eb655f96d79bec5468d49df40214cf9be3a
<p>
  <a href="https://instagram.com/jpres_tes" target="_blank">
    <img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" alt="Instagram target="_blank"">
  </a>
  <a href="https://discord.gg/j_prestes" target="_blank">
    <img src="https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white" alt="Discord" target="_blank">
  </a>
  <a href="mailto:joaoprestes17@outlook.com">
    <img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" alt="Email" target="_blank">
  </a>
  <a href="https://www.linkedin.com/in/jo%C3%A3o-claudio-prestes" target="_blank">
    <img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn" target="_blank">
  </a>
</p>

## 🚀 Sobre Mim
<<<<<<< HEAD
| Sou estudante de Ciência da Computação focado em Desenvolvimento Front-end, pronto para mergulhar no mundo profissional. Tenho uma verdadeira paixão por criar interfaces incríveis e interativas que deixam os usuários impressionados. | ![Imagem Sobre Mim](https://cdn.picrew.me/shareImg/org/202307/137904_xOHhz9pE.png) |
| --- | --- |

## 💻 Tecnologias
=======

| Sou estudante de Ciência da Computação focado em Desenvolvimento Front-end, pronto para mergulhar no mundo profissional. Tenho uma verdadeira paixão por criar interfaces incríveis e interativas que deixam os usuários impressionados. | ![Imagem Sobre Mim](https://cdn.picrew.me/shareImg/org/202307/137904_xOHhz9pE.png) |
| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- |

## 💻 Tecnologias

>>>>>>> 24ff4eb655f96d79bec5468d49df40214cf9be3a
<div align="center">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg" alt="JavaScript" height="30" width="40">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg" alt="TypeScript" height="30" width="40">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg" alt="React" height="30" width="40">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg" alt="HTML" height="30" width="40">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg" alt="CSS" height="30" width="40">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="Python" height="30" width="40">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/csharp/csharp-original.svg" alt="C#" height="30" width="40">
</div>

## <img src="https://github.com/fluidicon.png" alt="Git Icon" width="24" height="24" style="vertical-align: middle;"> Github Stats
<<<<<<< HEAD
=======

>>>>>>> 24ff4eb655f96d79bec5468d49df40214cf9be3a
<p align="center">
  <img src="https://github-readme-stats.vercel.app/api?username=joaoclaudioprestes&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF" alt="GitHub Stats">
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=joaoclaudioprestes&layout=compact&theme=dracula&hide_border=true&bg_color=0D1117&title_color=CC6699&icon_color=CC6699" alt="Top Langs">
</p>
