# Hello there, I'm Fabiano Thimotheo

### I'm currently an undergraduate "Data Science" and "Computer Science" student

### Thank you for your time! You're welcome to come back here anytime you want! 

---

## **📊 GitHub Stats**

<div align="center">

![TopLangs](https://github-readme-stats.vercel.app/api/top-langs/?username=Fabiano-Thimotheo&theme=nord&layout=compact&hide_border=true)

</div>

---

## Tech Stack:

### <img src="https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript" alt="JavaScript" style="zoom:150%;" /> 

### <img src="https://img.shields.io/badge/html5-E34F26.svg?style=for-the-badge&logo=html5&logoColor=white" alt="HTML5" style="zoom:150%;" /> 

#### <img src="https://img.shields.io/badge/css3-1572B6.svg?style=for-the-badge&logo=css3&logoColor=white" alt="CSS3" style="zoom:150%;" />  

### <img src="https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python" style="zoom:150%;" />

### <img src="https://img.shields.io/badge/Pandas-2C2D72?style=for-the-badge&logo=pandas" alt="Pandas" style="zoom:150%;" />

### <img src="https://img.shields.io/badge/Numpy-777BB4?style=for-the-badge&logo=numpy&logoColor=white" alt="Numpy" style="zoom:150%;" />

### <img src="https://img.shields.io/badge/mysql-00f.svg?style=for-the-badge&logo=mysql&logoColor=white" alt="MySQL" style="zoom:150%;" />

### <img src="https://img.shields.io/badge/sqlite-07405e.svg?style=for-the-badge&logo=sqlite&logoColor=white" alt="SQLite" style="zoom:150%;" />

### <img src="https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=white" alt="Linux" style="zoom:150%;" />



<img src="C:\Users\janat\Favorites\Downloads\GITHUB_LOGO.jpg" alt="GITHUB_LOGO" style="zoom:50%;" />

<img src="C:\Users\janat\Favorites\Downloads\GIT_Logo 2.jpg" alt="GIT_Logo 2" style="zoom:10%;" />

