# José Felipe
Minha principal motivação para trabalhar com estatística é constantemente lembrar que os dados não se limitam a números. Eles são narrativas não contadas que requerem interpretação adequada. Cada conjunto de dados representa histórias diversas, que envolvem vidas individuais, fenômenos naturais e uma infinidade de outros eventos. Se eu tivesse que resumir a essência da estatística em duas palavras, seria "contar histórias".




## Habilidades em:
![R](https://img.shields.io/badge/R-000?style=for-the-badge&logo=R)
![Google Cloud](https://img.shields.io/badge/Google_Cloud-000?style=for-the-badge&logo=google-cloud)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![tidyverse](https://img.shields.io/badge/tidyverse-000?style=for-the-badge&logo=R)
![ggplot2](https://img.shields.io/badge/ggplot2-000?style=for-the-badge&logo=R)
![shiny](https://img.shields.io/badge/shiny-000?style=for-the-badge&logo=R)
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)

## GitHub Streak 
[![GitHub Streak](https://streak-stats.demolab.com?user=josefelipe0036&theme=ambient-gradient)](https://git.io/streak-stats)


## Linguagens mais usadas
![ ](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=josefelipe0036&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/jos%C3%A9-felipe-83154397/)


