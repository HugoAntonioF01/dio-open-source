## - 👋 Olá, eu sou o Caio Felipe!
- 👮‍♂️ Atualmente estou na Força Aérea Brasileira.
- 📚 Formado em Análise e Desenvolvimento de Sistemas.
- 🎮 Gosto de Jogos.

 
 ## Conecte-se comigo
 
<div> 
  <a href="https://instagram.com/c.felipev" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href = "caiocfvc@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/caio-carv/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
 
</div>

## GitHub Stats

<div align="center">
  <a href="https://github.com/CaioCarv">
  <img height="160rem" src="https://github-readme-stats.vercel.app/api?username=CaioCarv&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
  <img height="160rem" src="https://github-readme-stats.vercel.app/api/top-langs/?username=CaioCarv&layout=compact&langs_count=7&theme=tokyonight"/>
</div>

## ⚡ Tecnologias

<div style="display: inline_block"><br>
  <img align="center" alt="Caio-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Caio-HTML"  height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Caio-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Caio-Python" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" />
  <img align="center" alt="Caio-MySQL" height="30" width= 40" src="https://img.icons8.com/color/48/000000/mysql-logo.png"/>
  <img align="center" alt="Caio-django" height="30" width= 40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/django/django-plain.svg"/>
 

</div>