# Hello World, I'm Luis Cristofolli 😎

- Olá! Sou uma pessoa dedicada aos estudos, especialmente na área de programação. Tenho conhecimento em Unity 2D e sou apaixonado por Game Design. Além disso, estou me aprofundando no campo da inteligência artificial e ciência de dados. Atualmente, estou trabalhando em projetos pessoais, colaborando com duas sócias para o desenvolvimento de um jogo. Sou um entusiasta das tecnologias e acredito no poder delas em facilitar nossas vidas, otimizando tarefas repetitivas. Estou sempre em busca de aprender mais e explorar o potencial que a tecnologia oferece.

-==========================================================================================-


## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/luis-cristofolli/)



## Habilidades

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) &nbsp;
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085) &nbsp; 
![Unity](https://img.shields.io/badge/Unity-100000?style=for-the-badge&logo=unity&logoColor=white) &nbsp;
![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)

-==========================================================================================-

## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=luisCristofolli&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF) 

[![GitHub Streak](https://streak-stats.demolab.com/?user=luisCristofolli&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)
