# 💫 About Me:
### [![Typing SVG](https://readme-typing-svg.herokuapp.com?duration=5011&color=CFCECB&center=falso&vCenter=falso&lines=Ol%C3%A1+%F0%9F%91%8B+seja+Bem-vindo(a);ao+meu+perfil+Fernando-S-Santos)](https://git.io/typing-svg)

[![](https://visitcount.itsvg.in/api?id=Fernando-S-Santos&icon=0&color=0)](https://visitcount.itsvg.in)
<!-- Proudly created with GPRM ( https://gprm.itsvg.in ) -->
##

### ✍️ Random Dev Quote
![](https://quotes-github-readme.vercel.app/api?type=horizontal&theme=tokyonight)

##

# 📊 GitHub Stats:
![](https://github-readme-stats.vercel.app/api?username=Fernando-S-Santos&theme=react&hide_border=false&include_all_commits=false&count_private=false)<br/>
![](https://github-readme-streak-stats.herokuapp.com/?user=Fernando-S-Santos&theme=react&hide_border=false)<br/>
![](https://github-readme-stats.vercel.app/api/top-langs/?username=Fernando-S-Santos&theme=react&hide_border=false&include_all_commits=false&count_private=false&layout=compact)

<h2 align="left">💻 Tech Stack:</h2>
<div style="display: inline_block"><br>
  <img align="center" alt="Fer-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg ">
  <img align="center" alt="Fer-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg ">
  <img align="center" alt="Fer-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg ">
  <!--<img align="center" alt="Fer-Ts" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg">-->
  <img align="center" alt="Fer-React" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
  <img align="center" alt="Fer-Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="Fer-Bootstrap" height="30" width="110" 
src="https://img.shields.io/badge/bootstrap-%23563D7C.svg?style=for-the-badge&logo=bootstrap&logoColor=white">
</div>
 
##

<h2 align="left">Connect with me | 🌐 Socials:</h2>
<div>
<p align="left">
  <a href="https://www.linkedin.com/in/fernando-s-santos/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
  <a href="https://instagram.com/fernando__s.santos" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href = "mailto:ferssantos33@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://discord.com/channels/@Fernando693#8067" target="_blank"><img src="https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white" target="_blank"></a>
 
![Snake animation](https://github.com/Fernando-S-Santos/Fernando-S-Santos/blob/output/github-contribution-grid-snake.svg)
</div>
