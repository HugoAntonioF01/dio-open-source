# Kaio Pablo 

Apaixonado pela tecnologia e pelos avanços causados pela mesma na sociedade. Busco aprender cada dia mais, visando a evolução e aperfeiçoamento de minhas habilidades afim de otimizar processos com a programação, desenvolver melhores soluções para problemas, criar ferramentas úteis para mim e para o próximo no dia a dia.

### Contatos 

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/kaiopablo44)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/kaio-martins-6319741b0/)
[![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Dhaxx)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:kaiopablo44@gmail.com)

### Proeficiências

![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white)
![Flask](https://img.shields.io/badge/flask-%23000.svg?style=for-the-badge&logo=flask&logoColor=white)

### Github Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Dhaxx&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Dhaxx&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)