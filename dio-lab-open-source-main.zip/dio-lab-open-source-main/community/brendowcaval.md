# Brendow Cavalcante

Sou alagoano, tenho 25 anos e um tremendo fã de Senhor dos Anéis, atualmente gosto bastante da área de back-end, onde vi com C# e .NET, desejo seguir nessa área e trabalhar nela, ou quem sabe ser um full stack.


## Conecte-se comigo : 
[![Github](https://img.shields.io/badge/github-000?style=for-the-badge&logo=github&logoColor=0E76A8)](https://github.com/brendowcaval)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/brendow-cavalcante-717588223/)


## Habilidades : 
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)
![SQl](https://img.shields.io/badge/Mysql-000?style=for-the-badge&logo=mysql&logoColor=823085)



## Github Stats : 

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=brendowcaval&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=brendowcaval&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)