<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=1F618D&height=120&section=header"/>

[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=2471A3&size=35&center=true&vCenter=true&width=1000&lines=OLÁ,+MEU+NOME+É+HENRIQUE+MESSIAS+DOS+SANTOS;TENHO+25+ANOS+E+ATUO+NA+ÁREA+DE+DADOS+HÁ+3+ANOS+:%29)](https://git.io/typing-svg)

<div align="center">  
  <img width="49%" height="195px" src="https://github-readme-stats.vercel.app/api?username=HenriqueMessias&show_icons=true&count_private=true&hide_border=true&title_color=2471A3&icon_color=00bfbf&text_color=A3A214&bg_color=0d1117" alt="Mateus Franco Gonçalves github stats" /> 
  <img width="41%" height="195px" src="https://github-readme-stats.vercel.app/api/top-langs/?username=HenriqueMessias&layout=compact&hide_border=true&title_color=A3A214&text_color=A3A214&bg_color=0d1117" />
</div>

<div align="center"> 
<a href = "mailto:henrique.messiasit@outlook.com"> <img src="https://img.shields.io/badge/-Email-%23333?style=for-the-badge&logo=gmail&logoColor=A3A214" target="_blank"></a>
<a href="https://www.linkedin.com/in/henrique-messias-santos/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" style="border-radius: 30px" target="_blank"></a> 
 </div>


### Toolbox:
![Python](https://img.shields.io/badge/-Python-0D1117?style=for-the-badge&logo=python&labelColor=0D1117)&nbsp;
![SQL](https://img.shields.io/badge/-SQL-0D1117?style=for-the-badge&logo=mysql&labelColor=0D1117&textColor=0D1117)&nbsp;
![PowerBi](https://img.shields.io/badge/-PowerBi-0D1117?style=for-the-badge&logo=powerbi&labelColor=0D1117&textColor=0D1117)&nbsp;
![Excel](https://img.shields.io/badge/-Excel-0D1117?style=for-the-badge&logo=microsoftexcel&labelColor=0D1117&textColor=0D1117)&nbsp;

<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=1F618D&height=120&section=footer"/>
