# Meu Perfil

## Sobre

Olá, me chamo Raimundo Azevedo e sou graduando em Engenharia de Computação. Gosto de resolver problemas, estudá-los e avaliar qual o melhor curso de ação seguir para resolvê-los.

Durante a graduação aprendi bastante, mas esses tópicos foram para mim um "divisor de águas": Estruturas de Dados, Análise de Algoritmos, Programação Orientada a Objetos, Design Patterns e Inteligência Computacional. Essas disciplinas me levaram a enxergar um novo horizonte de possibilidades que me ajudaram a avaliar os problemas de forma mais analítica.

Buscarei, futuramente, me especializar nas áreas de meu interesse: Pesquisa Operacional e Otimização Combinatória.

No ambito profissional, pretendo seguir carreira em Backend mas também considero Ciência de Dados estimulante e fascinante.

No meu tempo livre gosto de estudar, ler livros, jogar videogames e assistir filmes e séries.

## Skills

<img alt="Static Badge" src="https://img.shields.io/badge/C-000?style=for-the-badge&logo=c&color=black"> <img alt="Static Badge" src="https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=cplusplus&color=black">
<img alt="Static Badge" src="https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java&logoColor=white&color=black">
<img alt="Static Badge" src="https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python&color=black">
<img alt="Static Badge" src="https://img.shields.io/badge/Django-000?style=for-the-badge&logo=django&color=black">
<img alt="Static Badge" src="https://img.shields.io/badge/MySQL-000?style=for-the-badge&logo=mysql&logoColor=white&color=black">
<img alt="Static Badge" src="https://img.shields.io/badge/Cmake-000?style=for-the-badge&logo=cmake&logoColor=white&color=black">
<img alt="Static Badge" src="https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=white&color=black">
<img alt="Static Badge" src="https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github&logoColor=white&color=black">
