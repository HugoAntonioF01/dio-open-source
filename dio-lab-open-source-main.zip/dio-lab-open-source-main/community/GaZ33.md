
# Gabriel Alexandre Pinto
Olá!! Me chamo Gabriel Alexandre Pinto, porém prefiro ser chamado por Gaze, um nickname que utilizo. Tenho 18 anos. Atualmente sou estudante, faço faculdade na Escola de Engenharia de Piracicaba (EEP), no curso de Ciências da Computação.

Fiz meu ensino médio integrado ao técnico em informática, foi de lá que surgiu minha paixão por programação. Desde então venho tentando aprender programação por cursos na internet.

## Conecte-se comigo
[![Twitter](https://img.shields.io/badge/Twitter-4acabb?style=for-the-badge&logo=twitter)](https://twitter.com/G4Z33) 
[![Instagram](https://img.shields.io/badge/Instagram-4acabb?style=for-the-badge&logo=instagram)](https://www.instagram.com/gabriel_gaz3/)
[![Instagram](https://img.shields.io/badge/GitHub-4acabb?style=for-the-badge&logo=github)](https://www.github.com/GaZ33/)
![Alt](https://img.shields.io/badge/Discord-4acabb?style=for-the-badge&logo=discord&logoColor=7289DA)

## Habilidades

![HTML5](https://img.shields.io/badge/HTML5-4acabb?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-4acabb?style=for-the-badge&logo=css3&logoColor=264CE4)
![Python](https://img.shields.io/badge/Python-4acabb?style=for-the-badge&logo=python)
![C++](https://img.shields.io/badge/C%2B%2B-4acabb?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)


## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=GaZ33&theme=transparent&bg_color=770092&border_color=a058f5&show_icons=true&icon_color=91ff95&title_color=91ff95&text_color=FFF)


