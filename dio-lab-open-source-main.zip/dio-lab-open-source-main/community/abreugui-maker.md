
# Guilherme Abreu

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/guilherme-abreu-598b75190/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/guiabreu_/)

## Habilidades

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

## Frameworks

![Tensorflow](https://img.shields.io/badge/Tensorflow-000?style=for-the-badge&logo=tensorflow)
![Tensorflow](https://img.shields.io/badge/Pytorch-000?style=for-the-badge&logo=pytorch)

## GitHub Stats
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=ABREUGUI-MAKER&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas contribuições

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=abreugui-maker&repo=games&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/SEUUSERNAME/SEUREPOSITORIO)