## 👋 Welcome to my profile!

<p align="justify">✍️ Hi, I'm Carlos A. Gonçalves. I am a Data Analyst in an automotive group in the Northeast of Brazil. Tech enthusiast and string aficionado in his spare time </p>

## 👨🏻‍💻 Technologies & tools
<img src="https://tools.avans.nl/tools/image/Ispt2s40ff.jpg" width="40" height="40"/>
<img src="https://miro.medium.com/v2/resize:fit:640/format:webp/1*KTDZHTVaVbvbyhIf2PmBAw.png" width="40" height="40"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/windows8/windows8-original.svg" width="40" height="40"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-plain.svg" width="40"
height="40"/><img src="https://agailcombr.files.wordpress.com/2020/12/pdi.png" width="40"
height="40"/><img src="https://upload.wikimedia.org/wikipedia/commons/5/50/Oracle_logo.svg" width="50"
height="40"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/github/github-original.svg" width="40" height="40"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/gitlab/gitlab-original.svg" width="40" height="40"/><img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linux/linux-original.svg" width="40" height="40"/><img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/figma/figma-original.svg" width="40" height="40"/>


 

## 📈 My Skills
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-plain.svg" width="40" height="40"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-plain.svg" width="40" height="40"/><img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-plain.svg" width="40" height="40"/>
<img src="https://tools.avans.nl/tools/image/Ispt2s40ff.jpg" width="40" height="40"/>
<img src="https://miro.medium.com/v2/resize:fit:640/format:webp/1*KTDZHTVaVbvbyhIf2PmBAw.png" width="40" height="40"/>
<img src="https://agailcombr.files.wordpress.com/2020/12/pdi.png" width="40"
height="40"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/c/c-original.svg" width="40" height="40" /><img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg" width="40" heigth="40"/><img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-plain.svg" width="40" height="40"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-original.svg" width="40" height="40"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" width="40" height="40"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" width="40" height="40" />

## 🔭 Technologies on my radar
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" width="40" height="40"/><img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-plain.svg" width="40" height="40"/><img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/anaconda/anaconda-original.svg" width="40" height="40"/>
          


## 🚀 Status
<div align="center">
<a href="https://github.com/calexmatrix">
<img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=calexmatrix&layout=compact&langs_count=7&theme=nord"/>
<img height="180em" src="https://github-readme-stats.vercel.app/api?username=calexmatrix&show_icons=true&theme=nord&include_all_commits=true&count_private=true"/>
</div>

## ✉️ Contacts
<div align="center">
<a href = "mailto:calexmatrix@gmail.com"><img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
<a href="https://www.linkedin.com/in/calexmatrix/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white"></a>   
<a href="https://wa.me/5555981056768" target="_blank"><img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"></a>
<a href="https://t.me/calexmatrix" target="_blank"><img src="https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white"></a>
<a href="https://www.instagram.com/calexmatrix/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white"></a>
</div>

<div align="center"><img src="https://www.alura.com.br/artigos/assets/como-criar-um-readme-para-seu-perfil-github/imagem15.gif"/></div>
