# Tiago Tanaka
Olá! Sou desenvolvedor junior, atualmente no ramo de Robotic Process Automation (RPA).
Cursando ultimo período de Sistemas de Informação. 

Tenho muito interesse no Python. Tentando atuar nessa area.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/tiago-tanaka-8039bb1ba/)

📧Email: tiago.tanaka.tmt@gmail.com
## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![SQL](https://img.shields.io/badge/SQL-000?style=for-the-badge&logo=SQL)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)


