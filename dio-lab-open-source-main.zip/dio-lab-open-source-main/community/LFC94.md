## Olá!! Sou o Lucas

>Olá, meu nome é Lucas Felipe Costa e nasci em 1994 na cidade de Pará de Minas. Iniciei minha carreira na área de desenvolvimento de software durante meu curso técnico em 2012/2013, e posteriormente formei em Gestão da Tecnologia da Informação pela FAPAM.

>Desde então, venho trabalhando como desenvolvedor profissionalmente desde 2013, inicialmente com Delphi para aplicações desktop e com Java para aplicações Android. Em 2017, mudei para outra empresa para trabalhar com Visual FoxPro e, em 2019, entrei para a equipe de desenvolvimento web de uma empresa de abrangência nacional, onde trabalho com linguagens como PHP (Laravel, Zend...) e Javascript (Marionette, AngularJs, React).

<a href="https://github.com/LFC94">
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=LFC94&layout=compact&langs_count=8&theme=tokyonight&locale=pt-br"/>
</a>

##
**Contatos**
 
<a href="https://www.linkedin.com/in/lucasfelipecosta" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
<a href = "mailto:contato@lfcapp.com.br"><img src="https://img.shields.io/badge/-Email-%23333?style=for-the-badge&logo=mail.ru&logoColor=white" target="_blank"></a>
<a href="https://bitbucket.org/LFC94" target="_blank"><img src="https://img.shields.io/badge/-Bitbucket-%230077B5?style=for-the-badge&logo=bitbucket&logoColor=white" target="_blank"></a>
