# Jefferson Jimenez
## 🚀 Sobre mim

Fala Devs,espero que você esteja muito bem e muito otimista nessa área maravilhosa 👨‍💻 Tech. Sou um amante de Tecnologias. Meu objetivo é me tornar um Expert em Desenvolvedor Back-end. Estudo na DIO sempre. Curso 👨‍🎓ADS na 🏫UniFatecie. **_"Nada é tão complexo que não podemos codar em linhas de comandos. ps.: jcjr"_**

### **Gostaria de Te conhecer melhor.**
Siga minhas Redes Sociais para que possamos juntos aprender muito mais sobre Programação. Te aguardo lá🤙.

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/jeffersonjimenezump)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=gmail&logoColor=E94D5F)](mailto:jeffersonjimenezump@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/jefferson-christhopher-jimenez-ribeiro-296894153/)


### Habilidades
![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=30A3DC)
![CSS](https://img.shields.io/badge/css3-000?style=for-the-badge&logo=css3&logoColor=E94D5F)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

### GitHub Stats
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=kaisy2020&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Bootcamp | DIO
- **Potência Tech powered by iFood | Ciências de Dados com Python**
![Logo](https://hermes.dio.me/tracks/49c408ad-800d-416d-b77c-681add1be673.png)
-----

### Meus Principais Desafios de Projeto DIO
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/elidianaandrade/dio-lab-open-source)

### Outro Projeto que estou envolvido
## 🔗Gerenciador de Links. 
- [Visite o Projeto Online](https://kaisy2020.github.io/Projeto_Rocketseat)
