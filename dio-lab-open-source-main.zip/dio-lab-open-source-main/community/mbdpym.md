# Hello! mbdp.ym here. :wave:


**EN-US:** My name is Matheus, currently a computer science student with a focus in data science. :computer:

**PT-BR** Meu nome é Matheus, atualmente um estudande de ciência da computação com um foco na ciência de dados. :computer:


|Social| Connect with me!|
-----------|-------------|
[![LinkedIn](https://cdn.discordapp.com/attachments/1118312260159406123/1126167540293439589/icons8-linkedin-40.png)](https://www.linkedin.com/in/matheusbilbao/)| LinkedIn, the social platform I am most active in.|


---

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Yanmew&theme=transparent&bg_color=FFF&border_color=f1a6a6&show_icons=true&icon_color=f1a6a6&title_color=f1a6a6&text_color=f1a6a6)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Yanmew&layout=compact&bg_color=FFF&border_color=f1a6a6&title_color=f1a6a6&text_color=f1a6a6)
