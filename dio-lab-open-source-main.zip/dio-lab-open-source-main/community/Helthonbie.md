# Helthon Bie
Sou estudante de Análise e Desenvolvimento de Sistemas. Estou aprendendo a fazer Análise de Dados na universidade e também em cursos extracurriculares. Atualmente faço parte do Projeto Acolher e trabalho como analista de mídias sociais na Codando. Sou comunicativo, organizado, proativo. Atualmente moro em Estocolmo (Suécia) e aqui estou tendo a oportunidade de desenvolver meu inglês. Busco uma oportunidade de utilizar as minhas habilidades que venho desenvolvendo como Analista.



I'm a student of Systems Analysis and Development. I have learned to do Data Analysis at university and in extracurricular courses as well. I am currently part of Projeto Acolher, and I work as a social media analyst at Codando. I am communicative, organized, proactive. I currently live in Stockholm (Sweden) and here I am having the opportunity to develop my English. I am looking for an opportunity to use the skills I have been developing as an Analyst.

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/helthonbie/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:helthonbie@hotmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/helthon-bi%C3%A9-33265923a/)


### Habilidades
<img align="center" alt="helthon-Python" height="60" width="60" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
<img align="center" alt="Helthon-MYSQL" height="60" width="60" src="https://d1.awsstatic.com/asset-repository/products/amazon-rds/1024px-MySQL.ff87215b43fd7292af172e2a5d9b844217262571.png">
<img align="center" alt="Helthon-postsql" height="60" width="60" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-original.svg">
<img align="center" alt="Helthon-powerbi" height="60" width="60" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/New_Power_BI_Logo.svg/2048px-New_Power_BI_Logo.svg.png">




