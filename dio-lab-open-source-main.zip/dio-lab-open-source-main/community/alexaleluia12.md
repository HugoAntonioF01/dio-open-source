

# Alex Aleluia
Tenho formação em Ciência da Computação. Me afastei da área durante a pandemia.
Pessei no concurso do Banco do Brasil na área de TI e agora estou correndo atraz do prejuizo.
Estou fazendo BootCamps na DIO. Seguindo guia de [30-Days-of-React](https://github.com/Asabeneh/30-Days-Of-React).

Tenho alguns projetos para finalizar como:
 - [Mega Sena](https://github.com/alexaleluia12/mega-sena) Gerar números para mega sena de forma acertiva.
 - [Sinal Ativos](-) Envia msg no Telegram caso o preço (Ações,Fii) atingir determinado valor.



### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/alexdiasaleluia/)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/alex-dias-835a71116/)


### Habilidades
![Python](https://img.shields.io/badge/python-blue)
![Node.js](https://img.shields.io/badge/node-blue)
![AWS](https://img.shields.io/badge/aws-blue)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
![SQL](https://img.shields.io/badge/SQL-blue)
![React](https://img.shields.io/badge/React-blue)
![HTML](https://img.shields.io/badge/HTML-blue)
![CSS](https://img.shields.io/badge/CSS-blue)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=alexaleluia12&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=alexaleluia12&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

### Meus Principais Desafios de Projeto DIO
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=alexaleluia12&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/elidianaandrade/dio-lab-open-source)
[![Repo DIO Roadmaps](https://github-readme-stats.vercel.app/api/pin/?username=digitalinnovationone&repo=roadmaps&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/digitalinnovationone/roadmaps)

### Meus Principais Artigos na DIO
<table>
  <thead>
    <tr align="left">
      <th>Data</th>
      <th>Título</th>
      <th>Link</th>
    </tr>
  </thead>
  <tbody align="left">
    <tr>
      <td>21/06/2023</td>
      <td>Prática de Algoritmos</td>
      <td align="center">
        <a href="https://web.dio.me/articles/pratica-de-algoritmos?page=1&order=oldest">
           <img align="center" alt="Artigo Escrito" src="https://img.shields.io/badge/Ler%20Artigo-30A3DC?style=for-the-badge">
        </a>
      </td>
    </tr>


  </tbody>
  <tfoot></tfoot>
</table>

---
