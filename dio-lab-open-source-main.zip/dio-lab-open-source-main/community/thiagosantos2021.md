# Sobre mim
Olá! Me chamo Thiago Santos dos Anjos, sou um estudante de Desenvolvimento Fullstack que atualmente trabalha no IBGE e gosta de passar seu tempo livre escutando música e/ou jogando videogame.

## Conecte-se Comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/thiago-santos-96a18b20b/)
[![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/thiagosantos.dosanjos/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)](https://www.github.com/thiagosantos2021/)

## Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=thiagosantos2021&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=thiagosantos2021&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Meus Projetos
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=thiagosantos2021&repo=clone_site_dio&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/thiagosantos2021/clone_site_dio)
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=thiagosantos2021&repo=Neoflix&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/thiagosantos2021/Neoflix)
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=thiagosantos2021&repo=jogo-da-memoria-DIO&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/thiagosantos2021/jogo-da-memoria-DIO)
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=thiagosantos2021&repo=Site-Sua-Essencia-Perfumes&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/thiagosantos2021/Site-Sua-Essencia-Perfumes)




