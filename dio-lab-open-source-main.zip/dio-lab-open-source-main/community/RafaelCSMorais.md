# RAFAEL MORAIS
Olá, estou iniciando meus primeiros passos na área de programação. Anteriormente atuava na área de produção Audio Visual, porém tenho grande interesse em programação, a qual oferece das grandes possibilidades.

----

# Meu progresso nos estudos com a DIO

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/rafaelcsm)



## 💻 Primeiras experiências com GitHub
  <a href="https://github.com/Jurredr/github-widgetbox">
     <img width="100%" src="https://github-widgetbox.vercel.app/api/profile?username=RafaelCSMorais&data=followers,repositories,stars,commits&theme=defult" alt="GitHub WirdgetBox" />     
  </a>
  <a href="https://github.com/vitorkol/github-readme-streak-stats">
    <img title="🔥 Get streak stats for your profile at git.io/streak-stats" alt="vitorkol's streak" src="https://github-readme-streak-stats.herokuapp.com/?user=RafaelCSMorais&theme=defult&hide_border=true"/>
  </a>

----
  
📇 Contatos!

[![E-mail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:rafaelcsm@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/rafael-morais-3a1b4535)

