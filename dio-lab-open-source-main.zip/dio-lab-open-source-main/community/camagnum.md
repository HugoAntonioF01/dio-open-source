# Carlos Magnum

## Who am I?
Hi! I'm a geophysicist and currently I'm studying web development and data science.

I've started studying programming about 11 years ago.

I've already attended HTML, CSS, JavaScript, Java and Python courses.

## Contact Me
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/magnumbenevides/)

## Skills
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)  ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)                          ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)                           ![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)  ![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=camagnum&theme=transparent&bg_color=000&border_color=FF3849&show_icons=true&icon_color=FF3849&title_color=FF3849&text_color=FFF&hide=stars&hide_title=true)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=camagnum&bg_color=000&border_color=FF3849&title_color=FF3849&text_color=FFF)
