# Olá, me chamo Cris!☕

Sobre mim:
- 📚 Sou estudante da Ciência da Computação. 
- 💻 Atualmente, iniciando os estudos sobre Análise de Dados e Data Science.
- 🇯🇵❤️🇧🇷

<div align="center">
 <h3>📊 Github Analytics</h3>
  <img width="49%" height="195px" src= "https://github-readme-stats.vercel.app/api?username=CrisNakamura&show_icons=true&theme=tokyonight" /> 
  <img width="49%" height="195px" src= "https://github-readme-stats.vercel.app/api/top-langs/?username=CrisNakamura&layout=compact&theme=tokyonight"/>
</div>

<div style="display: inline_block"><br>
  <h3>⚙️ Tools</h3>
  <img align="center" alt="Java" height="40" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg"/>
  <img align="center" alt="Python" height="40" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="Jupyter" height="40" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/jupyter/jupyter-original-wordmark.svg">
  <img align="center" alt="Pandas" height="40" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/pandas/pandas-original.svg">
  <img align="center" alt="Numpy" height="40" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/numpy/numpy-original.svg">
</div>

##

<div> 
  <h3>📍 Contatos</h3>
  <a href="https://instagram.com/nat_nakamura98/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href = "mailto:natsuminakamura98@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/cris-nakamura" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
  
</div>
