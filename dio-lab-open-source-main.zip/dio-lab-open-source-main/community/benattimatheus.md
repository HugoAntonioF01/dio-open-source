
## Hi there 👋

Welcome to my profile and I hope you like it here.
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/matheus-benatti-software-engineer/)

## Public Information

My name is Matheus Benatti and I'm a Software Engineer student. I currently live in Paraná, Brazil.

Nowadays I'm studying and improving my Web Development and Python skills.

## Detailed Information

• Name: Matheus Benatti

• Age: 19

• Living in: Curitiba - PR, Brazil

• Stack: Python - SQL - HTML - CSS

• University: Unicesumar. Software Engineering degree

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)


## Curiosities about me

• My first contact with coding was creating a Minecraft Server to play with some friends;

• I was part of an Youtuber Discord community and that's where i spoke for the first time with some developers and programmers;

• I like helping people.

##

![Matheus's GitHub stats](https://github-readme-stats.vercel.app/api?username=benattimatheus&count_private=true&show_icons=true&theme=transparent)

[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=benattimatheus&layout=compact&theme=transparent)](https://github.com/benattimatheus/github-readme-stats)
