# 🎈 João Vitor Silva

### Ola dev amigos, me chamo João Vitor, tenho 20 anos e trabalho como suporte tecnico na Policia Civil do Estado do Ceará. Estou muito animado com a ideia de aprender mais sobre o universo vasto da programação e desejo me especializar nessa área. No mais desejo bons estudos a todos!!!

# 🔗 Conecte-se comigo:
[![LinkedIn](https://img.shields.io/badge/LinkedIn-2BB21D?style=for-the-badge&logo=linkedin&logoColor=#003e4f)](https://www.linkedin.com/in/joao-vitor-silva-152213270/)

[![Instagram](https://img.shields.io/badge/Instagram-2BB21D?style=for-the-badge&logo=instagram&logoColor=#cfb590)](https://www.instagram.com/_jvitorsilva0/)


# 📚 O que estou aprendendo:
![Markdown](https://img.shields.io/badge/Markdown-2BB21D?style=for-the-badge&logo=markdown)

![JavaScript](https://img.shields.io/badge/JavaScript-2BB21D?style=for-the-badge&logo=javascript)

![Python](https://img.shields.io/badge/Python-2BB21D?style=for-the-badge&logo=python)

![HTML5](https://img.shields.io/badge/HTML5-2BB21D?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-2BB21D?style=for-the-badge&logo=css3&logoColor=264CE4)



## 🔥 GitHub stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=jvitorsilvadn&theme=transparent&bg_color=000&border_color=2BB21D&show_icons=true&icon_color=2BB21D&title_color=2BB21D&text_color=FFF)
