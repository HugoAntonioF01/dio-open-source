# 💻 Lucas Venancio - Programador FullStack
Olá! Meu nome é Lucas Venancio e tenho 33 anos. Sou apaixonado pelo mundo do desenvolvimento e estou dedicado aos estudos na DIO.

Estou aprimorando minhas habilidades na área da programação e pronto para aplicar meu conhecimento e contribuir para projetos criativos e funcionais na web.

# 📱 Contato

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/lucasvda) [![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=fff)](https://www.linkedin.com/in/lucas-venancio-973779277/) [![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram&logoColor=fff)](https://www.instagram.com/lucas.venancio.araujo/) [![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook&logoColor=fff)](https://www.facebook.com/lucas.venancio.araujo/) [![Twitter](https://img.shields.io/badge/Twitter-000?style=for-the-badge&logo=twitter&logoColor=fff)](https://twitter.com/LucasVe72464708)

# 🥷 Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5) ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4) ![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown) ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript) ![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=lucasvda&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

# 🤜🤛 Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=lucasvda&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/lucasvda/dio-lab-open-source)




