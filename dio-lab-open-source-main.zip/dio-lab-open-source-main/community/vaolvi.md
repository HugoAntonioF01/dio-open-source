# Vaolvi [![Static Badge](https://img.shields.io/badge/GitHub-000?logo=github)](https://github.com/vaolvi)

## 😁 Quem sou eu?
Olá comunidade 🖖🏼!!! Me chamo **Vanderson** e sou novo aqui no quisito uso da ferramenta. Sou da area de análise de dados e estou aqui para poder usar ainda mais e melhor essa ferramenta e o que ela proporciona para a gestão.
***
## 👨🏼‍🎓 Formação
- Engenheiro de Produção (2016) [UNIESP](https://uniesp.edu.br/sites/institucional/)
- Engenheiro da Computação (Cursando) [UNIVESP](https://univesp.br/)
***
## 📚 Habilidades
- Microsoft

    ![Static Badge](https://img.shields.io/badge/PowerBI-000?logo=powerbi&color=F2C811&logoColor=000)
    ![Static Badge](https://img.shields.io/badge/MS_Excel-000?logo=microsoftexcel&color=217346&logoColor=000)

- Google

    ![Static Badge](https://img.shields.io/badge/Looker-000?logo=looker&color=4285F4&logoColor=000)
    ![Static Badge](https://img.shields.io/badge/GTM-000?logo=googletagmanager&color=246FDB&logoColor=000)
    ![Static Badge](https://img.shields.io/badge/GA-000?logo=googleanalytics&color=E37400&logoColor=000)
    ![Static Badge](https://img.shields.io/badge/Sheets-000?logo=googlesheets&color=34A853&logoColor=000)

- Banco de dados

    ![Static Badge](https://img.shields.io/badge/MYSQL-000?logo=mysql&color=4479A1&logoColor=000)


***

## 📱 Social
[![Static Badge](https://img.shields.io/badge/LINKEDIN-000?logo=linkedin&color=0A66C2)](https://www.linkedin.com/in/vanderson-vieira-712a3167/)

***


## 📊 Estatística
Está vendo essas estatísticas aqui em baixo, espero que ela esteja melhorando, e fica a dica, use com constância!!! 🧑🏼‍💻
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=vaolvi&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)