<h1>Olá, eu sou o Marco 👋</h1>
<div>
  <h2>Seja bem vindo ao meu perfil</h2>
</div>
<div>
  <p>
    Me chamo Marco Aurélio, sou formado em Análise e Desenvolvimento de Sistemas pelo Instituto de Educação Superior de Brasília. Gosto muito de tecnologia e atualmente estou focado na área de ciência de dados, pretendo estar aprendendo muito com os cursos e bootcamps da DIO para poder contribuir em futuras empresas que me contratar.
  </p>
</div>

<div align="center">
  <a href="https://github.com/MarcoAurelioT">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=MarcoAurelioT&show_icons=false&theme=dark&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=MarcoAurelioT&layout=compact&langs_count=7&theme=dark"/>
</div>
<br>
<div>
   <a href = "mailto:mateixeira547@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/marco-aurelio-teixeira-9973aa212/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
</div>  