# Andersonspita

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/anderson-pita-8227241aa/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/dinho.pita/)

## Habilidades
[![GitHub](https://img.shields.io/badge/GitHub-ec63a1?style=for-the-badge&logo=github)](https://docs.github.com/)

[![Git](https://img.shields.io/badge/Git-ec63a1?style=for-the-badge&logo=git)](https://git-scm.com/doc)

## Github stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Andersonspita&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Andersonspita&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Andersonspita&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/SEUUSERNAME/SEUREPOSITORIO)