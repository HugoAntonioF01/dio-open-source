<h1 align="center">Olá! Eu me chamo Lucas Ramos <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="35"></h1>
<p align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&pause=1000&center=true&vCenter=true&width=435&lines=Web+Developer;Iniciante+em+Ci%C3%AAncia+de+Dados;Apaixonado+por+Tecnologia;Platina+IV+No+Lolzinho" alt="Typing SVG" /></a>
</p>

<br>
<div style="text-align: center;">

[![GitHub Streak](https://streak-stats.demolab.com?user=lucasramosdev&theme=transparent&locale=pt_BR)](https://git.io/streak-stats)

</div>

<div style="text-align: center; display: flex;">

<div style="margin: 10px">

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=lucasramosdev&theme=transparent&show_icons=true&icon_color=#00A4EF&title_color=#00A4EFtext_color=FFF)

</div>

<div style="margin: 10px">

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=lucasramosdev&layout=compact&theme=transparent&show_icons=true&icon_color=#00A4EF&title_color=#00A4EFtext_color=FFF)

</div>


</div>

<br>

## Conecte-se comigo
---

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=00A4EF)](https://www.linkedin.com/in/lucasramosdev/) [![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/lucasramosdev/) [![Portfolio](https://img.shields.io/badge/Portfolio-%23000000.svg?style=for-the-badge&logo=firefox&logoColor=#FF7139)](https://lucasramos.dev.br)
<br><br>

## Sobre mim
---

<picture> <img align="right" src="https://github.com/7oSkaaa/7oSkaaa/blob/main/Images/Right_Side.gif?raw=true" width = 250px></picture>

<br>

Meu desejo é que eu, através da tecnologia, consiga melhorar a vida de todos ao meu redor. Estou sempre ávido para aprender novas coisas, porém descontente quando tenho que sempre repetir as mesmas atividades dia após dia. 
Jogar e acompanhar as notícias sobre tecnologia são certamente os meus dois melhores hobbies. 
<br>

## Tecnologias
---
<br>

### Essas são as principais tecnologias que eu venho trabalhando atualmente

<br>

<div style="display: inline_block" align="center">
  <img align="center" alt="lucasramosdev-Ts" height="80" width="80" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg">
  <img align="center" alt="lucasramosdev-React" height="80" width="80" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
  <img align="center" alt="lucasramosdev-Nodejs" height="80" width="80" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original.svg">
  <img align="center" alt="lucasramosdev-Python" height="80" width="80" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="lucasramosdev-MongoDB" height="80" width="80" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original-wordmark.svg">
  <img align="center" alt="lucasramosdev-" height="80" width="80" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/postgresql/postgresql-original.svg">
  <img align="center" alt="lucasramosdev-Docker" height="80" width="80" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/docker/docker-original.svg">
  <img align="center" alt="lucasramosdev-Git" height="80" width="80" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/git/git-original.svg">
  <br>
  <br>
</div>