# Agente Developer
Opa, sou Agente Developer, ou Tiago, e busco pela DIO mais conhecimento e oportunidades de serviço em ADS

## Conecte-se Comigo!
[![Github](https://img.shields.io/badge/Github-357?style=for-the-badge&logo=Github&logoColor=fffff)](https://www.github.com/AgenteDeveloper)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-357?style=for-the-badge&logo=linkedin&logoColor=ffff)](https://www.linkedin.com/in/Tiago-Angeli-308395223/)


## Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS](https://img.shields.io/badge/css-000?style=for-the-badge&logo=CSS3)
![Python](https://img.shields.io/badge/PYTHON-000?style=for-the-badge&logo=python&logoColor=)
![JS](https://img.shields.io/badge/JAVASCRIPT-000?style=for-the-badge&logo=Javascript&)


## Github Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AgenteDeveloper&theme=transparent&bg_color=000&border_color=000&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFFF00&hide_title=true&hide=stars)

