# Paulo Ricardo

E ai pessoal, tudo tranquilo!? Eu sou o Paulo, sou apaixonado por tecnologia e curioso por natureza rsrs, adoro aprender novas tecnologias e estar sempre por dentro das novidades. Sou formado em Administração mas com uma boa experiência em SQL e sistemas de informação. Bora aprender ??? 📚😎

### **Conecte-se comigo**

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/paulo-ricardo-237999b6/)

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/prikrdo)

### **Habilidades** 

![Powerbi](https://img.shields.io/badge/Powerbi-000?style=for-the-badge&logo=powerbi)

![SQL](https://img.shields.io/badge/SQL-000?style=for-the-badge&logo=microsoftsqlserver)

![MySQL](https://img.shields.io/badge/MySQL-000?style=for-the-badge&logo=mysql)
### **GitHub Status**

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=prikrdo&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

#### Linguagens 
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=prikrdo&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

#### Repositórios

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=prikrdo&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/prikrdo/dio-lab-open-source)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=prikrdo&repo=processador_de_imagem&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/prikrdo/processador_de_imagem)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=prikrdo&repo=instagram-dio&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/prikrdo/instagram-dio)