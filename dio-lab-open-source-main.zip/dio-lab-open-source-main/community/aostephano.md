<h3 align="center">hey there, im alê :)</h3>

<br/>

  <img align="right" alt="GIF" src="https://i.pinimg.com/originals/57/18/5d/57185d2176d7cbaebdb74c00ce1b9ebf.gif" width="256" height="256" />

   <h4>👨🏻‍💻 About me</h4>

- 📱 FrontEnd Mobile
  - Stack: Flutter
- 💻 BackEnd Web Student
  - Stack: Django

- 👨‍🎓 **Information Systems** at **Universidade Estadual de Campinas**.

- ##### 👨‍🎓🇧🇷 **Sistemas de Informação** na **Universidade Estadual de Campinas**

<br/>

- 🔭 **Contac:**
  - 🏢 [Linkedin](https://www.linkedin.com/in/alexandre-stephano-852ab717b/)
  - 📫 Email: **<ale.stephano@gmail.com>**
  - 📋 Institutional: **<a265642@dac.unicamp.br>**

<br/>
