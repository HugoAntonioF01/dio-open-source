
![profile count](https://komarev.com/ghpvc/?username=RodrigoPdeOliveira&color=blueviolet&style=plastic) [![Linkedin Badge](https://img.shields.io/badge/-LinkedIn-blue?style=flat&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/rodrigo-oliveira-1a651017b/)](https://www.linkedin.com/in/rodrigo-oliveira-1a651017b/)

### Opa, tudo bem? <img src="https://raw.githubusercontent.com/MartinHeinz/MartinHeinz/master/wave.gif" width="30px">

*Meu nome é Rodrigo e sou um apaixonado por tecnologia, com especial interesse pelo desenvolvimento de software. Embora ainda não tenha tido a chance de colocar minhas habilidades à prova no mercado de trabalho, estou sempre buscando estudar e me aprimorar como desenvolvedor.*

<div>
<a href="https://github.com/RodrigoPdeOliveira">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=RodrigoPdeOliveira&show_icons=true&theme=dark&include_all_commits=true&count_private=true" height="160px", width="400px" />
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=RodrigoPdeOliveira&layout=compact&langs_count=7&theme=dark" height="160px", width="400px" />
</div>

 ### 📧 Contato
  
  <div>
    <a href="https://www.linkedin.com/in/rodrigo-oliveira-1a651017b/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
    <a href = "mailto:rodrikpoliveira@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  </div> 


 
   ### ⚒️ Minha stack
-   _**Linguagens**_

    <p>
      <img alt="Python" src="https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white">
      <img alt="HTML 5" src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white">
      <img alt="CSS 3" src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white">
      <img alt="JavaScript" src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=JavaScript&logoColor=white">
      <img alt="TypeScript" src="https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white">
      <img alt="C#" src="https://img.shields.io/badge/C%23-239120?style=for-the-badge&logo=c-sharp&logoColor=white">
  </p>
  
-   _**Front-end**_

    <p>
      <img height="28em" alt="Angular" src="https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white">
  </p>
  

-   _**Back-end**_

     <p>
      <img alt="Node.js" src="https://img.shields.io/static/v1?message=Node.js&logo=Node.js&labelColor=339933&color=339933&logoColor=white&label=%20&style=for-the-badge">
      <img alt="Flask" src="https://img.shields.io/badge/Flask-000000?style=for-the-badge&logo=flask&logoColor=white">
      <img alt="Express.js" src="https://img.shields.io/badge/Express.js-404D59?style=for-the-badge">
    </p>
    
-   _**Banco de dados**_

    <p>
      <img alt="MySql" src="https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white">
    </p>
    
-   _**Ferramentas**_
    <p>
      <img alt="Git" src="https://img.shields.io/static/v1?message=Git&logo=Git&labelColor=F05032&color=F05032&logoColor=white&label=%20&style=for-the-badge">
      <img alt="Visual Studio Code" src="https://img.shields.io/static/v1?message=Visual Studio Code&logo=Visual Studio Code&labelColor=007ACC&color=007ACC&logoColor=white&label=%20&style=for-the-badge">
    </p>
  
  ![Readme Quotes](https://quotes-github-readme.vercel.app/api?type=horizontal&theme=dark)

