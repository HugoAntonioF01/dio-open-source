***
<div align ="center">
  
<img src = "https://simpleicons.org/icons/affinity.svg" role="img" height="275" width="550"></img>

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Cyberpunk&weight=900&pause=1000&color=00F0FF&background=FFF10900&center=true&vCenter=true&width=435&lines=%F0%9F%92%BB+Bem+vindo+ao+meu+perfil+%F0%9F%94%B0;Meu+nome+e+Gabriel." alt="Typing SVG" /></a>

***
</div>

Eu começei a programar recentemente, seguindo a trilha de front-end. Futuramente pretendo aprender C# é focar em desenvolvimento de games.

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](www.linkedin.com/in/gabsll)
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/gabrielsr0302)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:gabrielsr0302@gmail.com)




### Estudando:

![GitHub](https://img.shields.io/badge/-GitHub-0D1117?style=for-the-badge&logo=github&labelColor=0D1117)&nbsp;
![CSS](https://img.shields.io/badge/-CSS-0D1117?style=for-the-badge&logo=CSS3&logoColor=1572B6&labelColor=0D1117)&nbsp;
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)&nbsp;
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Python](https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white)&nbsp;

![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)

***

<p align ="center">



### Tools:
![Visual Studio Code](https://img.shields.io/badge/-Visual%20Studio%20Code-0D1117?style=for-the-badge&logo=visual-studio-code&logoColor=007ACC&labelColor=0D1117)&nbsp;
![Git](https://img.shields.io/badge/-Git-0D1117?style=for-the-badge&logo=git&labelColor=0D1117)&nbsp;
![GitHub](https://img.shields.io/badge/-GitHub-0D1117?style=for-the-badge&logo=github&labelColor=0D1117)&nbsp;
![Windows](https://img.shields.io/badge/-Windows-0D1117?style=for-the-badge&logo=windows&labelColor=0D1117)&nbsp;
&nbsp;

***
<div align="center">

| *Top Langs* |*GitHub Stats*|
| :------------------ | :----------: |
| [![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Gabsll&hide=null)](https://github.com/Gabsll/github-readme-stats) |![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Gabsll&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)|

| *GitHub Streak* |*trophy*|
| :------------------ | :----------: |
| [![GitHub Streak](https://streak-stats.demolab.com?user=Gabsll&theme=neon-palenight&border_radius=10&locale=pt_BR&date_format=j%2Fn%5B%2FY%5D&mode=weekly&card_width=500&background=45%2C65DC98%2CFCEE09&border=00F0FF&stroke=00F0FF&ring=FF003C&fire=00F0FF&currStreakNum=050A0E&sideNums=050A0E&currStreakLabel=050A0E&sideLabels=050A0E&dates=050A0E&excludeDaysLabel=050A0E)](https://git.io/streak-stats) |<img src="https://github-profile-trophy.vercel.app/?username=Gabsll&theme=dracula&row=2&no-bg=true&column=3&margin-w=15&margin-h=15" />|
</div>
<div align="center">

***

[![Grafico de atividade do github de Gabsll github ](https://github-readme-activity-graph.vercel.app/graph?username=Gabsll&theme=github-compact)](https://github.com/Gabsll/github-readme-activity-graph)
</div>