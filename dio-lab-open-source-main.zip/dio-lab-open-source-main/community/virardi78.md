# André Dorta Virardi


## Sobre Mim
Atuo como QA desde 2005 com foco em testes manuais. Atualmente tenho estudado Robot Framework, Selenium e Python para tentar migrar de área.

## Rede Social:
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/andr%C3%A9-dorta-virardi-a79b5521/)

## Habilidades:
![Robot Framework](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQY6XcnTvgYfjx3Uoyv8xWhip__4dO6YVNHbT9Afoi2w&s)
![Selenium](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRLyH0gfbkrxbrgH_zkuVALb09rJikiBlGTcYZoUFUz&s)
![Python](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRekFE5Rdfuvtf_nEvcBlRlwvAn_6wlUb9HnQ&usqp=CAU)