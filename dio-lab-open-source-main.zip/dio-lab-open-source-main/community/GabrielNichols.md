# Apresentação

Olá! Eu sou um estudante de Engenharia Mecânica apaixonado por resolver problemas complexos com criatividade e determinação. Tenho habilidades em liderança e gerenciamento de projetos, adquiridas através da minha experiência como diretor de produtos do diretório acadêmico da faculdade.

Minha paixão por aplicar minhas habilidades se estende por diversas áreas, como design gráfico, front-end e data science com Python. Sempre busco soluções inovadoras para desafios desafiadores.

Além disso, tenho experiência em programação, análise de dados, estatística, design gráfico e ferramentas de produtividade. Sou fluente em inglês e tenho conhecimentos em espanhol.

No momento, estou cursando Engenharia Mecânica na Universidade Mackenzie, depois de transferir de Engenharia Mecatrônica no Insper. Também tenho experiência em programas como Python, C, HTML, CSS, JavaScript, Adobe Photoshop, Adobe Premiere, Adobe Illustrator e Office.

Estou animado para contribuir com projetos interessantes e aprender com a comunidade do GitHub. Vamos trabalhar juntos para alcançar resultados incríveis!

## Habilidades

- Resolução de problemas
- Liderança
- Gerenciamento de projetos
- Liderança de equipe
- Atendimento ao cliente
- Design gráfico
- Front-end
- Data science (Python)
- Inovação
- Programação
- Análise de dados
- Estatística
- Ferramentas de produtividade

## Idiomas

- Inglês (Fluente)
- Espanhol (Conhecimentos básicos)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-blue?style=flat-square&logo=linkedin&logoColor=white&link=https://www.linkedin.com/in/gabriel-nichols1/)](https://www.linkedin.com/in/gabriel-nichols1/)
