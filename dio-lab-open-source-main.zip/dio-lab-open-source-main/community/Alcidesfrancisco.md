### Olá devs 👋

Gosto de usar Raciocíneo lógico para criar softwares, focado mais no Back-end. gosto de games, esportes de luta e animes.

## <img width="45" alt="about" src="https://raw.github.com/elizarov/elizarov/master/about.png"> Mais sobre mim

<img align="right" width="300" src="https://i2.wp.com/allhtaccess.info/wp-content/uploads/2018/03/programming.gif?fit=1281%2C716&ssl=1" />

```kotlin
object **ALCIDES** {
 val name = "Alcides Francisco"
 val acknowledgements = "Sistemas de Informação"
 
 val primarySkillset = "Analise e desenvolvimento de sistemas,
                        resolução de problemas,
                        raciocínio lógico"
 val languages = listOf("Java", "Python", "JavaScript", "Kotlin") 

}
```

## **Linguagens e Ferramentas:**  

<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/android/android.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/kotlin/kotlin.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/java/java.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/visual-studio-code/visual-studio-code.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/git/git.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/terminal/terminal.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/html/html.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/css/css.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/mongodb/mongodb.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/mysql/mysql.png"></code>

## **GitHub Estatísticas**

<a href="https://github.com/Gurupreet">
  <img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Alcidesfrancisco&theme=dracula&hide_langs_below=1" />
</a>

<a href="https://github.com/Gurupreet">
 <img align="center" src="https://github-readme-stats.vercel.app/api?username=Alcidesfrancisco&show_icons=true&theme=dracula&line_height=27" alt="**SEU NOME** github stats"/>
</a>

[website]: https://codedev.ga/
[twitter]: https://twitter.com/
[youtube]: https://www.youtube.com/user/Alcidesfrancisco
[instagram]: https://www.instagram.com/Agentelegionario
[linkedin]: https://www.linkedin.com/in/AlcidesFrancisco
<br>

#### Rede Sociais!

🏡 [website][website] **|** 
🐦 [twitter][twitter] **|** 
📺 [youtube][youtube] **|** 
📷 [instagram][instagram] **|** 
👔 [linkedin][linkedin]

