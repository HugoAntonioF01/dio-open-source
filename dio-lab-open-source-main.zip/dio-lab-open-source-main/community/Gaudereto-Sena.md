
# Gustavo Sena
<br>

Hello there, I'm Gustavo Sena, a full stack web developer.
I started a career transition in 2019 from marine
mechanical engineer to developer, so I could explore more my logical and
problem solving skills.

<br>

## 🔗 Conect With Me

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://github.com/Gaudereto-Sena)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://https://www.instagram.com/gustavogaudereto/)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/gustavogaudereto/)

<br>

## 💻 Skills

![Typescript](https://img.shields.io/badge/typescript-000?style=for-the-badge&logo=typescript)
![Javascript](https://img.shields.io/badge/javascript-000?style=for-the-badge&logo=javascript)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)
![React Native](https://img.shields.io/badge/React_Native-000?style=for-the-badge&logo=react)
![NodeJS](https://img.shields.io/badge/nodeJS-000?style=for-the-badge&logo=node.js)
![Express](https://img.shields.io/badge/express-000?style=for-the-badge&logo=express)
![NestJS](https://img.shields.io/badge/NestJs-000?style=for-the-badge&logo=nestJs)
![MySQL](https://img.shields.io/badge/MySQL-000?style=for-the-badge&logo=MySQL)
![MongoDb](https://img.shields.io/badge/MongoDb-000?style=for-the-badge&logo=MongoDb)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=HTML5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=CSS3)
![TailWind](https://img.shields.io/badge/TailWind-000?style=for-the-badge&logo=TailWindcss)

<br>

## GitHub stats


![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Gaudereto-Sena&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)


<br>

## Main Projects

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Gaudereto-Sena&repo=Finance-Nest&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Gaudereto-Sena/Finance-Nest)
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Gaudereto-Sena&repo=dungeon-crawler&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Gaudereto-Sena/dungeon-crawler)

