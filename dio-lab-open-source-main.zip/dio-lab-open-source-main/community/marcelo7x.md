### Hi there 👋
Oi, eu sou um iniciante de programação em formação para me tornar um ciêntista de dados.

# 💻 Tech Stack
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) ![Notion](https://img.shields.io/badge/Notion-%23000000.svg?style=for-the-badge&logo=notion&logoColor=white) 

##
# 📊 GitHub Stats:
<img src="https://github-readme-stats-wheat-two-53.vercel.app/api?username=marcelo7xy&theme=neon&hide_border=false&include_all_commits=false&count_private=false"  width="364px" />                    <img src="https://github-readme-streak-stats.herokuapp.com/?user=marcelo7xy&theme=neon&hide_border=false"  width="400px" />


# 🌐 Socials:
[![Instagram](https://img.shields.io/badge/Instagram-%23E4405F.svg?logo=Instagram&logoColor=white)](https://instagram.com/olecram7xy) [![LinkedIn](https://img.shields.io/badge/LinkedIn-%230077B5.svg?logo=linkedin&logoColor=white)](https://www.linkedin.com/in/marcelo-rosa-7b5ab1281/)
  
