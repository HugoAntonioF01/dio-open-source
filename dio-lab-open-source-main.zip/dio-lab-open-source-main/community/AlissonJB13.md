# Alisson Barrabarra

Ola, sou acadêmico do 7º período do curso de Sistemas de Informação do IFPR-campus Palmas, e gosto muito de trabalhar com Flutter, Firebase, HTML, CSS, GitHub.

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alissonjb13/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/alissonjb13/)

## Habilidades

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlissonJB13&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas contribuições

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AlissonJB13&repo=Bio_If&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AlissonJB13/Bio_IF)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AlissonJB13&repo=dio-lab-open-source-fork&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AlissonJB13/dio-lab-open-source-fork)
