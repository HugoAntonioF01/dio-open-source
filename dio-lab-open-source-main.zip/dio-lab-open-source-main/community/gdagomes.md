<h1 align="center">Hi 👋, I'm Magda</h1>
<h3 align="center">I'm a Data Scientist</h3>

<br>

- 🌱 I’m currently learning **Data Science, Python and Machine Learning.**

- 👨‍💻 All of my projects are available at [https://github.com/gdagomes](https://github.com/gdagomes)

- ⚡ Fun fact **I Love cats.**

- 🥸 I have 7 years of experience with Fraud Prevention, operational analyses, monitoring of customers, and fraud identification. 
  
- 🎲 I have experience with ETL, development of scripts to tasks automation using Python, and maintenance of Databases using SQL Server and Oracle.

<br>
<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://linkedin.com/in/magda gomes" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="magda gomes" height="30" width="40" /></a>
</p>

<br>
<h3 align="left">Languages and Tools:</h3>
  <a href="https://www.microsoft.com/en-us/sql-server" target="_blank" rel="noreferrer"> <img src="https://www.svgrepo.com/show/303229/microsoft-sql-server-logo.svg" alt="mssql" width="40" height="40"/> </a> 
  <a href="https://pandas.pydata.org/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/2ae2a900d2f041da66e950e4d48052658d850630/icons/pandas/pandas-original.svg" alt="pandas" width="40" height="40"/> </a>  
  <a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> 
  <a href="https://scikit-learn.org/" target="_blank" rel="noreferrer"> <img src="https://upload.wikimedia.org/wikipedia/commons/0/05/Scikit_learn_logo_small.svg" alt="scikit_learn" width="40" height="40"/> </a> 
  <a href="https://seaborn.pydata.org/" target="_blank" rel="noreferrer"> <img src="https://seaborn.pydata.org/_images/logo-mark-lightbg.svg" alt="seaborn" width="40" height="40"/> </a> 
  <a href="https://www.tensorflow.org" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/tensorflow/tensorflow-icon.svg" alt="tensorflow" width="40" height="40"/> </a> 
  <a href="https://aws.amazon.com" target="_blank" rel="noreferrer"><img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/amazonwebservices/amazonwebservices-original-wordmark.svg" alt="aws" width="40" height="40"/> </a> 
</p>

<br>
