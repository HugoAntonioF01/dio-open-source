
# Fábio Manfredi





## 🚀 About Me
Trabalho com Editoração Gráfica há mais de 20 anos, estou começando a estudar Python, pois quero mudar de área.




## 🔗 Links
[![Meu perfil Dio](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/manfredi_di_sicilia/)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/manfs/)

[![e-mail](https://img.shields.io/badge/Email-000?style=for-the-badge&logo=microsoft-outlook
)](mailto:manfredi.di.sicilia@gmail.com)


## 🛠 Skills
Conhecimento avançado:

![Photoshop](https://img.shields.io/badge/Photoshop-000?style=for-the-badge&logo=adobephotoshop)

![Illustrator](https://img.shields.io/badge/Illustrator-000?style=for-the-badge&logo=adobeillustrator)

![InDesign](https://img.shields.io/badge/InDesign-000?style=for-the-badge&logo=adobeindesign)

![QuarkXpress](https://img.shields.io/badge/QuarkXpress-000?style=for-the-badge&logo=quarkxpress)

Iniciando:

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)