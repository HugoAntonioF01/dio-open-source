# Joao Pedro de Sanches Pinheiro

Sou João e sou apaixonado por programação, computadores e tecnologia. Desde pequeno sempre gostei muito de ficar fuçando nos códigos dos programas, mesmo que não entendesse nada, desenvolvia sites usando as ferramentas que vinha no Windows, de maneira bem amadora, mas acabava conseguindo colocá-los no ar e tudo mais, infelizmente acabei deixando essa paixão de lado conforme cresci, acabei me formando em Engenharia de Alimentos, curso que me proporcionou várias coisas mas por insatisfação pessoal nos últimos anos resolvi retomar essa paixão e comecei a estudar programaçao por conta, começando tudo do zero. Espero conseguir seguir a diante nesse sonho e que possa torná-lo no meu ganha pão.

### Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/Jotapesp/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram&logoColor=0E76A8)](https://www.instagram.com/jotapesp1/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=0E76A8)](https://github.com/jotapesp)

### Habilidades

[![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)](https://docs.python.org/)
[![Django](https://img.shields.io/badge/Django-000?style=for-the-badge&logo=django)](https://docs.djangoproject.com/en/4.2/)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

### GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=jotapesp&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=jotapesp&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
