<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=4e237e&height=120&section=header"/>

[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=4e237e&size=35&center=true&vCenter=true&width=1000&lines=OLÁ,+MEU+NOME+É+Pedro+Henrique+Aguilar+Correia;Tenho+19+anos;+Estudo+Desenvolvimento+de+Sistemas+na+ETEC+BG;Bem-Vindo!+:%29)](https://git.io/typing-svg)

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=pedro-aguilar-dev&show_icons=true&hide_title=true&hide=stars&cache_seconds=86400&theme=midnight-purple)

### 🔗 Conecte-se comigo
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor)](www.linkedin.com/in/pedro-henrique-aguilar-183083266)


### 🔗 Estudando no momento:
![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)&nbsp;
![Spring Framework](https://img.shields.io/badge/Spring-6DB33F?style=for-the-badge&logo=spring&logoColor=white)&nbsp;
![MongoDB](https://img.shields.io/badge/MongoDB-4EA94B?style=for-the-badge&logo=mongodb&logoColor=white)&nbsp;

![](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=pedro-aguilar-dev&layout=compact&bg_color=000&border_color=white&title_color=4e237e&text_color=4e237e)
 <div align="center">
<br><p align="centre"><b>Visitors Count</b></p>  
<p align="center"><img align="center" src="https://profile-counter.glitch.me/{pedro-aguilar-dev}/count.svg" /></p> 
<br></div>
