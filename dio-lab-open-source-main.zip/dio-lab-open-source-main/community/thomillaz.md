<a href="https://git.io/typing-svg"><img align='center' width='100%' height='80px' src="https://readme-typing-svg.demolab.com?font=Fira+Code&duration=4000&pause=900&color=A286C0&center=true&vCenter=true&width=435&lines=Ol%C3%A1%2C+mundo!;Sou+a+Milla%2C;tenho+25+anos;e+sou+dev+Front-End+Junior.;Fique+%C3%A0+vontade!" alt="Typing SVG" /></a>

<div align='center'>
    <img display='inline_block' height='165em' src='https://github-readme-stats-sigma-five.vercel.app/api?username=thomillaz&show_icons=true&theme=material-palenight'/>
    <img display='inline_block' height='165em' src='https://github-readme-stats-sigma-five.vercel.app/api/top-langs/?username=thomillaz&layout=compact&theme=material-palenight'/>
    <img display='inline_block' src='https://streak-stats.demolab.com?user=thomillaz&theme=material-palenight&date_format=j%20M%5B%20Y%5D'/>
</div>

<div align='center' style='display: inline_block'>
    <h3>Tecnologias:</h3>
    <img height='50px' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" />
    <img height='50px' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" />
    <img height='50px' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" />
    <img height='50px' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" />
    <br /><br />
    <h3>Ferramentas:</h3>
    <img height='50px' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg" />
    <img height='50px' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg" />
    <img height='50px' src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/firefox/firefox-original.svg" />
</div>