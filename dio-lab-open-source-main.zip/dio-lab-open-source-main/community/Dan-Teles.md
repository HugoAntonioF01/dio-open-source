
<div>
    <h1>Eu sou o Daniel. </h1>
    <h1>Bem vindo ao meu Perfil.</h2>
    <p> Sou um estudante de Análise e Desenvolvimento de Sistemas, atualmente no terceiro semestre da Fatec Antônio Russo, buscando minha primeira oportunidade de estágio na área de Análise de Dados. Possuo um inglês intermediário (B1) e conhecimento básico em Python e SQL. Meu encantamento pela área me impulsiona a me dedicar aos estudos. Procuro uma empresa que contribua com o meu crescimento profissional e pessoal.
    </p>
    <p>Estou ansioso para aplicar meus conhecimentos teóricos, aprender e contribuir para o sucesso da empresa.
    </p>
</div>
<div>
    <h2>Conecte-se comigo</h2>
   [![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/dan-teles-silva/)
</div>
<br>
<div align="center">
  <a href="https://github.com/Dan-Teles">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=Dan-Teles&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Dan-Teles&layout=compact&langs_count=7&theme=tokyonight"/>
</div>
<div style="display: inline_block"><br>
    <h2>Tecnologias</h2>
<div>
[![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)] \t
[![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python&logoColor=30A3DC)] \t
[![MYSQL](https://img.shields.io/badge/MYSQL-000?style=for-the-badge&logo=mysql&logoColor=30A3DC)] \t
[![EXCEL](https://img.shields.io/badge/MYSQL-000?style=for-the-badge&logo=microsoft-excel&logoColor=30A3DC)] \t
[![CSS3](https://img.shields.io/badge/CSS-000?style=for-the-badge&logo=css3&logoColor=30A3DC)] \t
[![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5&logoColor=30A3DC)] \t
</div>
</a>

