# Olá! Me chamo Beatriz, Sejam bem vindos ao meu ponto de partida!🚀

Tenho 25 anos e decidi começar na área da tecnologia por curiosidade e paixão, atualmente curso Analise e desenvolvimento de sistema na faculdade Estácio de Sá, e desde então venho buscando agregar conhecimento participando de cursos e botcamps.

**META**
Minha meta é me tornar uma analista de segurança da informação.

**HABILIDADES**
|Nível: Básico|
|--------------|
|Python|
|Git|
|GitHub|

**SOCIAL**
[Linkedln](https://www.linkedin.com/in/beatriz-moniky-56467a26b/)
[Gmail](nikynhaby@gmail.com)

Convido você caro leitor Dev, a me acompanha e se possível contribuir para a minha formação, me orientando e dando aquela força nos meus projetos futuros.
