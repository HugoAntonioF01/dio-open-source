# Sobre mim

Olá! Me chamo Robert, vivo na região sul do país, estudante de Sistemas para Internet e interessado em Ciência de Dados, Informática para Educação e nos impactos da Inteligência Artificial na sociedade.

## 🖥️ **Conecte-se comigo**

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/robert-silveira-780408233/)
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/robertsilveiracrust)

