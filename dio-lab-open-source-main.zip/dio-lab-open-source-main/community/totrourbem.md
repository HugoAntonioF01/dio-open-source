# Ricardo Francisco

## Quem é?

Historiador, 40 anos, fã de NBA e NFL. Gordinho confinado em um corpo bariátrico há 2 anos, trabalho há 11 anos na Cia. de Habitação do Paraná, na área adminsitrativa/imobiliária. Tenho alguma experiência em informática, tendo inclusive, sido auxiliar na gestão do parte de informática da empresa,bem como da equipe de compras/licitações.

## O que estuda?

![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown) ![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5) ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)  
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript) ![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) ![R](https://img.shields.io/badge/R-000000?style=for-the-badge&logo=r&logoColor=00FFFF)   
![MySQL](https://img.shields.io/badge/MySQL-000000?style=for-the-badge&logo=mysql&logoColor=4479A1) ![MongoDB](https://img.shields.io/badge/MongoDB-000000?style=for-the-badge&logo=mongodb&logoColor=47A248)

## Onde acha?

[![WhatsApp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/5543935059077) [![LinkedIn](https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](http://www.linkedin.com/in/ricardo-jeferson-da-silva-francisco-22358011b) [![Gmail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:olhodelugarnenhum@gmail.com) [![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/totorourbem/) [![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/olhodelugarnenhum)

## O que anda fazendo por aqui?

![GitHub Streak](https://streak-stats.demolab.com/?user=totorourbem&theme=nightowl)
