# **JoseLeiteAli**

## **Conecte-se comigo**
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/josé-leite-b6404a148/)

## **Sobre mim**
Profissional em atendimento ao público em transição de carreira, em busca de uma melhor qualidade de vida para mim e minha familía atravrés da tecnologia.

## **Habilidades**
*Em desenvolvimento!!!👷🚨🚧*

## **GitHub Stats**
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=JoseLeiteAli&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## **Minhas Contribuições**
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=JoseLeiteAli&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/JoseLeiteAli/dio-lab-open-source)
