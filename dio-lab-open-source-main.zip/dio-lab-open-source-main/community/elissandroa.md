# Elissandro Aparecido Anastácio

## Sobre mim 
__*Tenho 47 anos casado e pai de dois filhos, gosto de praticar esportes como corrida de rua e futebol. Sou formado em Analise de sistemas e tenho uma pós graduação em ciência de dados, no momento estou cursando um MBA em Business Intelligence, sempre trabalhei com tecnologias, na maioria das vezes com hardware, já estou a um bom tempo estudando programação e gostando mais a cada dia.*__

***

## Conecte-se as minhas redes

[![LinkedIn](https://img.shields.io/badge/LinkedIn-fff?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/elissandroa/)
[![Facebook](https://img.shields.io/badge/Facebook-fff?style=for-the-badge&logo=facebook)](https://www.facebook.com/elissandro.aparecidoanastacio/)
[![Twitter](https://img.shields.io/badge/Twitter-fff?style=for-the-badge&logo=twitter)](https://twitter.com/elissandroan)
[![Instagram](https://img.shields.io/badge/Instagram-fff?style=for-the-badge&logo=instagram)](https://www.instagram.com/elissandroctba/)  


## Linguagens estudadas
---
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript) ![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java) ![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)  ![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react) ![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown) ![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5) ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)  ![GIT](https://img.shields.io/badge/GIT-000?style=for-the-badge&logo=git&logoColor=264CE4)

---
## Atividades em andamento
---
[![BootCamp Ifood](https://hermes.dio.me/tracks/49c408ad-800d-416d-b77c-681add1be673.png )](https://web.dio.me/track/potencia-tech-powered-ifood-ciencias-de-dados-com-python)
