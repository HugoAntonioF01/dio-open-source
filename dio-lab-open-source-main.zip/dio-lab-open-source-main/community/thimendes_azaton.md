<img align="right" src="https://spread.com.br/wp-content/uploads/2020/06/anima-desenvolvimento-agil.gif" width="400"/> 

## Olá 😉, meu nome é Thiago Mendes

---

 [![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=)](https://www.linkedin.com/in/tlmendes/) [![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=GitHub&logoColor=fff)](https://github.com/Azaton/) [![Azure](https://img.shields.io/badge/PORTIFÓLIO-000?style=for-the-badge&logo=AzureDevOps&logoColor=fff)](https://dev.azure.com/Personal-Scrum/Agile%20Master/_wiki/wikis/Agile-Master.wiki/10/Home/)

Sou formado em Sistema da Informação, gosto bastante de tecnologia e de passar o tempo no Youtube. Sou mais caseiro e gosto também de sair para jantar em bares e luagres familiares. Tenho hábito de ler e de estudar sobre a origem do Universo.
  
Comecei a minha jornada profissional no Helpdesk e hoje atuo como *Scrum Master > Consultor Funcional*. Hoje estou aqui pra aprender com vocês, grandes criadores de produtos digitais.

---

## Meus Interesses
  
  Buscando aprimorar os meus conhecimentos em Python, um irmão-parceiro indicou este Bootcamp. Agora estou me desafiando e está sendo um grande sucesso.

  Eu almejo aprender Python para (1) me aproximar das linguagens técnicas e das pessoas com quem trabalho e (2) de conciliar a Ciência de Dados, de forma que seja possível gerar gráficos e indicadores que hoje eu faço no Excel ou no Power BI. 
  
  Moro em Osasco, São Paulo. 

  Obrigado pela oportunidade de aprender com vocês e me encontro a disposição para aqueles que queiram entender um pouquinho mais sobre Scrum e Metodologias Ágeis 😉 Bons estudos 🙏


    
## Conhecimentos
  
* Scrum Master
* Design (Mural)
* Jira & Azure DevOps
* Kanban
* Lean
* Funcional
* SQLite
* Python
* Flask


## Painéis


|                |                  |
| -------------- | ---------------- |
| [![GitHub Streak](https://streak-stats.demolab.com/?user=AZATON&theme=onedark)](https://git.io/streak-stats) | ![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AZATON&theme=gruvbox&show_icons=true) |


|                |                  |
| -------------- |----------------- |
| ![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AZATON&theme=cobalt&show_icons=true)| [![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AZATON&repo=ESTUDOS-PYTHON&theme=merko&show_icons=true)](https://github.com/AZATON/AULAS-PYTHON) |
