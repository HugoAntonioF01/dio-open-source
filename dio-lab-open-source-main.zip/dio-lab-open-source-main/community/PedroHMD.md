
# PedroMIranda

## Sobre mim

Olá! Sou pedro Miranda, um entusiasta da programação apaixonado por Python. Sou um desenvolvedor autodidata com uma grande paixão por resolver problemas complexos por meio de código limpo e eficiente. Tenho experiência no desenvolvimento de aplicativos e soluções web.

## Habilidades

- **Linguagens de Programação:** Python
- **Desenvolvimento Web:** HTML, CSS, JavaScript
- **Frameworks e Bibliotecas:** Django, Flask, Qt
- **Banco de Dados:** MySQL, PostgreSQL
- **Controle de Versão:** Git, GitHub
- **Metodologias de Desenvolvimento:** Agile, Scrum
