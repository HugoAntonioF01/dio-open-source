
# Hello, I'm Chris!

## About me

I graduated in Information Systems in 2013, but, for lack of opportunity and incentive, at the time, I still don't have experience in the area.
Today I see a more inclusive labor market and with more women to get involved in science and technology. In this scenario, I return to study every day.
I look forward to a chance to learn (even more) and put my knowledge into practice.

## Github Stats

![Christiane's GitHub stats](https://github-readme-stats.vercel.app/api?username=christianebs&show_icons=true&theme=dracula&hide_border=true&bg_color=0D1117&title_color=CC6699&icon_color=CC6699&include_all_commits=true&count_private=true")
![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=christianebs&layout=compact&theme=dracula&hide_border=true&bg_color=0D1117&title_color=CC6699&icon_color=CC6699)

##  Languages

![HTML5](https://img.shields.io/badge/html5-0D1117.svg?style=for-the-badge&logo=html5&logoColor=CC6699)
![CSS3](https://img.shields.io/badge/css3-0D1117.svg?style=for-the-badge&logo=css3&logoColor=CC6699)
![JavaScript](https://img.shields.io/badge/javascript-0D1117.svg?style=for-the-badge&logo=javascript&logoColor=CC6699)
![Java](https://img.shields.io/badge/java-0D1117.svg?style=for-the-badge&logo=openjdk&logoColor=CC6699)
![Python](https://img.shields.io/badge/python-0D1117?style=for-the-badge&logo=python&logoColor=CC6699)


## Contact me

[![LinkedIn](https://img.shields.io/badge/linkedin-0D1117.svg?style=for-the-badge&logo=linkedin&logoColor=CC6699)](https://linkedin.com/in/christiane-barbosa)
[![Gmail](https://img.shields.io/badge/Gmail-0D1117?style=for-the-badge&logo=gmail&logoColor=CC6699)](mailto:christianebs90@gmail.com)