# Olá! Eu sou a Ana 🥰
Tenho 24 anos e moro em Lisboa, Portugal. Curso Ciências da Computação na Una Live e muito me interessa a área de análise de dados.
Adoro ler, jogar e escutar música.

O que estou lendo: Immortality, da Dana Schwartz
O que estou jogando: Stardew Valley
Minha cantora favorita: Taylor Swift

## Deem uma olhada no meu perfil <a href="https://github.com/kimanakim">