# Olá! Eu sou João Cardoso 👍😀 
Apaixonado por matemática, Python e análise de dados.

## Vamos nos conectar?

[![Linkedin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/joaovictorcardoso/)
[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/_victorcardosoo/)


![João Cardoso GitHub stats](https://github-readme-stats.vercel.app/api?username=Joao-Cardosoo&show_icons=true&theme=dracula)

![João Cardoso Languages](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Joao-Cardosoo&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Tecnologia que estou estudando e usando atualmente:

<div style="display: inline_block"><br/>
    <img align="center" alt="Python" src ="https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white">
    <img align="center" alt="SQlite" src ="https://img.shields.io/badge/SQLite-07405E?style=for-the-badge&logo=sqlite&logoColor=white">
    <img align="center" alt="Excel" src ="https://img.shields.io/badge/Microsoft_Excel-217346?style=for-the-badge&logo=microsoft-excel&logoColor=white">

</div><br/>
