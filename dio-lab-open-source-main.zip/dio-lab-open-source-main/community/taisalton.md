# Taísa Salton Vieira

## Sobre mim

Formada em Matemática e futura Cientista de Dados. 

## Conecte-se comigo
[![MEU PERFIL NA DIO](https://camo.githubusercontent.com/5ab7a221b534e8c6760bed4666dc9ac930f63b9e2eeda14923af266b49543d27/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f2d4d657525323050657266696c2532306e6125323044494f2d3330413344433f7374796c653d666f722d7468652d6261646765?style=for-the-badge)](https://web.dio.me/users/taisa_salton?tab=skills)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/taísa-salton-vieira-930a5374/)
[![E-MAIL](https://camo.githubusercontent.com/5569c47c09be5c1b56cc1327a30316503cd933f97caea0be8dc8a91789815e71/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f2d456d61696c2d3030303f7374796c653d666f722d7468652d6261646765266c6f676f3d6d6963726f736f66742d6f75746c6f6f6b266c6f676f436f6c6f723d453934443546?style=for-the-badge&)](mailto:taisa_salton@hotmail.com)

## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![GIT](https://img.shields.io/badge/git-000?style=for-the-badge&logo=git)
![GITHUB](https://img.shields.io/badge/github-000?style=for-the-badge&logo=github)
![MYSQL](https://img.shields.io/badge/MYSQL-000?style=for-the-badge&logo=mysql)
