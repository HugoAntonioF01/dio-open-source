# Tulio Sabino

## Um pouco sobre mim 👋

Sempre trabalhei na área de tecnologia e mesmo nos periodos em que fiquei afastado, sempre fui apaixonado pela área, Formado em Sistemas para Internet, aprendi um pouco de programação, mas nunca me dediquei de verdade.



Depois de me decepcionar na área bancária decidi voltar para a área de programação, mas dessa vez com tudo!

## Contatos

[![GitHub followers](https://img.shields.io/github/followers/tuliosabino?style=social)](https://github.com/tuliosabino)

[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/tuliosalmeida/)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/tuliosalmeida/)
[![Whatsapp](https://img.shields.io/badge/whatsapp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/5534991462388)
[![Gmail](https://img.shields.io/badge/gmail-EA4335?style=for-the-badge&logo=gmail&logoColor=white)](mailto:tuliosabinots@gmail.com)

## Estatísticas do GitHub

![Estatísticas do GitHub](https://github-readme-stats.vercel.app/api?username=tuliosabino&show_icons=true&theme=dark)

## Contribuições

![Contribuições](https://github-readme-streak-stats.herokuapp.com/?user=tuliosabino&theme=dark)

## Linguagens de programação

![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![HTML5](https://img.shields.io/badge/HTML-E34F26?style=for-the-badge&logo=HTML5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS-1572B6?style=for-the-badge&logo=CSS3)

## Bibliotecas e Frameworks

![Django](https://img.shields.io/badge/Django-092E20?style=for-the-badge&logo=Django)
![WordPress](https://img.shields.io/badge/WordPress-21759B?style=for-the-badge&logo=WordPress)
![Elementor](https://img.shields.io/badge/Elementor-92003B?style=for-the-badge&logo=Elementor)
