### 🎧 Hey Everyone!! I'm Lucas 🎸
<p style="font-size: 15px"> I am a graduate in Systems Analysis and Development, lover of emerging technologies and disruptive innovations. My main interest is in web application development, as well as an enthusiast of the data ecosystem and Artificial Intelligence, with a goal of exploring the power of data through programming.</p>
https://rxresu.me/r/7_tCMHQ1

<!-- ## Minhas Contribuições -->

## ***GitHub Stats***
<div>
  <a href="https://github.com/luk3mn">
    <img height="180em" src="https://github-readme-stats.vercel.app/api?username=luk3mn&show_icons=true&theme=dracula&include_all_commits=true&count_private=false"/>
    <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=luk3mn&layout=compact&langs_count=6&theme=dracula"/>
  </a>
</div><br>


## ***Skills***
![Python](https://img.shields.io/badge/python-%23000?style=for-the-badge&logo=python&color=%23000)
![django](https://img.shields.io/badge/django-%23000?style=for-the-badge&logo=django&color=%23000)
![javascript](https://img.shields.io/badge/javascript-%23000?style=for-the-badge&logo=javascript&color=%23000)
![postgres](https://img.shields.io/badge/postgresql-%23000?style=for-the-badge&logo=postgresql)
![terraform](https://img.shields.io/badge/terraform-%23000?style=for-the-badge&logo=terraform)
![docker](https://img.shields.io/badge/docker-%23000?style=for-the-badge&logo=docker)
![React Native](https://img.shields.io/badge/React-Native-000?style=for-the-badge&logo=React-Native)
![MySQL](https://img.shields.io/badge/MySQL-%23000?style=for-the-badge&logo=mysql)
![php](https://img.shields.io/badge/php-%23000?style=for-the-badge&logo=php)
![HTML](https://img.shields.io/badge/HTML-%23000?style=for-the-badge&logo=html5)
![css](https://img.shields.io/badge/css3-%23000?style=for-the-badge&logo=css3)
![linux](https://img.shields.io/badge/linux-%23000?style=for-the-badge&logo=linux)

[![GitHub Streak](https://streak-stats.demolab.com/?user=luk3mn&theme=radical&dates=FFF)](https://git.io/streak-stats)

## ***Contact me***
[![GitHub](https://img.shields.io/badge/github-%23000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/luk3mn)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/lucas-nunes-324822135/)
[![Gmail](https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white)](mailto:lucasnunes2030@gmail.com)
[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/luk3mn/)