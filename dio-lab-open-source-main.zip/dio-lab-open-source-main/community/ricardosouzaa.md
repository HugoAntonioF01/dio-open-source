# Ricardo
Olá Sou o Ricardo e estou fazendo o tutorial de colaboração do github. Realizando o primeiro commit teste. 
Obrigado!!!

## Conecte-se comigo
[![GitHub](https://img.shields.io/badge/GitHub-ec63a1?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/RicardoSouzaa)

## Habilidades
[![GitHub](https://img.shields.io/badge/GitHub-ec63a1?style=for-the-badge&logo=github&logoColor=fff)](https://docs.github.com/)
[![Git](https://img.shields.io/badge/Git-ec63a1?style=for-the-badge&logo=git&logoColor=fff)](https://git-scm.com/doc)
![C#](https://img.shields.io/badge/CSharp-ec63a1?style=for-the-badge&logo=c-sharp&logoColor=823085)
![HTML5](https://img.shields.io/badge/HTML5-ec63a1?style=for-the-badge&logo=html5)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ricardosouzaa&theme=transparent&bg_color=ec63a1&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=fff&hide_title=true&hide=stars)

## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=ricardosouzaa&repo=dio-lab-open-source&bg_color=ec63a1&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=fff)](https://github.com/octoeli/dio-lab-open-source)