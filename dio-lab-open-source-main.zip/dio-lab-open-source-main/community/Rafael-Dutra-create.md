# **Rafael Dutra**

## Social
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/rafael-dutra-14540a188/) [![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/ou_gordin/)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Rafael-Dutra-create&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Habilidades
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Rafael-Dutra-create&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Rafael-Dutra-create&repo=Portifolio&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Rafael-Dutra-create/Portifolio) [![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Rafael-Dutra-create&repo=Lista-de-Tarefas&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Rafael-Dutra-create/Lista-de-Tarefas) [![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Rafael-Dutra-create&repo=Cronometro&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Rafael-Dutra-create/Cronometro)