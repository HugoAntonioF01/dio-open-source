
# Andrey Silva 

💼 Sou um profissional da área de meio ambiente buscando recolocação profissional no mercado de tecnologia e ciência de dados. No momento, estou como técnico de meio ambiente no Porto de Docas do Rio de Janeiro, numa terceirizada da Petrobras. 

👨‍🎓 Atualmente, estou graduando em Data Science, e estou focado em aprender as linguagens SQL e Python, e para visualização de dados venho etudando Power BI.

🚀 Sou disciplinado, e sou resiliente frente a projetos difíceis. Estou constantemente em busca de oportunidades que me permitam desenvolver e aplicar o conhecimento técnico que tenho aprendido. 


<div>
<a href="https://github.com/SLV4">
  
<img width="400" height="300" src="https://github-readme-stats.vercel.app/api/top-langs/?username=SLV4&layout=compact&langs_count=20&theme=dark"/>
<img  width="400" height="300" src="https://github-readme-stats.vercel.app/api?username=SLV4&show_icons=true&theme=dark&include_all_commits=true&count_private=true"/>
</div>

![Snake animation](https://github.com/Alexandreinfov/Alexandreinfov/blob/output/github-contribution-grid-snake.svg)


## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/andrey-santos-54046152/)

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/slv4/)
