## Saudações! 
### Eu sou a Lilandra 👋
#### Biomédica apaixonada por dados e Python que está em transição de carreira.

A seguir você pode saber um pouquinho mais sobre minha formação:

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 📊 MBA em Big Data e Inteligência Competitiva (Faculdade Descomplica, 2023)

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 🖥️ Pós-graduação em Análise e Desenvolvimento de Programas (Faculdade Descomplica, 2023)

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 📈 Pós-graduação em Data Science e Informática na Área da Saúde (Albert Einstein Instituto Israelita de Ensino e Pesquisa, 2019)

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 🔬 Bacharelado em Biomedicina (Universidade de Mogi das Cruzes, 2014)
<br><br>

Neste momento estou ampliando meu conhecimento através de formações e cursos listados abaixo:

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ⭐ Bootcamp Potência Tech powered by iFood | Ciências de Dados com Python (DIO, 2023)

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 📚 Certificação Análise de Dados do Google (Coursera, 2023)

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 🎓 Formação SQL Database Specialist (DIO, 2023)

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 🎓 Formação Python Developer (DIO, 2023)
<br><br>

Ferramentas e tecnologias conhecidas a serem aperfeiçoadas:

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" height="30" width="30"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/r/r-original.svg" height="30" width="30"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg" height="30" width="30"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg" height="30" width="30"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/anaconda/anaconda-original.svg" height="30" width="30"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" height="30" width="30"/>         
<br><br>

Entre em contato comigo! 📧 <br> 

[![linkedin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/lilandra-rcunha/)

[![GitHub Streak](https://streak-stats.demolab.com/?user=lilandracunha&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)